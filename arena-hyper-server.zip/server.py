import os
import re
import time
import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
import base64
import json
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse, StreamingResponse, PlainTextResponse
from telegram import BotCommand, MenuButtonWebApp, WebAppInfo

import database as db
import ai_arena
import rubika_bot
import config_manager
from bot import create_bot_application, BOT_TOKEN

START_TIME = time.time()
bot_app = None
bot_info = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    global bot_app, bot_info
    db.init_db()
    db._load_shared_mp_rooms()
    db._load_shared_msg()
    # Warm L1 RAM cache for all registered server configs (< 1 µs reads)
    try:
        for k in db.list_api_keys_with_projects():
            db.get_server_config(k["key"])
    except Exception:
        pass

    # Non-blocking background sync of Arena AI models on startup so port 8080 opens in <0.5s
    asyncio.create_task(ai_arena.sync_arena_models_once())

    if BOT_TOKEN:
        bot_app = create_bot_application()
        await bot_app.initialize()
        await bot_app.start()
    else:
        bot_app = None

    commands = [
        BotCommand("start", "شروع مجدد و نمایش منوی Arena AI ⚡"),
    ]
    try:
        await bot_app.bot.set_my_commands(commands)
    except Exception:
        pass
    try:
        me = await bot_app.bot.get_me()
        bot_info = {
            "id": me.id,
            "first_name": me.first_name,
            "username": me.username,
            "can_join_groups": me.can_join_groups,
        }
    except Exception:
        pass

    if bot_app:
        await bot_app.updater.start_polling(poll_interval=0.1, timeout=1, drop_pending_updates=True)

    # 1. Background 60-Second Live Model Discovery & Sync Task
    async def model_sync_loop():
        while True:
            await asyncio.sleep(60)
            try:
                await ai_arena.sync_arena_models_once()
            except Exception:
                pass

    # 2. Background Rubika Bot Polling Worker
    rubika_task = asyncio.create_task(rubika_bot.rubika_polling_worker())

    # 3. 1-Second Ultra-Fast Self-Healing Watchdog + 1-Year Anti-Sleep Heartbeat
    async def telegram_supervisor_1s():
        tick = 0
        hb_path = "./data/server_heartbeat.json"
        while True:
            await asyncio.sleep(1)
            tick += 1
            try:
                if bot_app and bot_app.updater:
                    if not bot_app.updater.running:
                        try:
                            await bot_app.updater.start_polling(poll_interval=0.1, timeout=1, drop_pending_updates=False)
                        except Exception:
                            pass
                if tick % 5 == 0:
                    with open(hb_path, "w", encoding="utf-8") as f:
                        json.dump({
                            "status": "alive_24_7_365",
                            "pid": os.getpid(),
                            "timestamp": time.time(),
                            "uptime_seconds": int(time.time() - START_TIME),
                        }, f)
                if tick % 25 == 0 and bot_app and bot_app.bot:
                    await bot_app.bot.get_me()
            except Exception:
                pass

    # 4. 10-Minute (600s) Automatic Telegram Bot Heartbeat / Keep-Alive Messenger
    KEEPALIVE_STATS = {
        "enabled": True,
        "interval_seconds": 600,
        "target_chat_id": 8202240636,
        "sent_count": 0,
        "last_sent": "",
        "last_error": "",
    }
    app.state.keepalive_10min = KEEPALIVE_STATS

    def _get_admin_tg_chat_id() -> int:
        try:
            conn = db.get_conn()
            cur = conn.cursor()
            cur.execute(
                "SELECT user_id FROM users WHERE LOWER(username) = 'filternet3' AND platform = 'telegram' AND CAST(user_id AS INTEGER) > 1000000 ORDER BY started_at DESC LIMIT 1"
            )
            row = cur.fetchone()
            conn.close()
            if row and row["user_id"]:
                return int(row["user_id"])
        except Exception:
            pass
        return 8202240636

    async def telegram_10min_keepalive_loop():
        await asyncio.sleep(3)
        while True:
            try:
                if KEEPALIVE_STATS["enabled"] and bot_app and bot_app.bot:
                    cid = _get_admin_tg_chat_id()
                    KEEPALIVE_STATS["target_chat_id"] = cid
                    up_sec = int(time.time() - START_TIME)
                    h, rem = divmod(up_sec, 3600)
                    m, s = divmod(rem, 60)
                    now_str = time.strftime("%Y-%m-%d %H:%M:%S")
                    msg_txt = (
                        f"💓 پالس زنده نگهبان ۱۰ دقیقه‌ای ربات و فوق موتور فعال است ✅\n"
                        f"⏱ زمان کارکرد فعلی: {h:02d}:{m:02d}:{s:02d}\n"
                        f"⚡ فوق موتور: ۱ میکروثانیه (<1 µs) | مدل‌ها: {len(ai_arena.ARENA_MODELS)}\n"
                        f"🕒 زمان ارسال: {now_str}"
                    )
                    await bot_app.bot.send_message(
                        chat_id=cid,
                        text=msg_txt,
                        disable_notification=True,
                    )
                    KEEPALIVE_STATS["sent_count"] += 1
                    KEEPALIVE_STATS["last_sent"] = now_str
                    KEEPALIVE_STATS["last_error"] = ""
            except Exception as e:
                KEEPALIVE_STATS["last_error"] = str(e)
            await asyncio.sleep(600)

    sync_task = asyncio.create_task(model_sync_loop())
    hb_task = asyncio.create_task(telegram_supervisor_1s())
    ka10_task = asyncio.create_task(telegram_10min_keepalive_loop())

    # Ensure bot menu button is clean default (no broken web app)
    if bot_app and bot_app.bot:
        try:
            from telegram import MenuButtonDefault
            await bot_app.bot.set_chat_menu_button(menu_button=MenuButtonDefault())
        except Exception:
            pass

    yield

    # Flush all RAM rooms, messenger channels, and DB to persistent storage before exit
    try:
        db.SHARED_MP_ROOMS_FILE.write_text(json.dumps(db._MP_ROOMS_MEM, ensure_ascii=False), encoding="utf-8")
        db.SHARED_MSG_FILE.write_text(json.dumps(db._MSG_CHANNELS_MEM, ensure_ascii=False), encoding="utf-8")
        db.sync_db_to_shared()
    except Exception:
        pass

    sync_task.cancel()
    rubika_task.cancel()
    hb_task.cancel()
    ka10_task.cancel()
    if bot_app:
        await bot_app.updater.stop()
        await bot_app.stop()
        await bot_app.shutdown()


app = FastAPI(title="Arena AI 24/7 Server (Telegram + Rubika + Global Game Engine)", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
async def health_check():
    uptime_sec = int(time.time() - START_TIME)
    return {
        "status": "online",
        "uptime_seconds": uptime_sec,
        "bot": bot_info,
        "rubika": rubika_bot.RUBIKA_STATUS,
        "models_count": len(ai_arena.ARENA_MODELS),
        "model_sync": ai_arena.MODEL_SYNC_STATS,
        "keepalive_10min": getattr(app.state, "keepalive_10min", {}),
    }


@app.get("/api/overview")
async def api_overview():
    uptime_sec = int(time.time() - START_TIME)
    hours, rem = divmod(uptime_sec, 3600)
    minutes, seconds = divmod(rem, 60)
    data = db.get_dashboard_overview()
    data["uptime"] = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    data["bot"] = bot_info
    data["rubika"] = rubika_bot.RUBIKA_STATUS
    data["models_count"] = len(ai_arena.ARENA_MODELS)
    data["model_sync"] = ai_arena.MODEL_SYNC_STATS
    data["api_key"] = db.get_api_key()
    data["disabled_models"] = list(db.get_disabled_models())
    data["models_list"] = [
        {"key": k, "name": v["name"], "btn": v["btn"], "disabled": not db.is_model_enabled(k)}
        for k, v in ai_arena.ARENA_MODELS.items()
    ]
    data["image_models"] = [
        {
            "key": k,
            "name": v["name"],
            "btn": v["btn"],
            "desc": v.get("desc", ""),
            "disabled": not db.is_model_enabled(k),
        }
        for k, v in ai_arena.ARENA_IMAGE_MODELS.items()
    ]
    data["keys"] = db.list_api_keys_with_projects()
    data["keys_count"] = len(data["keys"])
    return JSONResponse(data)


@app.post("/api/key/regenerate")
async def api_key_regenerate():
    new_key = db.generate_new_api_key()
    return JSONResponse({"ok": True, "api_key": new_key})


@app.post("/api/models/toggle")
async def api_models_toggle(req: Request):
    try:
        body = await req.json()
    except Exception:
        body = {}
    model_key = str(body.get("model_key") or "").strip()
    if not model_key:
        return JSONResponse({"ok": False, "error": "شناسه مدل الزامی است."}, status_code=400)
    is_disabled = db.toggle_model_disabled(model_key)
    return JSONResponse({"ok": True, "model": model_key, "disabled": is_disabled})


@app.post("/rubika/webhook")
@app.post("/rubika/webhook/{subpath:path}")
async def rubika_webhook_endpoint(req: Request, subpath: str = ""):
    """
    Receives real-time webhook updates directly from Rubika servers (`updateBotEndpoints`)
    so even when Iran's national network (نت ملی) is restricted, Rubika can push updates to the bot!
    """
    try:
        body = await req.json()
        rubika_bot.RUBIKA_STATUS["connected"] = True
        rubika_bot.RUBIKA_STATUS["last_poll"] = time.strftime("%H:%M:%S")
        if isinstance(body, dict):
            if "update" in body and isinstance(body["update"], dict):
                asyncio.create_task(rubika_bot.handle_rubika_update(body["update"]))
            elif "inline_message" in body and isinstance(body["inline_message"], dict):
                im = body["inline_message"]
                asyncio.create_task(rubika_bot.handle_rubika_update({
                    "chat_id": im.get("chat_id"),
                    "inline_message": im,
                }))
            elif "chat_id" in body:
                asyncio.create_task(rubika_bot.handle_rubika_update(body))
        return JSONResponse({"status": "OK"})
    except Exception as e:
        return JSONResponse({"status": "ERROR", "detail": str(e)}, status_code=400)


@app.post("/api/web_chat")
async def api_web_chat(req: Request):
    """Direct web chat endpoint so the user can also chat with Arena AI from the browser without any filter."""
    body = await req.json()
    prompt = str(body.get("prompt") or "").strip()
    model_key = str(body.get("model") or "gpt-5.6-sol").strip()
    user_id = str(body.get("user_id") or "web_user").strip()
    if not prompt:
        return JSONResponse({"ok": False, "error": "پیام خالی است."}, status_code=400)

    db.register_user(user_id, "کاربر وب", "web", platform="web")
    state = db.get_user_state(user_id)
    ans = await ai_arena.generate_once(model_key, state["history"], prompt)
    db.append_user_history(user_id, prompt, ans)
    db.log_arena_query(user_id, "کاربر پنل وب", "web_direct", model_key, prompt)
    return JSONResponse({"ok": True, "answer": ans, "model": model_key})


@app.post("/api/sync_models")
async def api_sync_models():
    stats = await ai_arena.sync_arena_models_once()
    return JSONResponse({"ok": True, "stats": stats, "models_count": len(ai_arena.ARENA_MODELS)})


def check_auth(req: Request) -> bool:
    token = ""
    auth_header = req.headers.get("Authorization", "").strip()
    if auth_header.startswith("Bearer "):
        token = auth_header.split("Bearer ", 1)[1].strip()
    if not token:
        token = req.query_params.get("api_key") or req.query_params.get("key") or ""
        token = token.strip()

    key_info = db.get_key_info(token)
    if key_info:
        if key_info.get("disabled") or key_info.get("is_active") == 0:
            req.state.auth_error = "کلید توسط مدیر خاموش و غیرفعال شده است (Key is turned OFF)."
            return False
        req.state.auth_info = key_info
        req.state.project_id = key_info.get("project_id", "proj-master")
        return True
    return False


@app.get("/api/keys")
async def api_get_keys():
    keys = db.list_api_keys_with_projects()
    return JSONResponse({"ok": True, "keys": keys})


@app.post("/api/keys")
async def api_create_key(req: Request):
    try:
        body = await req.json()
    except Exception:
        body = {}
    name = str(body.get("name") or "").strip()
    project_name = str(body.get("project_name") or "").strip()
    role = str(body.get("role") or "همکار").strip()
    description = str(body.get("description") or "").strip()
    key_data = db.create_api_key_with_project(key_name=name, project_name=project_name, role=role, description=description)
    return JSONResponse({"ok": True, "key": key_data})


@app.post("/api/keys/toggle")
async def api_toggle_key(req: Request):
    try:
        body = await req.json()
    except Exception:
        body = {}
    key = str(body.get("key") or "").strip()
    if not key:
        return JSONResponse({"ok": False, "error": "کلید نامعتبر است."}, status_code=400)
    new_state = db.toggle_api_key_active(key)
    return JSONResponse({"ok": True, "key": key, "is_active": new_state})


@app.delete("/api/keys/{key}")
async def api_delete_key(key: str):
    deleted = db.delete_api_key(key)
    return JSONResponse({"ok": deleted})


@app.get("/arena_bridge.py")
async def download_arena_bridge():
    bridge_path = "/home/antigravity/telegram-manager-bot/arena_bridge.py"
    if os.path.exists(bridge_path):
        return FileResponse(bridge_path, media_type="text/x-python", filename="arena_bridge.py")
    return PlainTextResponse("# Arena Bridge\n", status_code=200)


@app.get("/v1/models")
async def v1_list_models(req: Request):
    if not check_auth(req):
        err_msg = getattr(req.state, "auth_error", "Invalid API Key. Please provide Authorization: Bearer <API_KEY>")
        code = 403 if getattr(req.state, "auth_error", None) else 401
        return JSONResponse({"error": {"message": err_msg, "type": "auth_error"}}, status_code=code)
    models = []
    for k, v in ai_arena.ARENA_MODELS.items():
        models.append({
            "id": k,
            "object": "model",
            "created": 1700000000,
            "owned_by": "arena-ai",
            "name": v["name"],
            "type": v.get("type", "chat")
        })
    return JSONResponse({"object": "list", "data": models})


@app.post("/v1/chat/completions")
async def v1_chat_completions(req: Request):
    if not check_auth(req):
        err_msg = getattr(req.state, "auth_error", "Invalid API Key. Please provide Authorization: Bearer <API_KEY>")
        code = 403 if getattr(req.state, "auth_error", None) else 401
        return JSONResponse({"error": {"message": err_msg, "type": "auth_error"}}, status_code=code)
    try:
        body = await req.json()
    except Exception:
        return JSONResponse({"error": {"message": "Invalid JSON body"}}, status_code=400)

    model = str(body.get("model") or "gpt-5.6-sol").strip()
    messages = body.get("messages") or []
    stream = bool(body.get("stream", False))

    sys_override = ""
    history = []
    user_prompt = ""

    for m in messages:
        role = m.get("role", "user")
        content = m.get("content", "")
        if role == "system":
            sys_override = content
        elif role == "user":
            user_prompt = content
        elif role == "assistant":
            history.append({"role": "assistant", "content": content})

    if not user_prompt and messages:
        user_prompt = messages[-1].get("content", "")

    if stream:
        async def event_generator():
            cancel_ev = asyncio.Event()
            cmpl_id = f"chatcmpl-{int(time.time()*1000)}"
            created_ts = int(time.time())
            last_text = ""
            async for full_ans in ai_arena.stream_llm_response(model, history, user_prompt, sys_override, cancel_ev):
                new_chunk = full_ans[len(last_text):]
                last_text = full_ans
                if new_chunk:
                    chunk_obj = {
                        "id": cmpl_id,
                        "object": "chat.completion.chunk",
                        "created": created_ts,
                        "model": model,
                        "choices": [{"index": 0, "delta": {"content": new_chunk}, "finish_reason": None}]
                    }
                    yield f"data: {json.dumps(chunk_obj, ensure_ascii=False)}\n\n"
            done_chunk = {
                "id": cmpl_id,
                "object": "chat.completion.chunk",
                "created": created_ts,
                "model": model,
                "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}]
            }
            yield f"data: {json.dumps(done_chunk, ensure_ascii=False)}\n\n"
            yield "data: [DONE]\n\n"

        return StreamingResponse(event_generator(), media_type="text/event-stream")
    else:
        ans = await ai_arena.generate_once(model, history, user_prompt, sys_override)
        return JSONResponse({
            "id": f"chatcmpl-{int(time.time()*1000)}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": model,
            "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": ans},
                "finish_reason": "stop"
            }],
            "usage": {
                "prompt_tokens": len(user_prompt.split()),
                "completion_tokens": len(ans.split()),
                "total_tokens": len(user_prompt.split()) + len(ans.split())
            }
        })


@app.post("/v1/video/generations")
@app.post("/v1/videos/generations")
async def v1_video_generations(req: Request):
    if not check_auth(req):
        return JSONResponse({"error": {"message": "Invalid API Key. Please provide Authorization: Bearer <API_KEY>", "type": "auth_error"}}, status_code=401)
    try:
        body = await req.json()
    except Exception:
        body = {}
    prompt = str(body.get("prompt") or "").strip()
    if not prompt:
        return JSONResponse({"error": {"message": "Prompt is required"}}, status_code=400)

    path_a, path_b, secrets, desc = await ai_arena.generate_arena_video_battle(prompt)
    data_items = []
    if path_a and os.path.exists(path_a):
        with open(path_a, "rb") as vf:
            data_items.append({"model_name": secrets[0], "b64_mp4": base64.b64encode(vf.read()).decode("ascii")})
        try: os.remove(path_a)
        except Exception: pass
    if path_b and os.path.exists(path_b):
        with open(path_b, "rb") as vf:
            data_items.append({"model_name": secrets[1], "b64_mp4": base64.b64encode(vf.read()).decode("ascii")})
        try: os.remove(path_b)
        except Exception: pass

    return JSONResponse({
        "created": int(time.time()),
        "description": desc,
        "models": list(secrets),
        "data": data_items
    })


# ==================== MASTER PROJECT STUDIO API ====================

@app.get("/api/projects")
@app.get("/v1/projects")
async def api_get_projects():
    projs = db.list_projects()
    return JSONResponse({"ok": True, "projects": projs})


@app.post("/api/projects")
@app.post("/v1/projects")
async def api_create_project(req: Request):
    try:
        body = await req.json()
    except Exception:
        body = {}
    name = str(body.get("name") or "New Project").strip()
    description = str(body.get("description") or "").strip()
    prompt = str(body.get("prompt") or "").strip()
    code_files = body.get("code_files") or body.get("files") or {}
    status = str(body.get("status") or "active").strip()

    proj = db.create_project(name=name, description=description, prompt=prompt, code_files=code_files, status=status)
    return JSONResponse({"ok": True, "project": proj})


@app.get("/api/projects/{project_id}")
@app.get("/v1/projects/{project_id}")
async def api_get_project_detail(project_id: str):
    proj = db.get_project(project_id)
    if not proj:
        return JSONResponse({"ok": False, "error": "پروژه یافت نشد."}, status_code=404)
    return JSONResponse({"ok": True, "project": proj})


@app.put("/api/projects/{project_id}")
@app.put("/v1/projects/{project_id}")
async def api_update_project(project_id: str, req: Request):
    try:
        body = await req.json()
    except Exception:
        body = {}
    updated = db.update_project(
        project_id,
        name=body.get("name"),
        description=body.get("description"),
        prompt=body.get("prompt"),
        code_files=body.get("code_files") or body.get("files"),
        status=body.get("status"),
    )
    if not updated:
        return JSONResponse({"ok": False, "error": "پروژه یافت نشد."}, status_code=404)
    return JSONResponse({"ok": True, "project": updated})


@app.delete("/api/projects/{project_id}")
@app.delete("/v1/projects/{project_id}")
async def api_delete_project(project_id: str, req: Request):
    deleted = db.delete_project(project_id)
    return JSONResponse({"ok": deleted})


@app.post("/api/projects/{project_id}/generate")
@app.post("/v1/projects/{project_id}/generate")
async def api_generate_project_code(project_id: str, req: Request):
    """Uses Arena AI to generate code and architecture for a project."""
    proj = db.get_project(project_id)
    if not proj:
        return JSONResponse({"ok": False, "error": "پروژه یافت نشد."}, status_code=404)

    prompt = proj.get("prompt") or proj.get("description") or proj.get("name")
    model = "gpt-5.6-sol"
    sys_prompt = "You are an expert full-stack software architect. Generate clean, production-ready code files for the requested project. Return your output clearly structured."
    ans = await ai_arena.generate_once(model, [], f"Generate complete code architecture for project '{proj['name']}': {prompt}", sys_prompt)

    current_files = proj.get("code_files") or {}
    current_files["architecture.md"] = ans
    db.update_project(project_id, code_files=current_files, status="completed")
    return JSONResponse({"ok": True, "project": db.get_project(project_id), "generated": ans})


@app.get("/api/game/leaderboard")
@app.get("/v1/game/leaderboard")
async def api_game_leaderboard():
    leaders = db.get_game_leaderboard(20)
    return JSONResponse({"ok": True, "leaderboard": leaders})


@app.post("/v1/game/create")
@app.post("/api/game/create")
@app.get("/v1/game/create")
async def api_mp_game_create(req: Request, game_name: str = "Arena Game", host_id: str = "P1", room_code: str = ""):
    t0 = time.perf_counter()
    body = {}
    if req.method == "POST":
        try:
            body = await req.json()
        except Exception:
            body = {}
    g_name = str(body.get("game_name") or game_name or "Arena Game")
    h_id = str(body.get("host_id") or body.get("player_id") or host_id or "P1")
    r_code = str(body.get("room_code") or room_code or "")
    init_state = body.get("state") or body.get("initial_state") or {}
    room = db.mp_create_room(game_name=g_name, host_id=h_id, initial_state=init_state, room_code=r_code)
    latency_ms = round((time.perf_counter() - t0) * 1000, 3)
    return JSONResponse({
        "ok": True,
        "room_code": room["room_code"],
        "room": room,
        "latency_ms": latency_ms,
        "region": "GLOBAL-UNFILTERED-ANY-IP",
    })


@app.post("/v1/game/join")
@app.post("/api/game/join")
@app.get("/v1/game/join")
async def api_mp_game_join(req: Request, room_code: str = "", guest_id: str = "P2"):
    t0 = time.perf_counter()
    body = {}
    if req.method == "POST":
        try:
            body = await req.json()
        except Exception:
            body = {}
    r_code = str(body.get("room_code") or room_code or "").strip()
    g_id = str(body.get("guest_id") or body.get("player_id") or guest_id or "P2").strip()
    if not r_code:
        return JSONResponse({"ok": False, "error": "کد اتاق (room_code) الزامی است."}, status_code=400)
    room = db.mp_join_room(room_code=r_code, guest_id=g_id)
    latency_ms = round((time.perf_counter() - t0) * 1000, 3)
    return JSONResponse({
        "ok": True,
        "room_code": room["room_code"],
        "room": room,
        "latency_ms": latency_ms,
        "region": "GLOBAL-UNFILTERED-ANY-IP",
    })


@app.post("/v1/game/move")
@app.post("/v1/game/sync")
@app.post("/api/game/move")
@app.post("/api/game/sync")
async def api_mp_game_sync(req: Request):
    t0 = time.perf_counter()
    try:
        body = await req.json()
    except Exception:
        body = {}
    r_code = str(body.get("room_code") or "").strip()
    if not r_code:
        return JSONResponse({"ok": False, "error": "کد اتاق (room_code) الزامی است."}, status_code=400)
    player_id = str(body.get("player_id") or body.get("player") or "")
    move_data = body.get("move") if "move" in body else body.get("action")
    state_update = body.get("state") if isinstance(body.get("state"), dict) else None
    next_turn = body.get("next_turn") or body.get("turn")
    t_eng0 = time.perf_counter()
    room = db.mp_sync_room(
        room_code=r_code,
        player_id=player_id,
        move_data=move_data,
        state_update=state_update,
        next_turn=next_turn,
    )
    engine_us = round((time.perf_counter() - t_eng0) * 1_000_000, 2)
    latency_ms = round((time.perf_counter() - t0) * 1000, 4)
    return JSONResponse({
        "ok": True,
        "room_code": room["room_code"],
        "room": room,
        "engine_latency_us": engine_us,
        "latency_ms": latency_ms,
        "region": "GLOBAL-UNFILTERED-ANY-IP",
    })


@app.get("/v1/game/state")
@app.get("/api/game/state")
@app.get("/v1/game/room/{room_code}")
async def api_mp_game_state(room_code: str = ""):
    t0 = time.perf_counter()
    code = str(room_code or "").strip()
    t_eng0 = time.perf_counter()
    room = db.mp_get_room(code)
    if not room:
        room = db.mp_create_room(room_code=code or "10001")
    engine_us = round((time.perf_counter() - t_eng0) * 1_000_000, 2)
    latency_ms = round((time.perf_counter() - t0) * 1000, 4)
    return JSONResponse({
        "ok": True,
        "room_code": room["room_code"],
        "room": room,
        "engine_latency_us": engine_us,
        "latency_ms": latency_ms,
        "region": "GLOBAL-UNFILTERED-ANY-IP",
    })


@app.get("/v1/game/rooms")
@app.get("/api/game/rooms")
async def api_mp_game_rooms():
    t0 = time.perf_counter()
    rooms = db.mp_list_rooms()
    latency_ms = round((time.perf_counter() - t0) * 1000, 4)
    return JSONResponse({
        "ok": True,
        "rooms": rooms,
        "count": len(rooms),
        "latency_ms": latency_ms,
    })


def _extract_srv_key(req: Request, body: dict = None) -> str:
    body = body or {}
    auth = req.headers.get("Authorization", "").replace("Bearer ", "").strip()
    if auth:
        return auth
    return str(body.get("api_key") or req.query_params.get("api_key") or "default").strip()


@app.get("/v1/game/rules")
@app.post("/v1/game/rules")
@app.get("/v1/messenger/rules")
@app.post("/v1/messenger/rules")
async def api_server_rules(req: Request):
    stype = "messenger" if "messenger" in req.url.path else "game"
    body = {}
    if req.method == "POST":
        try:
            body = await req.json()
        except Exception:
            body = {}
    key = _extract_srv_key(req, body)
    if req.method == "POST":
        r_text = str(body.get("rules_text") or body.get("rules_description") or "")
        r_json = body.get("rules") if isinstance(body.get("rules"), dict) else body
        cfg = db.set_server_rules(key, rules_text=r_text, rules_json=r_json, server_type=stype)
        return JSONResponse({"ok": True, "message": "قوانین سرور با موفقیت ثبت و اعمال شد.", "config": cfg})
    return JSONResponse({"ok": True, "config": db.get_server_config(key, stype)})


@app.get("/v1/game/collaborators")
@app.post("/v1/game/collaborators")
@app.get("/v1/messenger/collaborators")
@app.post("/v1/messenger/collaborators")
async def api_server_collaborators(req: Request):
    stype = "messenger" if "messenger" in req.url.path else "game"
    body = {}
    if req.method == "POST":
        try:
            body = await req.json()
        except Exception:
            body = {}
    key = _extract_srv_key(req, body)
    if req.method == "POST":
        c_name = str(body.get("name") or body.get("collaborator_name") or "AI Collaborator")
        c_role = str(body.get("role") or "همکار هوش مصنوعی")
        perms = body.get("permissions") if isinstance(body.get("permissions"), list) else ["read", "write", "rules", "connect", "admin"]
        cfg = db.add_server_collaborator(key, collab_name=c_name, collab_role=c_role, permissions=perms, server_type=stype)
        return JSONResponse({"ok": True, "message": f"همکار «{c_name}» با موفقیت به سرور اضافه شد.", "config": cfg})
    return JSONResponse({"ok": True, "config": db.get_server_config(key, stype)})


@app.get("/v1/game/connect")
@app.post("/v1/game/connect")
@app.get("/v1/messenger/connect")
@app.post("/v1/messenger/connect")
async def api_server_connect(req: Request):
    stype = "messenger" if "messenger" in req.url.path else "game"
    body = {}
    if req.method == "POST":
        try:
            body = await req.json()
        except Exception:
            body = {}
    key = _extract_srv_key(req, body)
    if req.method == "POST":
        t_name = str(body.get("name") or body.get("target_name") or "External Service")
        t_ep = str(body.get("endpoint") or body.get("url") or body.get("service") or "http://localhost:8080/v1")
        cfg = db.add_server_connector(key, target_name=t_name, target_endpoint=t_ep, config=body, server_type=stype)
        return JSONResponse({"ok": True, "message": f"اتصال به «{t_name}» ({t_ep}) برقرار و فعال شد.", "config": cfg})
    return JSONResponse({"ok": True, "config": db.get_server_config(key, stype)})


# ==================== MESSENGER SERVER REAL-TIME API (< 1 µs Engine) ====================

@app.post("/v1/messenger/send")
@app.post("/api/messenger/send")
async def api_messenger_send(req: Request):
    t0 = time.perf_counter()
    try:
        body = await req.json()
    except Exception:
        body = {}
    key = _extract_srv_key(req, body)
    channel_id = str(body.get("channel_id") or body.get("room_id") or "general")
    sender = str(body.get("sender") or body.get("user") or "User")
    text = str(body.get("text") or body.get("message") or "")
    t_eng0 = time.perf_counter()
    res = db.msg_send_message(
        channel_id=channel_id,
        sender=sender,
        text=text,
        api_key=key,
        attachments=body.get("attachments"),
        metadata=body.get("metadata"),
    )
    res["engine_latency_us"] = round((time.perf_counter() - t_eng0) * 1_000_000, 2)
    res["latency_ms"] = round((time.perf_counter() - t0) * 1000, 4)
    return JSONResponse(res, status_code=200 if res.get("ok") else 403)


@app.get("/v1/messenger/messages")
@app.get("/api/messenger/messages")
async def api_messenger_messages(req: Request, channel_id: str = "general", since_seq: int = 0):
    t0 = time.perf_counter()
    key = _extract_srv_key(req)
    t_eng0 = time.perf_counter()
    res = db.msg_get_messages(channel_id=channel_id, since_seq=since_seq, api_key=key)
    res["engine_latency_us"] = round((time.perf_counter() - t_eng0) * 1_000_000, 2)
    res["latency_ms"] = round((time.perf_counter() - t0) * 1000, 4)
    return JSONResponse(res)


@app.get("/v1/messenger/channels")
@app.get("/api/messenger/channels")
async def api_messenger_channels():
    t0 = time.perf_counter()
    channels = db.msg_list_channels()
    return JSONResponse({
        "ok": True,
        "channels": channels,
        "count": len(channels),
        "latency_ms": round((time.perf_counter() - t0) * 1000, 4),
    })


# ==================== 1-MICROSECOND HYPER-ENGINE BUS (< 1 µs) ====================

@app.get("/v1/hyper")
@app.post("/v1/hyper")
async def api_hyper_engine(req: Request, op: str = "get", key: str = "default"):
    body = {}
    if req.method == "POST":
        try:
            body = await req.json()
        except Exception:
            body = {}
        op = body.get("op") or op
        key = body.get("key") or body.get("room_code") or body.get("channel_id") or key
    val = body.get("value") or body.get("move") or body.get("state") or body.get("text")
    t_eng0 = time.perf_counter()
    res = db.hyper_exec(op, key, val)
    engine_us = round((time.perf_counter() - t_eng0) * 1_000_000, 3)
    return JSONResponse({
        "ok": True,
        "engine": "HYPER_L1_RAM_1US",
        "op": op,
        "key": key,
        "data": res,
        "engine_latency_us": engine_us,
    })


@app.get("/console/{api_key}", response_class=HTMLResponse)
@app.get("/v1/console/{api_key}", response_class=HTMLResponse)
async def server_dedicated_console_page(api_key: str):
    stype = "messenger" if "msg" in api_key else "game"
    cfg = db.get_server_config(api_key, stype)
    title = "پنل و کنسول اختصاصی سرور پیام‌رسان" if stype == "messenger" else "پنل و کنسول اختصاصی سرور بازی‌سازی"
    html = f"""<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>{title} | {api_key[:18]}...</title>
<style>
body{{font-family:system-ui,sans-serif;background:#050811;color:#f8fafc;margin:0;padding:20px}}
.wrap{{max-width:860px;margin:0 auto;background:#0f172a;border:1px solid #1e293b;border-radius:20px;padding:24px}}
h1{{margin:0 0 8px;font-size:20px;color:#38bdf8}}
.sub{{font-family:monospace;color:#34d399;font-size:13px;direction:ltr;display:inline-block;background:#020617;padding:6px 12px;border-radius:8px;margin-bottom:16px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:14px;margin-top:14px}}
.box{{background:#1e293b;border-radius:14px;padding:16px}}
.box h3{{margin:0 0 10px;font-size:15px;color:#fbbf24}}
textarea,input{{width:100%;background:#020617;border:1px solid #334155;color:#fff;border-radius:10px;padding:10px;margin-bottom:8px;box-sizing:border-box}}
button{{background:linear-gradient(135deg,#10b981,#059669);color:#fff;border:none;padding:10px 16px;border-radius:10px;font-weight:700;cursor:pointer;width:100%}}
pre{{background:#020617;padding:12px;border-radius:10px;overflow:auto;direction:ltr;font-size:12px;color:#a7f3d0}}
</style>
</head>
<body>
<div class="wrap">
<h1>⚡ {title} (کنترل قوانین، همکاران و اتصالات جهانی)</h1>
<div class="sub">API Key: {api_key} | Type: {stype.upper()}</div>
<div class="grid">
  <div class="box">
    <h3>📜 ۱. تعیین قوانین سرور (Server Rules)</h3>
    <textarea id="rules_txt" rows="3" placeholder="قوانین سرور را بنویسید...">{cfg.get('rules_text','')}</textarea>
    <button onclick="saveRules()">ثبت و اعمال قوانین در سرور</button>
  </div>
  <div class="box">
    <h3>🤝 ۲. افزودن همکار (Add Collaborator)</h3>
    <input id="c_name" placeholder="نام همکار یا ایجنت هوش مصنوعی">
    <input id="c_role" placeholder="نقش (مثلاً داور بازی / ادمین پیام‌رسان)">
    <button onclick="addCollab()">افزودن همکار جدید</button>
  </div>
  <div class="box">
    <h3>🔌 ۳. اتصال به هر سرویسی (Universal Connector)</h3>
    <input id="conn_name" placeholder="نام سرویس (ربات، دیتابیس، هوش مصنوعی...)">
    <input id="conn_ep" placeholder="آدرس اندپوینت یا کانال ارتباطی">
    <button onclick="addConn()">برقراری اتصال</button>
  </div>
</div>
<h3 style="margin-top:20px;color:#38bdf8">📡 وضعیت زنده سرور، قوانین، همکاران و اتصالات:</h3>
<pre id="live_json">{json.dumps(cfg, indent=2, ensure_ascii=False)}</pre>
</div>
<script>
const KEY = "{api_key}";
const BASE = "/v1/{stype}";
async function saveRules(){{
  const r = await fetch(BASE+"/rules",{{method:"POST",headers:{{"Content-Type":"application/json"}},body:JSON.stringify({{api_key:KEY,rules_text:document.getElementById("rules_txt").value}})}});
  const d = await r.json(); document.getElementById("live_json").textContent = JSON.stringify(d.config,null,2);
}}
async function addCollab(){{
  const r = await fetch(BASE+"/collaborators",{{method:"POST",headers:{{"Content-Type":"application/json"}},body:JSON.stringify({{api_key:KEY,name:document.getElementById("c_name").value,role:document.getElementById("c_role").value}})}});
  const d = await r.json(); document.getElementById("live_json").textContent = JSON.stringify(d.config,null,2);
}}
async function addConn(){{
  const r = await fetch(BASE+"/connect",{{method:"POST",headers:{{"Content-Type":"application/json"}},body:JSON.stringify({{api_key:KEY,name:document.getElementById("conn_name").value,endpoint:document.getElementById("conn_ep").value}})}});
  const d = await r.json(); document.getElementById("live_json").textContent = JSON.stringify(d.config,null,2);
}}
</script>
</body></html>"""
    return HTMLResponse(html)


@app.get("/v1/key")
async def v1_get_key_info():
    key = db.get_api_key()
    return JSONResponse({
        "api_key": key,
        "base_url": "http://localhost:8080/v1",
        "description": "Universal OpenAI-Compatible API Key for Arena AI (Unrestricted High-Speed Server)",
        "compatible_apps": ["NextChat", "LibreChat", "Chatbox", "OpenAI Python SDK", "LobeChat", "curl", "Android apps"],
        "models_count": len(ai_arena.ARENA_MODELS) + len(ai_arena.ARENA_IMAGE_MODELS),
    })


@app.get("/api/pk2/verify")
@app.post("/api/pk2/verify")
async def api_pk2_verify(req: Request, token: str = ""):
    if not token:
        try:
            body = await req.json()
            token = str(body.get("token") or "")
        except Exception:
            pass
    res = db.verify_pk2_token(token)
    return JSONResponse(res, status_code=200 if res.get("ok") else 403)


@app.get("/api/pk2/tokens")
async def api_pk2_list_tokens():
    return JSONResponse({"ok": True, "tokens": db.list_pk2_tokens()})


@app.post("/api/pk2/tokens")
async def api_pk2_create_token(req: Request):
    try:
        body = await req.json()
    except Exception:
        body = {}
    owner = str(body.get("owner_name") or "کاربر VIP پی کا تو").strip()
    t = db.create_pk2_token(owner_name=owner)
    return JSONResponse({"ok": True, "token": t})



DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل مدیریت ۲۴ ساعته Arena AI | چت، تصویرسازی و API</title>
    <script src="https://telegram.org/js/telegram-web-app.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Vazirmatn', sans-serif; background: #070b14; color: #f1f5f9; }
        .glass { background: rgba(15, 23, 42, 0.82); backdrop-filter: blur(12px); border: 1px solid rgba(255,255,255,0.08); }
        .pulse-dot { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); animation: pulse 2s infinite; }
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }
            70% { box-shadow: 0 0 0 10px rgba(16, 185, 129, 0); }
            100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
        }
    </style>
</head>
<body class="min-h-screen pb-12">
    <header class="border-b border-slate-800 bg-slate-900/70 sticky top-0 z-20 backdrop-blur-md">
        <div class="max-w-6xl mx-auto px-4 py-4 flex flex-wrap items-center justify-between gap-4">
            <div class="flex items-center gap-3">
                <div class="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-500 to-cyan-500 flex items-center justify-center text-2xl shadow-lg shadow-emerald-500/20">⚡</div>
                <div>
                    <h1 class="text-lg font-bold text-white flex items-center gap-2">
                        <span>پنل مدیریت سرور Arena AI (تلگرام + روبیکا + وب)</span>
                        <span class="text-xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2.5 py-0.5 rounded-full flex items-center gap-1.5">
                            <span class="w-2 h-2 rounded-full bg-emerald-400 pulse-dot"></span>
                            آنلاین ۲۴/۷
                        </span>
                    </h1>
                    <p class="text-xs text-slate-400 mt-0.5">
                        ربات تلگرام: <a id="bot-link" href="https://t.me/RazChat_NashenasBot" target="_blank" class="text-cyan-400 hover:underline font-mono" dir="ltr">@RazChat_NashenasBot</a>
                        | اتصال API باز: <span class="text-emerald-400 font-mono" dir="ltr">http://localhost:8080/v1</span>
                    </p>
                </div>
            </div>
            <div class="flex items-center gap-3">
                <div class="glass px-3.5 py-2 rounded-xl text-xs flex items-center gap-2">
                    <span class="text-slate-400">⏱ آپتایم سرور:</span>
                    <span id="uptime" class="font-mono font-bold text-emerald-400 text-sm" dir="ltr">00:00:00</span>
                </div>
                <button onclick="forceSyncModels()" class="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-lg shadow-cyan-500/20 transition">
                    🔄 بروزرسانی مدل‌ها
                </button>
            </div>
        </div>
    </header>

    <main class="max-w-6xl mx-auto px-4 mt-6 space-y-6">
        <!-- Stats Cards -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div class="glass p-4 rounded-2xl">
                <div class="text-xs text-slate-400">🧠 مدل‌های فعال چت و تصویر</div>
                <div id="stat-models" class="text-2xl font-extrabold text-emerald-400 mt-1">58</div>
                <div id="stat-sync-time" class="text-[11px] text-slate-400 mt-1">همگام‌سازی لحظه‌ای فعال</div>
            </div>
            <div class="glass p-4 rounded-2xl">
                <div class="text-xs text-slate-400">👥 کاربران ثبت‌شده</div>
                <div id="stat-users" class="text-2xl font-extrabold text-cyan-400 mt-1">0</div>
                <div class="text-[11px] text-slate-400 mt-1">پایگاه داده SQLite دائمی</div>
            </div>
            <div class="glass p-4 rounded-2xl">
                <div class="text-xs text-slate-400">💬 کل درخواست‌ها</div>
                <div id="stat-msgs" class="text-2xl font-extrabold text-indigo-400 mt-1">0</div>
                <div class="text-[11px] text-slate-400 mt-1">چت، تصویرساز و ایجنت</div>
            </div>
            <div class="glass p-4 rounded-2xl">
                <div class="text-xs text-slate-400">🎨 موتور تصویرسازی ارنا</div>
                <div class="text-lg font-extrabold text-amber-400 mt-1">FLUX 1.1 + MJ</div>
                <div class="text-[11px] text-emerald-400 mt-1">تولید تصویر آنی و HD</div>
            </div>
        </div>

        <!-- MULTI-KEY & ISOLATED PROJECT STUDIO SECTION -->
        <div class="glass rounded-2xl p-5 space-y-4 border-r-4 border-amber-500 shadow-xl">
            <div class="flex flex-wrap items-center justify-between gap-3">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center text-xl font-bold">🔑</div>
                    <div>
                        <h2 class="font-bold text-base text-white flex items-center gap-2">
                            <span>مدیریت کلیدها و پروژه‌های اختصاصی سرور (Multi-Key Project Studio)</span>
                            <span class="text-xs bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-mono">👑 اختصاصی @FilterNet3</span>
                            <span class="text-xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full">🔐 تفکیک ۱۰۰٪ پروژه‌ها</span>
                        </h2>
                        <p class="text-xs text-slate-400">شما می‌توانید به هر تعداد دلخواه کلید بسازید؛ <span class="text-amber-300 font-medium">هر کلید به یک پروژه کاملاً مجزا با کدهای ایزوله متصل می‌شود.</span></p>
                    </div>
                </div>
                <div class="text-xs text-slate-400 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-xl font-mono" id="keys-stat-badge">
                    تعداد کلیدها: در حال بارگذاری...
                </div>
            </div>

            <!-- Create New Key Form -->
            <div class="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3.5 space-y-3">
                <div class="flex flex-wrap items-center justify-between gap-2">
                    <div class="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                        <span>➕ ساخت کلید API جدید (با نام و پیشوند متفاوت و پروژه ایزوله):</span>
                    </div>
                    <button onclick="createColleagueKey()" class="bg-cyan-600/30 hover:bg-cyan-500/40 text-cyan-300 border border-cyan-500/40 font-bold text-xs px-3 py-1.5 rounded-xl transition flex items-center gap-1.5">
                        <span>👥 ساخت سریع کلید همکار (Colleague)</span>
                    </button>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-4 gap-3">
                    <input id="new-key-name" type="text" placeholder="نام کلید (یا خالی برای نام خودکار)" class="bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400">
                    <input id="new-key-project" type="text" placeholder="عنوان پروژه اختصاصی (اختیاری)" class="bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400">
                    <select id="new-key-role" class="bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-cyan-300 focus:outline-none focus:border-amber-400">
                        <option value="همکار">👥 نقش: همکار (Collaborator)</option>
                        <option value="ایجنت هوش مصنوعی">🤖 نقش: ایجنت هوش مصنوعی</option>
                        <option value="مدیر">👑 نقش: مدیر سیستم</option>
                    </select>
                    <button onclick="createNewKeyWithProject()" class="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-lg shadow-orange-500/20 transition flex items-center justify-center gap-2">
                        <span>✨ ساخت کلید و پروژه جدید</span>
                    </button>
                </div>
                <div id="key-create-toast" class="hidden text-xs text-emerald-400 font-semibold pt-1">✅ کلید جدید، نقش و پروژه اختصاصی آن با موفقیت در پایگاه داده ایجاد شد.</div>
            </div>

            <!-- Keys Table -->
            <div class="overflow-x-auto">
                <table class="w-full text-right text-xs">
                    <thead class="text-slate-400 border-b border-slate-800">
                        <tr>
                            <th class="pb-2.5 pr-2">نام کلید و کد اختصاصی</th>
                            <th class="pb-2.5">نقش</th>
                            <th class="pb-2.5">کلید API (Bearer Token)</th>
                            <th class="pb-2.5">پروژه متصل (ایزوله)</th>
                            <th class="pb-2.5">فایل‌ها</th>
                            <th class="pb-2.5">وضعیت و کنترل کلید</th>
                            <th class="pb-2.5">تاریخ ساخت / اتصال</th>
                            <th class="pb-2.5 text-center">عملیات</th>
                        </tr>
                    </thead>
                    <tbody id="keys-table-body" class="divide-y divide-slate-800/60 font-mono text-xs">
                        <tr><td colspan="8" class="text-center py-4 text-slate-500">در حال بارگذاری کلیدها...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>


        <!-- MODEL TOGGLE & MANAGEMENT PANEL -->
        <div class="glass rounded-2xl p-5 space-y-5 border-r-4 border-cyan-500">
            <div class="flex flex-wrap items-center justify-between gap-3">
                <div class="flex items-center gap-3">
                    <span class="text-2xl">⚙️</span>
                    <div>
                        <h2 class="font-bold text-base text-white">کنترل و مدیریت مدل‌های هوش مصنوعی (خاموش / روشن)</h2>
                        <p class="text-xs text-slate-400">با زدن دکمه خاموش/روشن، مدل بلافاصله در تلگرام و سرور غیرفعال یا فعال می‌شود.</p>
                    </div>
                </div>
                <div class="text-xs bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-xl font-mono text-cyan-300" id="models-summary">
                    در حال بارگذاری...
                </div>
            </div>

            <!-- Image Models Section -->
            <div>
                <h3 class="text-xs font-bold text-indigo-300 mb-3 flex items-center gap-2">
                    <span>🎨 مدل‌های اختصاصی تصویرساز Arena AI (Text-to-Image):</span>
                </h3>
                <div id="image-models-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3"></div>
            </div>

            <!-- Chat Models Section -->
            <div class="pt-2 border-t border-slate-800/80">
                <h3 class="text-xs font-bold text-cyan-300 mb-3 flex items-center gap-2">
                    <span>🧠 مدل‌های گفتگو و استدلال ارنا (Chat & Reasoning):</span>
                </h3>
                <div id="chat-models-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-96 overflow-y-auto p-1"></div>
            </div>
        </div>

        <!-- Direct Web Chat -->
        <div class="glass rounded-2xl p-5 space-y-4">
            <div class="flex items-center justify-between">
                <h2 class="font-bold text-base">💬 چت مستقیم تحت وب با Arena AI</h2>
                <select id="web-model" class="bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-cyan-300"></select>
            </div>
            <div id="chat-box" class="bg-slate-950/80 border border-slate-800 rounded-xl p-4 h-52 overflow-y-auto space-y-3 text-sm">
                <div class="text-slate-400 text-xs text-center py-6">پیام خود را بنویسید تا مستقیماً از طریق سرور پاسخ بگیرید...</div>
            </div>
            <div class="flex gap-2">
                <input id="web-prompt" type="text" placeholder="پیام را بنویسید..." class="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-500" onkeydown="if(event.key==='Enter') sendWebChat()">
                <button onclick="sendWebChat()" class="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2.5 rounded-xl text-xs transition">ارسال 🚀</button>
            </div>
        </div>

        <!-- DEVELOPER HUB & INTEGRATION METHODS SECTION -->
        <div class="glass rounded-2xl p-5 space-y-4 border-r-4 border-indigo-500">
            <div class="flex flex-wrap items-center justify-between gap-3">
                <div class="flex items-center gap-3">
                    <span class="text-2xl">👨‍💻</span>
                    <div>
                        <h2 class="font-bold text-base text-white">پورتال و مستندات توسعه‌دهندگان (Developer Hub)</h2>
                        <p class="text-xs text-slate-400">راهنمای اتصال کامل و کدهای اجرایی برای اتصال سرور به زبان‌ها و برنامه‌های مختلف (استاندارد OpenAI v1)</p>
                    </div>
                </div>
                <span class="text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-3 py-1 rounded-full font-mono">OpenAI Compatible v1</span>
            </div>

            <!-- Tab Buttons -->
            <div class="flex flex-wrap gap-2 border-b border-slate-800 pb-3" id="dev-tabs">
                <button onclick="switchDevTab('py')" id="tab-btn-py" class="dev-tab-btn active bg-indigo-600 text-white text-xs px-3.5 py-1.5 rounded-xl font-bold transition">🐍 پایتون (Python)</button>
                <button onclick="switchDevTab('js')" id="tab-btn-js" class="dev-tab-btn bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-3.5 py-1.5 rounded-xl font-bold transition">🟨 جاوااسکریپت (Node.js)</button>
                <button onclick="switchDevTab('cursor')" id="tab-btn-cursor" class="dev-tab-btn bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-3.5 py-1.5 rounded-xl font-bold transition">💻 نرم‌افزار Cursor & VS Code</button>
                <button onclick="switchDevTab('apps')" id="tab-btn-apps" class="dev-tab-btn bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-3.5 py-1.5 rounded-xl font-bold transition">📱 اپلیکیشن‌های آماده (NextChat)</button>
                <button onclick="switchDevTab('curl')" id="tab-btn-curl" class="dev-tab-btn bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-3.5 py-1.5 rounded-xl font-bold transition">🌐 درخواست مستقیم cURL</button>
                <button onclick="switchDevTab('projects')" id="tab-btn-projects" class="dev-tab-btn bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-3.5 py-1.5 rounded-xl font-bold transition">🚀 استودیو پروژه‌ها (API)</button>
                <button onclick="switchDevTab('cloud')" id="tab-btn-cloud" class="dev-tab-btn bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-3.5 py-1.5 rounded-xl font-bold transition">☁️ اتصال در کلود (Connection Refused Fix)</button>
            </div>

            <!-- Tab Contents -->
            <div id="dev-content-py" class="dev-tab-content bg-slate-950/80 rounded-xl p-4 border border-slate-800 font-mono text-xs text-slate-300 overflow-x-auto space-y-2">
                <div class="text-slate-400"># ۱. نصب کتابخانه رسمی OpenAI:</div>
                <div class="text-cyan-400 font-bold">pip install openai</div>
                <div class="text-slate-400 mt-2"># ۲. اجرای چت و استریم لایو با سرور:</div>
                <div class="text-emerald-300">from openai import OpenAI</div>
                <div class="text-emerald-300">client = OpenAI(base_url="http://localhost:8080/v1", api_key="sk-arena-your-key")</div>
                <div class="text-emerald-300">res = client.chat.completions.create(model="gpt-5.6-sol", messages=[{"role": "user", "content": "سلام!"}])</div>
                <div class="text-emerald-300">print(res.choices[0].message.content)</div>
            </div>

            <div id="dev-content-js" class="dev-tab-content hidden bg-slate-950/80 rounded-xl p-4 border border-slate-800 font-mono text-xs text-slate-300 overflow-x-auto space-y-2">
                <div class="text-slate-400">// npm install openai</div>
                <div class="text-cyan-400 font-bold">import OpenAI from "openai";</div>
                <div class="text-emerald-300">const client = new OpenAI({ baseURL: "http://localhost:8080/v1", apiKey: "sk-arena-your-key" });</div>
                <div class="text-emerald-300">const res = await client.chat.completions.create({ model: "gemini-2.5-pro", messages: [{ role: "user", content: "سلام!" }] });</div>
                <div class="text-emerald-300">console.log(res.choices[0].message.content);</div>
            </div>

            <div id="dev-content-cursor" class="dev-tab-content hidden bg-slate-950/80 rounded-xl p-4 border border-slate-800 text-xs text-slate-300 space-y-2">
                <div class="font-bold text-cyan-300">تنظیم Cursor IDE برای کدنویسی ۲۴ ساعته با سرور شخصی:</div>
                <div>۱. به منوی <code class="bg-slate-900 px-2 py-0.5 rounded text-amber-300">Settings -> Models</code> بروید.</div>
                <div>۲. تیک <code class="bg-slate-900 px-2 py-0.5 rounded text-emerald-400">Override OpenAI Base URL</code> را روشن کرده و مقدار <code class="bg-slate-900 px-2 py-0.5 rounded text-emerald-400">http://localhost:8080/v1</code> را بنویسید.</div>
                <div>۳. کلید سرور دریافتی از @FilterNet3 را در کادر API Key قرار دهید.</div>
                <div>۴. مدل دلخواه خود مانند <code class="bg-slate-900 px-2 py-0.5 rounded text-indigo-300">gpt-5.6-sol</code> یا <code class="bg-slate-900 px-2 py-0.5 rounded text-indigo-300">gemini-2.5-pro</code> را انتخاب کنید.</div>
            </div>

            <div id="dev-content-apps" class="dev-tab-content hidden bg-slate-950/80 rounded-xl p-4 border border-slate-800 text-xs text-slate-300 space-y-2">
                <div class="font-bold text-cyan-300">اتصال به اپلیکیشن‌های چت آماده (NextChat, Chatbox, LibreChat):</div>
                <div>• پلتفرم‌های پشتیبانی‌شده: اندروید، iOS، ویندوز، مک و لینوکس</div>
                <div>• در بخش تنظیمات اپلیکیشن، نوع سرویس‌دهنده را روی <code class="text-amber-300">OpenAI</code> بگذارید.</div>
                <div>• آدرس هاست را <code class="text-emerald-400">http://localhost:8080/v1</code> و کلید را وارد نمایید.</div>
            </div>

            <div id="dev-content-curl" class="dev-tab-content hidden bg-slate-950/80 rounded-xl p-4 border border-slate-800 font-mono text-xs text-slate-300 overflow-x-auto space-y-2">
                <div class="text-slate-400"># درخواست دریافت ۵۱ مدل فعال:</div>
                <div class="text-emerald-400">curl -s http://localhost:8080/v1/models -H "Authorization: Bearer sk-arena-your-key"</div>
                <div class="text-slate-400 mt-2"># درخواست چت مستقیم:</div>
                <div class="text-cyan-400">curl -s http://localhost:8080/v1/chat/completions \</div>
                <div class="text-cyan-400">  -H "Authorization: Bearer sk-arena-your-key" \</div>
                <div class="text-cyan-400">  -H "Content-Type: application/json" \</div>
                <div class="text-cyan-400">  -d '{"model": "gpt-5.6-sol", "messages": [{"role": "user", "content": "سلام"}]}'</div>
            </div>

            <div id="dev-content-projects" class="dev-tab-content hidden bg-slate-950/80 rounded-xl p-4 border border-slate-800 font-mono text-xs text-slate-300 overflow-x-auto space-y-2">
                <div class="text-slate-400"># ساخت پروژه جدید با هوش مصنوعی:</div>
                <div class="text-emerald-400">curl -s -X POST http://localhost:8080/api/projects \</div>
                <div class="text-emerald-400">  -H "Content-Type: application/json" \</div>
                <div class="text-emerald-400">  -d '{"name": "Crypto Bot", "description": "ربات ترید", "prompt": "کد کامل ربات اسکلپ"}'</div>
                <div class="text-slate-400 mt-2"># تولید خودکار کدهای معماری پروژه:</div>
                <div class="text-cyan-400">curl -s -X POST http://localhost:8080/api/projects/&lt;PROJECT_ID&gt;/generate</div>
            </div>

            <div id="dev-content-cloud" class="dev-tab-content hidden bg-slate-950/80 rounded-xl p-4 border border-slate-800 text-xs text-slate-300 space-y-3">
                <div class="font-bold text-amber-300 text-sm">💡 دلیل خطای Connection Refused در هوش مصنوعی‌های کلود:</div>
                <div class="text-slate-300 leading-relaxed">
                    هنگامی که یک هوش مصنوعی در یک سرور ابری مجزا (مثل ChatGPT، Claude، یا کانتینرهای ابری) اجرا می‌شود، آدرس <code class="text-rose-400 bg-slate-900 px-1.5 py-0.5 rounded font-mono">localhost:8080</code> به سیستم خود آن هوش مصنوعی برمی‌گردد نه سرور شما.
                </div>
                <div class="font-bold text-cyan-300">✅ راه‌حل ۱: پل ارتباطی ابری تلگرام (Telegram Cloud Bridge - فعال ۲۴/۷):</div>
                <div class="text-slate-400">تمام هوش‌های مصنوعی ابری در جهان به سرورهای رسمی تلگرام دسترسی آزاد دارند. هوش مصنوعی دیگر می‌تواند از طریق API جهانی تلگرام با ربات شما ارتباط بگیرد:</div>
                <div class="bg-slate-900 p-3 rounded-lg font-mono text-[11px] text-emerald-300 overflow-x-auto space-y-1">
                    <div class="text-slate-400"># درخواست پیام مستقیم به ربات توسط هوش مصنوعی دیگر:</div>
                    <div class="text-cyan-300">curl -s -X POST "https://api.telegram.org/bot/sendMessage" \</div>
                    <div class="text-cyan-300">  -d "chat_id=YOUR_USER_ID" \</div>
                    <div class="text-cyan-300">  -d "text=/newproject سیستم فروشگاهی خودکار"</div>
                </div>
                <div class="font-bold text-indigo-300 pt-1">✅ راه‌حل ۲: استقرار رایگان در کلود با دامنه پابلیک اینترنتی (Render.com):</div>
                <div class="text-slate-400">فایل‌های <code class="text-emerald-400 font-mono">Dockerfile</code> و <code class="text-emerald-400 font-mono">render.yaml</code> در گیت‌هاب آماده است؛ با ساخت یک اکانت رایگان در Render.com و اتصال مخزن، یک آدرس پابلیک دائمی آمریکا مانند <code class="text-cyan-400 font-mono">https://my-arena.onrender.com/v1</code> دریافت می‌کنید که بدون هیچ مشکلی به تمام هوش‌های مصنوعی کلود متصل خواهد شد.</div>
            </div>
        </div>

        <!-- Live Logs -->
        <div class="glass rounded-2xl p-5">
            <div class="flex items-center justify-between mb-4">
                <h2 class="font-bold text-base">📊 گزارش زنده درخواست‌های سرور (تلگرام و وب)</h2>
                <span class="text-xs text-emerald-400">بروزرسانی خودکار هر ۳ ثانیه</span>
            </div>
            <div class="overflow-x-auto max-h-64">
                <table class="w-full text-right text-xs">
                    <thead class="text-slate-400 border-b border-slate-800">
                        <tr>
                            <th class="pb-2">زمان</th>
                            <th class="pb-2">حالت</th>
                            <th class="pb-2">مدل</th>
                            <th class="pb-2">کاربر</th>
                            <th class="pb-2">پیام</th>
                        </tr>
                    </thead>
                    <tbody id="logs-body" class="divide-y divide-slate-800/60"></tbody>
                </table>
            </div>
        </div>
    </main>

    <script>
        // Telegram Mini App (Web App) Native Integration
        if (window.Telegram && window.Telegram.WebApp) {
            try {
                window.Telegram.WebApp.ready();
                window.Telegram.WebApp.expand();
            } catch(e) {}
        }
        function switchDevTab(tab) {
            document.querySelectorAll('.dev-tab-btn').forEach(b => {
                b.classList.remove('bg-indigo-600', 'text-white');
                b.classList.add('bg-slate-800', 'text-slate-300');
            });
            const activeBtn = document.getElementById('tab-btn-' + tab);
            if (activeBtn) {
                activeBtn.classList.add('bg-indigo-600', 'text-white');
                activeBtn.classList.remove('bg-slate-800', 'text-slate-300');
            }
            document.querySelectorAll('.dev-tab-content').forEach(c => c.classList.add('hidden'));
            const content = document.getElementById('dev-content-' + tab);
            if (content) content.classList.remove('hidden');
        }

        let modelsLoaded = false;
        async function fetchOverview() {
            try {
                const res = await fetch('/api/overview');
                const data = await res.json();
                document.getElementById('uptime').textContent = data.uptime;
                document.getElementById('stat-models').textContent = (data.models_count || 0) + ((data.image_models || []).length);
                document.getElementById('stat-users').textContent = data.bot_users_count || 0;
                document.getElementById('stat-msgs').textContent = data.total_messages || 0;
                if (data.api_key) {
                    document.getElementById('api-key-input').value = data.api_key;
                }
                if (data.model_sync && data.model_sync.last_check) {
                    document.getElementById('stat-sync-time').textContent = 'بروزرسانی: ' + data.model_sync.last_check;
                }

                // Render Image Models
                const imgGrid = document.getElementById('image-models-grid');
                if (data.image_models && imgGrid) {
                    imgGrid.innerHTML = data.image_models.map(m => {
                        const isDis = m.disabled;
                        return `
                        <div class="p-3 rounded-xl border ${isDis ? 'bg-slate-900/40 border-rose-900/40 opacity-70' : 'bg-slate-900/90 border-slate-800'} flex items-center justify-between gap-2">
                            <div>
                                <div class="text-xs font-bold ${isDis ? 'text-slate-400 line-through' : 'text-slate-100'}">${m.name}</div>
                                <div class="text-[10px] text-slate-400 mt-0.5">${m.desc || ''}</div>
                                <div class="mt-1">
                                    <span class="text-[10px] px-2 py-0.5 rounded-full font-bold ${isDis ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'}">
                                        ${isDis ? 'خاموش ❌' : 'فعال ✅'}
                                    </span>
                                </div>
                            </div>
                            <button onclick="toggleModel('${m.key}')" class="text-xs font-bold px-3 py-1.5 rounded-lg transition ${isDis ? 'bg-emerald-600 hover:bg-emerald-500 text-white' : 'bg-rose-600/80 hover:bg-rose-500 text-white'}">
                                ${isDis ? 'روشن کردن' : 'خاموش کردن'}
                            </button>
                        </div>
                        `;
                    }).join('');
                }

                // Render Chat Models
                const chatGrid = document.getElementById('chat-models-grid');
                let activeCount = 0;
                let disabledCount = 0;
                if (data.models_list && chatGrid) {
                    chatGrid.innerHTML = data.models_list.map(m => {
                        const isDis = m.disabled;
                        if (isDis) disabledCount++; else activeCount++;
                        return `
                        <div class="p-2.5 rounded-xl border ${isDis ? 'bg-slate-900/40 border-rose-900/40 opacity-70' : 'bg-slate-900/80 border-slate-800'} flex items-center justify-between gap-2">
                            <div class="truncate">
                                <div class="text-xs font-semibold ${isDis ? 'text-slate-400 line-through' : 'text-slate-200'} truncate">${m.name}</div>
                                <span class="text-[10px] px-1.5 py-0.2 rounded font-bold ${isDis ? 'text-rose-400' : 'text-emerald-400'}">
                                    ${isDis ? 'خاموش ❌' : 'فعال ✅'}
                                </span>
                            </div>
                            <button onclick="toggleModel('${m.key}')" class="text-[11px] font-bold px-2.5 py-1 rounded-lg transition shrink-0 ${isDis ? 'bg-emerald-600 hover:bg-emerald-500 text-white' : 'bg-slate-800 hover:bg-rose-600 text-slate-300'}">
                                ${isDis ? 'روشن' : 'خاموش'}
                            </button>
                        </div>
                        `;
                    }).join('');
                    document.getElementById('models-summary').textContent = `${activeCount} مدل فعال | ${disabledCount} مدل خاموش`;

                    const sel = document.getElementById('web-model');
                    if (!modelsLoaded) {
                        sel.innerHTML = data.models_list.filter(m => !m.disabled).map(m => `<option value="${m.key}">${m.btn}</option>`).join('');
                        modelsLoaded = true;
                    }
                }

                const lb = document.getElementById('logs-body');
                lb.innerHTML = (data.logs || []).map(l => `<tr class="hover:bg-slate-800/30">
                    <td class="py-2 font-mono text-slate-400" dir="ltr">${l.timestamp}</td>
                    <td class="py-2"><span class="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-300">${l.level}</span></td>
                    <td class="py-2 text-emerald-300 font-mono">${l.chat_title}</td>
                    <td class="py-2 font-medium text-white">${l.event}</td>
                    <td class="py-2 text-slate-400">${l.details}</td>
                </tr>`).join('');
            } catch (e) {}
        }

        async function loadApiKeys() {
            try {
                const res = await fetch('/api/keys');
                const data = await res.json();
                if (data.ok && data.keys) {
                    const badge = document.getElementById('keys-stat-badge');
                    if (badge) badge.textContent = `تعداد کلیدها: ${data.keys.length} | پروژه‌ها: ${data.keys.length}`;
                    const tbody = document.getElementById('keys-table-body');
                    if (!tbody) return;
                    if (data.keys.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4 text-slate-500">هیچ کلیدی یافت نشد. می‌توانید با فرم بالا کلید جدید بسازید.</td></tr>';
                        return;
                    }
                    tbody.innerHTML = data.keys.map((k, idx) => {
                        const masked = k.key.substring(0, 12) + '••••••••••••' + k.key.substring(k.key.length - 4);
                        const role = k.role || 'همکار';
                        let roleBadge = '<span class="bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 px-2 py-0.5 rounded-full text-[10px]">👥 همکار</span>';
                        if (role === 'مدیر' || k.key.startsWith('sk-arena-iran-master')) {
                            roleBadge = '<span class="bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full text-[10px]">👑 مدیر</span>';
                        } else if (role === 'ایجنت هوش مصنوعی') {
                            roleBadge = '<span class="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded-full text-[10px]">🤖 ایجنت هوش</span>';
                        }
                        const isAct = k.is_active === 1 || k.is_active === undefined;
                        return `
                        <tr class="hover:bg-slate-800/40 transition ${!isAct ? 'opacity-60 bg-slate-950/40' : ''}">
                            <td class="py-3 pr-2 font-bold text-slate-200">
                                <div>${k.name}</div>
                                <span class="text-[10px] text-slate-400 font-mono">${k.key.split('-')[1] || 'key'}</span>
                            </td>
                            <td class="py-3">${roleBadge}</td>
                            <td class="py-3">
                                <div class="flex items-center gap-1.5 font-mono text-emerald-400">
                                    <span id="key-text-${idx}" data-full="${k.key}">${masked}</span>
                                    <button onclick="toggleKeyText(${idx})" class="text-slate-400 hover:text-slate-200 text-[11px] p-1" title="نمایش/پنهان">👁️</button>
                                    <button onclick="copyRawKey('${k.key}')" class="bg-slate-800 hover:bg-slate-700 text-[11px] text-slate-300 px-2 py-0.5 rounded border border-slate-700 transition" title="کپی کلید">📋 کپی</button>
                                </div>
                            </td>
                            <td class="py-3">
                                <div class="font-sans font-semibold text-cyan-300">${k.project_name}</div>
                                <div class="text-[10px] text-slate-400 font-mono">ID: ${k.project_id}</div>
                            </td>
                            <td class="py-3">
                                <span class="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded-full text-[10px] font-sans">
                                    ${k.files_count} فایل
                                </span>
                            </td>
                            <td class="py-3">
                                <div class="flex items-center gap-2 font-sans">
                                    <span class="text-[10px] font-bold ${isAct ? 'text-emerald-400' : 'text-rose-400'}">
                                        ${isAct ? '🟢 روشن' : '🔴 خاموش'}
                                    </span>
                                    ${k.key.startsWith('sk-arena-iran-master') ? '' : `
                                    <button onclick="toggleKeyActive('${k.key}')" class="text-[10px] font-bold px-2 py-0.5 rounded border transition ${isAct ? 'bg-rose-500/20 border-rose-500/30 text-rose-300 hover:bg-rose-500/40' : 'bg-emerald-500/20 border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/40'}">
                                        ${isAct ? 'خاموش کردن ⏸️' : 'روشن کردن ▶️'}
                                    </button>
                                    `}
                                </div>
                            </td>
                            <td class="py-3 text-slate-400 text-[11px]">
                                <div>ایجاد: ${k.created_at || '-'}</div>
                                <div class="text-[10px] text-slate-500">اتصال: ${k.last_used || '-'}</div>
                            </td>
                            <td class="py-3 text-center">
                                ${k.key.startsWith('sk-arena-iran-master') ? '<span class="text-[10px] text-slate-500">مستر</span>' : `
                                <button onclick="deleteKey('${k.key}')" class="bg-rose-500/20 hover:bg-rose-500/40 text-rose-300 border border-rose-500/30 text-[11px] px-2.5 py-1 rounded-lg transition">🗑️</button>
                                `}
                            </td>
                        </tr>
                        `;
                    }).join('');
                }
            } catch (e) {
                console.error("Error loading keys:", e);
            }
        }

        async function toggleKeyActive(key) {
            try {
                const res = await fetch('/api/keys/toggle', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({key: key})
                });
                const data = await res.json();
                if (data.ok) {
                    await loadApiKeys();
                } else {
                    alert('خطا در تغییر وضعیت کلید: ' + (data.error || 'خطا'));
                }
            } catch (e) {
                alert('خطا در ارتباط با سرور: ' + e);
            }
        }

        async function createColleagueKey() {
            try {
                const res = await fetch('/api/keys', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({role: 'همکار'})
                });
                const data = await res.json();
                if (data.ok) {
                    const toast = document.getElementById('key-create-toast');
                    if (toast) {
                        toast.textContent = `✅ کلید همکار جدید با نام «${data.key.name}» و شناسه پروژه اختصاصی ساخته شد.`;
                        toast.classList.remove('hidden');
                        setTimeout(() => toast.classList.add('hidden'), 5000);
                    }
                    await loadApiKeys();
                }
            } catch (e) {
                alert('خطا در ساخت کلید همکار: ' + e);
            }
        }

        function toggleKeyText(idx) {
            const el = document.getElementById('key-text-' + idx);
            if (!el) return;
            const full = el.getAttribute('data-full');
            const masked = full.substring(0, 12) + '••••••••••••' + full.substring(full.length - 4);
            if (el.textContent === masked) {
                el.textContent = full;
            } else {
                el.textContent = masked;
            }
        }

        function copyRawKey(k) {
            navigator.clipboard.writeText(k);
            alert('کلید API اختصاصی کپی شد!\n' + k);
        }

        async function createNewKeyWithProject() {
            const nameInput = document.getElementById('new-key-name');
            const projInput = document.getElementById('new-key-project');
            const roleSelect = document.getElementById('new-key-role');
            const keyName = nameInput.value.trim();
            const projName = projInput.value.trim();
            const role = roleSelect ? roleSelect.value : 'همکار';
            try {
                const res = await fetch('/api/keys', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({name: keyName, project_name: projName, role: role})
                });
                const data = await res.json();
                if (data.ok) {
                    nameInput.value = '';
                    projInput.value = '';
                    const toast = document.getElementById('key-create-toast');
                    if (toast) {
                        toast.textContent = `✅ کلید جدید «${data.key.name}» (${role}) با موفقیت ایجاد گردید.`;
                        toast.classList.remove('hidden');
                        setTimeout(() => toast.classList.add('hidden'), 5000);
                    }
                    await loadApiKeys();
                } else {
                    alert('خطا در ساخت کلید: ' + (data.error || 'خطای سرور'));
                }
            } catch (e) {
                alert('خطا در ارتباط با سرور: ' + e);
            }
        }

        async function deleteKey(key) {
            if (!confirm('آیا مطمئن هستید که می‌خواهید این کلید را حذف کنید؟ این کلید دیگر قادر به اتصال به سرور نخواهد بود.')) return;
            try {
                const res = await fetch('/api/keys/' + encodeURIComponent(key), {method: 'DELETE'});
                const data = await res.json();
                if (data.ok) {
                    await loadApiKeys();
                }
            } catch (e) {
                alert('خطا در حذف کلید: ' + e);
            }
        }

        async function toggleModel(modelKey) {
            try {
                const res = await fetch('/api/models/toggle', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({model_key: modelKey})
                });
                const data = await res.json();
                if (data.ok) {
                    fetchOverview();
                }
            } catch (e) {
                alert('خطا در تغییر وضعیت مدل: ' + e);
            }
        }

        async function forceSyncModels() {
            await fetch('/api/sync_models', {method: 'POST'});
            modelsLoaded = false;
            await fetchOverview();
        }

        async function sendWebChat() {
            const inp = document.getElementById('web-prompt');
            const box = document.getElementById('chat-box');
            const model = document.getElementById('web-model').value;
            const text = inp.value.trim();
            if (!text) return;
            inp.value = '';
            box.innerHTML += `<div class="text-right"><span class="inline-block bg-cyan-600/30 border border-cyan-500/40 text-white px-3 py-1.5 rounded-xl">${text}</span></div>`;
            box.scrollTop = box.scrollHeight;
            const res = await fetch('/api/web_chat', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({prompt: text, model: model})
            });
            const data = await res.json();
            if (data.ok) {
                box.innerHTML += `<div class="text-right"><div class="inline-block bg-slate-800 border border-slate-700 text-slate-100 px-3.5 py-2 rounded-xl whitespace-pre-wrap">${data.answer}</div></div>`;
            }
            box.scrollTop = box.scrollHeight;
            fetchOverview();
        }

        fetchOverview();
        loadApiKeys();
        setInterval(fetchOverview, 3000);
        setInterval(loadApiKeys, 5000);
    </script>
</body>
</html>
"""


@app.get("/", response_class=HTMLResponse)
async def dashboard():
    return DASHBOARD_HTML


if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8080))
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="info")
