"""
=============================================================================
پل اتصال ربات روبیکا به هوش مصنوعی Arena AI (مخصوص داخل ایران - بدون فیلترشکن)
=============================================================================
این اسکریپت ساده را می‌توانید روی گوشی (با برنامه Termux یا Pydroid 3) یا کامپیوتر در ایران اجرا کنید.
چون این اسکریپت از داخل ایران اجرا می‌شود، فایروال روبیکا آن را مسدود نمی‌کند و پیام‌های روبیکا را
دریافت کرده و مستقیم از سرور هوش مصنوعی پاسخ گرفته و در روبیکا ارسال می‌کند!

نحوه اجرا:
1) نصب کتابخانه: pip install requests
2) اجرا: python rubika_iran_bridge.py
"""

import time
import requests

TOKEN = ""
RUBIKA_URL = f"https://botapi.rubika.ir/v3/{TOKEN}"
SERVER_API = "http://localhost:8080/api/web_chat"  # یا آدرس سرور خارجی

print("🚀 پل اتصال روبیکا به هوش مصنوعی Arena AI آغاز شد...")

offset_id = ""
while True:
    try:
        payload = {"limit": 10}
        if offset_id:
            payload["offset_id"] = offset_id
        r = requests.post(f"{RUBIKA_URL}/getUpdates", json=payload, timeout=10)
        if r.status_code == 200:
            data = r.json().get("data") or r.json()
            updates = data.get("updates", [])
            for u in updates:
                chat_id = u.get("chat_id")
                new_msg = u.get("new_message") or {}
                text = str(new_msg.get("text") or "").strip()
                if chat_id and text and str(new_msg.get("sender_type", "")).lower() != "bot":
                    print(f"📩 پیام جدید از {chat_id}: {text}")
                    # ارسال به هوش مصنوعی سرور
                    ai_res = requests.post(SERVER_API, json={"prompt": text, "user_id": f"rubika_{chat_id}"}, timeout=25)
                    ans = ai_res.json().get("answer", "پاسخی دریافت نشد.")
                    # ارسال پاسخ به روبیکا
                    requests.post(f"{RUBIKA_URL}/sendMessage", json={"chat_id": chat_id, "text": ans[:4000]}, timeout=10)
                    print(f"✅ پاسخ در روبیکا ارسال شد: {ans[:60]}...")
            if data.get("next_offset_id"):
                offset_id = str(data["next_offset_id"])
    except Exception as e:
        pass
    time.sleep(2)
