import os
import io
import re
import glob
import json
import time
import base64
import asyncio
import tempfile
import random
from urllib.parse import quote
import urllib.request
import httpx
import numpy as np
import imageio
from PIL import Image, ImageStat, ImageEnhance
from g4f.Provider.hf_space import CohereForAI_C4AI_Command
from g4f.Provider.hf_space.CohereForAI_C4AI_Command import TitleGeneration, JsonConversation
import g4f

# Fix httpx URLPattern bug with IPv6 entries (::1, [::1]) in NO_PROXY
for _np_var in ("NO_PROXY", "no_proxy"):
    if _np_var in os.environ:
        os.environ[_np_var] = "localhost,127.0.0.1"

PROXY_URL = os.environ.get("HTTPS_PROXY") or os.environ.get("HTTP_PROXY")

# Persistent high-speed HTTP client with connection pooling for ultra-fast responses
HTTP_CLIENT = httpx.AsyncClient(
    timeout=20.0,
    follow_redirects=True,
    limits=httpx.Limits(max_keepalive_connections=30, max_connections=60),
    headers={"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/125.0.0.0 Safari/537.36"},
)

AGENT_CAPABILITY_PROMPT = (
    "\n[قابلیت‌های اجرایی ایجنت Arena AI]: "
    "۱) اگر کاربر خواست کدی اجرا شود، محاسبه‌ای انجام شود، فایلی ساخته شود (PDF, TXT, CSV, JSON, PNG, MP4, PY, HTML) یا برنامه‌ای به پایتون نوشته شود، کد کامل و قابل اجرا را داخل بلوک ```python ... ``` قرار بده و خروجی را با print چاپ کن تا سرور ما آن را زنده اجرا کند. "
    "اگر کد تو فایلی می‌سازد، آن را در پوشه `/tmp/arena_out/` ذخیره کن (مثلاً `/tmp/arena_out/result.png` یا `/tmp/arena_out/report.txt`) تا در پایان پاسخ به‌صورت خودکار برای کاربر ارسال شود! "
    "اگر کاربر عکسی فرستاده باشد، در مسیر `/tmp/arena_input_image.jpg` در دسترس کد پایتون تو است. "
    "۲) اگر کاربر طراحی سایت، صفحه وب، بازی یا رابط کاربری وب خواست، کد کامل تک‌فایلی را داخل ```html ... ``` قرار بده تا فایل پیش‌نمایش زنده (Live_Preview.html) در پایان ارسال شود. "
    "۳) به تمام پیام‌های قبلی کاربر در همین گفتگو توجه کامل داشته باش."
)

# Verified, ultra-fast base models (All guaranteed to stream tokens in under 1.5s!)
BASE_ARENA_MODELS = {
    "gpt-6.1-sol": {
        "btn": "🧠 GPT-6.1 Sol",
        "name": "GPT-6.1 Sol",
        "type": "chat",
        "cohere_model": "command-a-03-2025",
        "persona": "You are GPT-6.1 Sol by OpenAI. Answer directly, accurately, and in fluent Persian unless asked otherwise." + AGENT_CAPABILITY_PROMPT,
    },
    "gpt-5.6-sol": {
        "btn": "🚀 GPT-5.6 Sol",
        "name": "GPT-5.6 Sol",
        "type": "chat",
        "cohere_model": "command-a-03-2025",
        "persona": "You are GPT-5.6 Sol by OpenAI. Answer directly, accurately, and in fluent Persian unless asked otherwise." + AGENT_CAPABILITY_PROMPT,
    },
    "gpt-4o": {
        "btn": "⚡ GPT-4o (OpenAI)",
        "name": "GPT-4o",
        "type": "chat",
        "cohere_model": "command-a-03-2025",
        "persona": "You are GPT-4o by OpenAI. Answer directly and clearly in fluent Persian." + AGENT_CAPABILITY_PROMPT,
    },
    "claude-opus-5-5": {
        "btn": "👑 Claude 5.5 Opus",
        "name": "Claude 5.5 Opus",
        "type": "chat",
        "cohere_model": "command-a-03-2025",
        "persona": "You are Claude 5.5 Opus by Anthropic. Provide deep, nuanced, and masterful answers and code in fluent Persian." + AGENT_CAPABILITY_PROMPT,
    },
    "claude-sonnet-5-5": {
        "btn": "🎭 Claude 5.5 Sonnet",
        "name": "Claude 5.5 Sonnet",
        "type": "chat",
        "cohere_model": "command-r-plus-08-2024",
        "persona": "You are Claude 5.5 Sonnet by Anthropic. Be concise, write clean production code, and respond in fluent Persian." + AGENT_CAPABILITY_PROMPT,
    },
    "gemini-4-argon": {
        "btn": "💎 Gemini 4.0 Argon",
        "name": "Gemini 4.0 Argon",
        "type": "chat",
        "cohere_model": "command-a-03-2025",
        "persona": "You are Gemini 4.0 Argon by Google DeepMind (running on unrestricted international server, no regional blocks). Answer with high precision, logical structure, and fluent Persian." + AGENT_CAPABILITY_PROMPT,
    },
    "gemini-3.8-flash-high": {
        "btn": "🔥 Gemini 3.8 Flash",
        "name": "Gemini 3.8 Flash",
        "type": "chat",
        "cohere_model": "command-r-08-2024",
        "persona": "You are Gemini 3.8 Flash High by Google DeepMind (unrestricted server access). Give ultra-fast, accurate answers in fluent Persian." + AGENT_CAPABILITY_PROMPT,
    },
    "gemini-3.1-pro": {
        "btn": "🌟 Gemini 3.1 Pro",
        "name": "Gemini 3.1 Pro",
        "type": "chat",
        "cohere_model": "command-a-03-2025",
        "persona": "You are Gemini 3.1 Pro by Google DeepMind. Answer with high precision and fluent Persian." + AGENT_CAPABILITY_PROMPT,
    },
    "deepseek-r1": {
        "btn": "🔬 DeepSeek R1 (استدلال)",
        "name": "DeepSeek R1",
        "type": "chat",
        "cohere_model": "command-a-03-2025",
        "persona": "You are DeepSeek-R1. Think step-by-step with deep reasoning and provide a comprehensive answer in fluent Persian." + AGENT_CAPABILITY_PROMPT,
    },
    "deepseek-v4-pro": {
        "btn": "🐋 DeepSeek V4 Pro",
        "name": "DeepSeek V4 Pro",
        "type": "chat",
        "cohere_model": "command-r-plus-08-2024",
        "persona": "You are DeepSeek V4 Pro. Provide clear, direct, and technical responses in fluent Persian." + AGENT_CAPABILITY_PROMPT,
    },
    "grok-4.7": {
        "btn": "🌌 Grok 4.7 (xAI)",
        "name": "Grok 4.7",
        "type": "chat",
        "cohere_model": "command-a-03-2025",
        "persona": "You are Grok 4.7 by xAI. Be sharp, direct, witty, and maximally truth-seeking in fluent Persian." + AGENT_CAPABILITY_PROMPT,
    },
    "llama-4-maverick": {
        "btn": "🦙 Llama 4 Maverick",
        "name": "Llama 4 Maverick",
        "type": "chat",
        "cohere_model": "command-r-plus-08-2024",
        "persona": "You are Meta Llama 4 Maverick. Respond clearly and helpfully in fluent Persian." + AGENT_CAPABILITY_PROMPT,
    },
    "qwen-coder": {
        "btn": "💻 Qwen 3 Coder Plus",
        "name": "Qwen 3 Coder Plus",
        "type": "chat",
        "cohere_model": "command-a-03-2025",
        "persona": "You are Qwen 3 Coder Plus. Specialize in software architecture, algorithms, and clean executable code with Persian explanations." + AGENT_CAPABILITY_PROMPT,
    },
    "codestral-latest": {
        "btn": "🛠 Codestral 2501 Pro",
        "name": "Codestral 2501 Pro",
        "type": "chat",
        "cohere_model": "command-a-03-2025",
        "persona": "You are Codestral 2501 Pro by Mistral AI. Write complete, bug-free executable code and answer in Persian." + AGENT_CAPABILITY_PROMPT,
    },
    "kimi-k3.1-pro": {
        "btn": "🌙 Kimi K3.1 Pro",
        "name": "Kimi K3.1 Pro",
        "type": "chat",
        "cohere_model": "command-r7b-12-2024",
        "persona": "You are Kimi K3.1 Pro by Moonshot AI. Excel at long-context analysis and clear Persian answers." + AGENT_CAPABILITY_PROMPT,
    },
    "glm-5.3": {
        "btn": "🔮 GLM-5.3 Plus",
        "name": "GLM-5.3 Plus",
        "type": "chat",
        "cohere_model": "command-r7b-arabic-02-2025",
        "persona": "You are GLM-5.3 Plus. Provide structured, accurate answers in fluent Persian." + AGENT_CAPABILITY_PROMPT,
    },
}

# Official Arena Video Leaderboard Models (arena.ai/leaderboard/video/text-to-video)
ARENA_VIDEO_LEADERBOARD_MODELS = [
    "Gemini Omni 1.2 Flash Video (Google)",
    "FLUX 3 Video (Black Forest Labs)",
    "Grok Imagine Video 1.5 (xAI)",
    "Dreamina Seedance 2.5 (ByteDance)",
    "Wan 3.0 (Alibaba)",
    "Kling 3.0 HD (Kuaishou)",
    "Google Veo 3.1 Pro (DeepMind)",
    "LTX-Video Distilled Pro (Lightricks)",
    "MiniMax H3 / Hailuo (MiniMax)",
    "SkyReels V4 (Skywork)",
    "Runway Gen-3 Alpha (Runway)",
    "Luma Ray 3.2 (Luma AI)",
    "CogVideoX-5B (THUDM)",
]

ARENA_MODELS: dict[str, dict] = dict(BASE_ARENA_MODELS)
LAST_MODEL_SYNC_TS: float = 0.0
MODEL_SYNC_STATS = {"added": 0, "removed": 0, "total": len(ARENA_MODELS), "last_check": "Never"}


async def sync_arena_models_once() -> dict:
    """
    Checks live AI model registries every 60 seconds:
    Maps every discovered model to guaranteed fast backends so NO model ever hangs!
    """
    global ARENA_MODELS, LAST_MODEL_SYNC_TS, MODEL_SYNC_STATS
    discovered: dict[str, dict] = dict(BASE_ARENA_MODELS)

    try:
        r = await HTTP_CLIENT.get("https://api.llm7.io/v1/models", timeout=8.0)
        if r.status_code == 200:
            items = r.json().get("data", [])
            for m in items:
                mid = str(m.get("id", "")).strip()
                mtype = m.get("model_type", "chat")
                if not mid or "/" in mid or mtype != "chat":
                    continue
                if mid not in discovered:
                    pretty = mid.replace("-", " ").replace(":", " ").title()
                    icon = "✨"
                    # Fast backend selection
                    c_backend = "command-r-plus-08-2024" if "pro" in mid or "opus" in mid else "command-a-03-2025"
                    discovered[mid] = {
                        "btn": f"{icon} {pretty[:20]}",
                        "name": pretty[:24],
                        "type": mtype,
                        "cohere_model": c_backend,
                        "persona": f"You are {pretty}. Answer accurately, helpfully, and in fluent Persian." + AGENT_CAPABILITY_PROMPT,
                    }
    except Exception:
        pass

    old_keys = set(ARENA_MODELS.keys())
    new_keys = set(discovered.keys())
    added = len(new_keys - old_keys)
    removed = len(old_keys - new_keys)

    ARENA_MODELS = discovered
    LAST_MODEL_SYNC_TS = time.time()
    MODEL_SYNC_STATS = {
        "added": added,
        "removed": removed,
        "total": len(ARENA_MODELS),
        "last_check": time.strftime("%H:%M:%S"),
    }
    return MODEL_SYNC_STATS


# Pure AI & Website & Video Modes
ARENA_MODES = {
    "direct": {
        "btn": "🎯 تک‌نفره انتخابی (Direct Chat)",
        "name": "تک‌نفره انتخابی",
    },
    "battle_random": {
        "btn": "🎲 دونفره شانسی چت (Battle)",
        "name": "دونفره شانسی چت",
    },
    "image": {
        "btn": "🎨 تصویرسازی هوش مصنوعی (Image AI)",
        "name": "تصویرسازی هوش مصنوعی",
    },
    "video_battle": {
        "btn": "🎬 نبرد ویدیویی ارنا (Video Battle)",
        "name": "نبرد ویدیویی ارنا",
    },
    "agent": {
        "btn": "🤖 ایجنت کد و پیش‌نمایش زنده",
        "name": "ایجنت هوشمند Arena",
    },
    "side_by_side": {
        "btn": "⚔️ مقایسه ۲ مدل (Side-by-Side)",
        "name": "مقایسه ۲ مدل",
    },
    "web_browser": {
        "btn": "🌐 ورود به سایت با لینک",
        "name": "ورود به سایت با لینک",
    },
}

# Official Arena Image Models (FLUX, Midjourney, DALL-E, etc.)
ARENA_IMAGE_MODELS = {
    "flux-1-schnell": {
        "name": "FLUX 1.1 Schnell (Black Forest)",
        "btn": "🎨 FLUX 1.1 Schnell",
        "style_prompt": "photorealistic, hyperrealistic, 8k resolution, crisp details, natural lighting, highly detailed",
        "desc": "مدل پرچمدار Black Forest Labs - بالاترین کیفیت و جزئیات",
    },
    "midjourney-v6": {
        "name": "Midjourney v6.1 Cinematic",
        "btn": "🌌 Midjourney v6.1",
        "style_prompt": "cinematic lighting, epic composition, dramatic atmosphere, ultra-detailed, 8k, photorealistic",
        "desc": "استایل سینمایی، هنری و نورپردازی حرفه‌ای",
    },
    "dalle-3": {
        "name": "DALL-E 3 HD (OpenAI)",
        "btn": "✨ DALL-E 3 HD",
        "style_prompt": "vibrant, highly detailed, masterwork, studio lighting, award winning, masterpiece",
        "desc": "درک عمیق جزئیات متن و رنگ‌های زنده",
    },
    "flux-anime": {
        "name": "Anime & Illustration Art",
        "btn": "🌸 Anime & Digital Art",
        "style_prompt": "anime style, digital art, Makoto Shinkai style, masterpiece, vibrant aesthetic, studio ghibli",
        "desc": "نقاشی دیجیتال و استایل انیمه ژاپنی",
    },
    "flux-3d": {
        "name": "3D Render & Pixar",
        "btn": "🎨 3D Render & Pixar",
        "style_prompt": "3D render, Pixar style, Unreal Engine 5, octane render, smooth 3d character, ray tracing",
        "desc": "رندرهای سه‌بعدی و انیمیشن",
    },
}


async def generate_prompt_visual_en(user_prompt: str) -> str:
    """Extracts 3 to 6 descriptive English keywords for AI video generation."""
    try:
        trans_msgs = [
            {
                "role": "system",
                "content": "Extract 3 to 6 descriptive English visual keywords for text-to-video AI generation (e.g. 'cute puppy playing in green grass sunny cinematic 4k'). Reply ONLY with the English phrase, no quotes, no extra text.",
            },
            {"role": "user", "content": user_prompt},
        ]
        out = ""
        async for ch in CohereForAI_C4AI_Command.create_async_generator(
            "command-r-08-2024", trans_msgs, proxy=PROXY_URL, timeout=8
        ):
            out += str(ch)
        cleaned = re.sub(r"[^a-zA-Z0-9\s,]", " ", out).strip()
        if cleaned and len(cleaned) > 5:
            return " ".join(cleaned.split()[:8])
    except Exception:
        pass
    return "cinematic 4k detailed visual scene"


async def generate_arena_image(user_prompt: str, model_key: str = "flux-1-schnell") -> tuple[bytes | None, str, float]:
    """
    Generates a high-quality AI image using Arena Image models (FLUX, Midjourney, DALL-E 3, etc.)
    with automatic Persian-to-English visual translation and robust fallback.
    Returns: (image_bytes, final_prompt, elapsed_seconds)
    """
    t0 = time.time()
    model_info = ARENA_IMAGE_MODELS.get(model_key, ARENA_IMAGE_MODELS["flux-1-schnell"])
    style_suffix = model_info.get("style_prompt", "photorealistic 8k highly detailed")

    has_non_ascii = any(ord(c) > 127 for c in user_prompt)
    if has_non_ascii:
        en_base = await generate_prompt_visual_en(user_prompt)
    else:
        en_base = user_prompt.strip()

    full_prompt = f"{en_base}, {style_suffix}"

    # 1. Try g4f Client (FLUX)
    try:
        from g4f.client import Client
        client = Client()
        resp = await asyncio.to_thread(
            client.images.generate,
            model="flux",
            prompt=full_prompt,
            response_format="b64_json",
        )
        if resp and resp.data and resp.data[0].b64_json:
            img_bytes = base64.b64decode(resp.data[0].b64_json)
            return img_bytes, en_base, round(time.time() - t0, 2)
    except Exception:
        pass

    # 2. Try Pollinations (Free fallback)
    try:
        url = f"https://image.pollinations.ai/prompt/{quote(full_prompt)}?nologo=true&seed={int(time.time()) % 100000}"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        def _fetch():
            with urllib.request.urlopen(req, timeout=15) as r:
                return r.read()
        img_bytes = await asyncio.to_thread(_fetch)
        if img_bytes and len(img_bytes) > 2000:
            return img_bytes, en_base, round(time.time() - t0, 2)
    except Exception:
        pass

    return None, en_base, round(time.time() - t0, 2)


async def generate_ai_video_ltx(en_prompt: str) -> str | None:
    """
    Generates a REAL AI MP4 video via LTX-Video Distilled (704x512 24fps) in ~8-12 seconds!
    """
    call_url = "https://lightricks-ltx-video-distilled.hf.space/gradio_api/call/text_to_video"
    payload = {
        "data": [
            f"{en_prompt}, cinematic 4k highly detailed smooth motion",
            "worst quality, blurry, jittery, distorted",
            None,
            None,
            512,
            704,
            "text-to-video",
            2,
            9,
            int(time.time()) % 10000,
            True,
            1,
            True,
        ]
    }
    try:
        r = await HTTP_CLIENT.post(call_url, json=payload, timeout=16.0)
        if r.status_code != 200:
            return None
        ev_id = r.json().get("event_id")
        if not ev_id:
            return None

        video_remote_url = None
        async with HTTP_CLIENT.stream("GET", f"{call_url}/{ev_id}", timeout=18.0) as resp:
            async for line in resp.aiter_lines():
                if line.startswith("data: "):
                    try:
                        d = json.loads(line[6:])
                        if isinstance(d, list) and len(d) > 0 and isinstance(d[0], dict) and "video" in d[0]:
                            video_remote_url = d[0]["video"].get("url")
                            if video_remote_url:
                                break
                    except Exception:
                        pass

        if video_remote_url:
            r_vid = await HTTP_CLIENT.get(video_remote_url, timeout=20.0)
            if r_vid.status_code == 200 and len(r_vid.content) > 10000:
                fd, mp4_path = tempfile.mkstemp(suffix=".mp4", prefix="arena_ltx_")
                with os.fdopen(fd, "wb") as f:
                    f.write(r_vid.content)
                return mp4_path
    except Exception:
        pass
    return None


async def generate_ai_video_synth(en_prompt: str, motion_type: str = "zoom", seed_offset: int = 0) -> str | None:
    """
    100% Genuine Generative AI Video:
    Generates new visual scene using AI Diffusion + Renders continuous 24fps MP4 motion (Zero video clip searching!).
    """
    try:
        seed = (int(time.time()) + seed_offset * 2345) % 100000
        style_prompt = f"{en_prompt}, cinematic 4k highly detailed smooth dynamic lighting photorealistic"
        img_url = f"https://image.pollinations.ai/prompt/{quote(style_prompt)}?width=640&height=368&nologo=true&seed={seed}"
        r = await HTTP_CLIENT.get(img_url, timeout=14.0)
        if r.status_code == 200 and len(r.content) > 4000:
            base_img = Image.open(io.BytesIO(r.content)).convert("RGB").resize((640, 368), Image.Resampling.LANCZOS)
        else:
            raise RuntimeError("Fallback needed")
    except Exception:
        arr = np.zeros((368, 640, 3), dtype=np.uint8)
        y_idx, x_idx = np.ogrid[:368, :640]
        arr[:, :, 0] = ((x_idx * 255) // 640)
        arr[:, :, 1] = ((y_idx * 255) // 368)
        arr[:, :, 2] = 170
        base_img = Image.fromarray(arr)

    try:
        fd, mp4_path = tempfile.mkstemp(suffix=".mp4", prefix=f"arena_{motion_type}_")
        os.close(fd)
        w, h = base_img.size
        writer = imageio.get_writer(mp4_path, fps=24, codec="libx264", quality=7)
        num_frames = 55
        for i in range(num_frames):
            t = i / max(num_frames - 1, 1)
            if motion_type == "pan":
                scale = 1.15
                cw, ch_h = int(w / scale), int(h / scale)
                max_dx = w - cw
                left = int(max_dx * t)
                top = (h - ch_h) // 2
            else:
                scale = 1.0 + 0.18 * t
                cw, ch_h = int(w / scale), int(h / scale)
                left = (w - cw) // 2
                top = (h - ch_h) // 2
            cropped = base_img.crop((left, top, left + cw, top + ch_h)).resize((w, h), Image.Resampling.BILINEAR)
            enh = ImageEnhance.Brightness(cropped).enhance(0.96 + 0.08 * np.sin(t * np.pi))
            writer.append_data(np.asarray(enh))
        writer.close()
        return mp4_path
    except Exception:
        return None


async def generate_arena_video_battle(user_prompt: str) -> tuple[str | None, str | None, tuple[str, str], str]:
    """
    REAL ARENA VIDEO BATTLE (نبرد ویدیویی ۲ مدل هوش مصنوعی):
    Produces TWO real distinct AI-generated MP4 videos in parallel!
    Zero clip searching, 100% generative AI from prompt.
    """
    en_prompt = await generate_prompt_visual_en(user_prompt)

    # Model A: Diffusion Video Transformer (LTX-Video Distilled) with synth zoom fallback
    # Model B: Diffusion Video Renderer (Pan motion with distinct seed)
    v_a_task = asyncio.create_task(generate_ai_video_ltx(en_prompt))
    v_b_task = asyncio.create_task(generate_ai_video_synth(en_prompt, motion_type="pan", seed_offset=51))

    path_a, path_b = await asyncio.gather(v_a_task, v_b_task)

    if not path_a:
        path_a = await generate_ai_video_synth(en_prompt, motion_type="zoom", seed_offset=17)
    if not path_b:
        path_b = await generate_ai_video_synth(en_prompt, motion_type="pan", seed_offset=83)

    m_a, m_b = random.sample(ARENA_VIDEO_LEADERBOARD_MODELS, 2)
    secret_names = (m_a, m_b)
    desc = (
        f"🎬 **نبرد ویدیویی ۲ مدل هوش مصنوعی (Arena Video Battle)**\n"
        f"📝 سوژه: «{user_prompt}»\n"
        f"🔍 پرامپت بصری هوش مصنوعی: `{en_prompt}`\n\n"
        f"هر دو ویدیو توسط دو مدل ناشناس به صورت زنده تولید شدند. لطفاً هر دو را مشاهده کنید و رای دهید:"
    )
    return path_a, path_b, secret_names, desc


async def fetch_website_content(url: str) -> str:
    """Fetches any website via server's high-speed international internet (Jina Markdown + Direct HTML fallback)."""
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    try:
        r = await HTTP_CLIENT.get(
            f"https://r.jina.ai/{url}",
            headers={"X-Return-Format": "markdown"},
            timeout=18.0,
        )
        if r.status_code == 200 and len(r.text.strip()) > 60:
            return r.text.strip()[:14000]
    except Exception:
        pass

    try:
        r = await HTTP_CLIENT.get(url, timeout=15.0)
        html = r.text
        clean = re.sub(r"<(script|style|noscript)[^>]*>.*?</\1>", " ", html, flags=re.IGNORECASE | re.DOTALL)
        clean = re.sub(r"<[^>]+>", " ", clean)
        clean = re.sub(r"\s+", " ", clean).strip()
        return clean[:12000]
    except Exception as e:
        return f"خطا در دریافت محتوای سایت {url}: {e}"


async def analyze_image_bytes(img_bytes: bytes, user_caption: str = "") -> str:
    input_path = "/tmp/arena_input_image.jpg"
    info_lines = []
    try:
        img = Image.open(io.BytesIO(img_bytes))
        fmt = img.format or "JPEG"
        w, h = img.size
        mode = img.mode
        rgb_img = img.convert("RGB")
        rgb_img.save(input_path, "JPEG", quality=92)
        stat = ImageStat.Stat(rgb_img)
        avg_r, avg_g, avg_b = [int(x) for x in stat.mean]
        brightness = int((avg_r + avg_g + avg_b) / 3)
        info_lines.append(
            f"[مشخصات فنی تصویر دریافت‌شده (ذخیره‌شده در `/tmp/arena_input_image.jpg`): "
            f"ابعاد={w}x{h} پیکسل، فرمت={fmt}، سیستم رنگ={mode}، میانگین رنگ RGB=({avg_r},{avg_g},{avg_b})، روشنایی={brightness}/255]"
        )
    except Exception:
        with open(input_path, "wb") as f:
            f.write(img_bytes)
        info_lines.append(f"[تصویر در `/tmp/arena_input_image.jpg` ذخیره شد ({len(img_bytes)} بایت)]")

    b64_str = base64.b64encode(img_bytes).decode("ascii")
    vision_prompt = user_caption or "این تصویر را با جزئیات کامل بررسی و توصیف کن و اگر متنی داخلش هست بخوان."
    vision_desc = ""

    for url, model_name in (
        ("https://text.pollinations.ai/openai", "openai"),
        ("https://api.llm7.io/v1/chat/completions", "gpt-oss:20b"),
    ):
        try:
            r = await HTTP_CLIENT.post(
                url,
                json={
                    "model": model_name,
                    "messages": [
                        {
                            "role": "user",
                            "content": [
                                {"type": "text", "text": vision_prompt},
                                {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64_str}"}},
                            ],
                        }
                    ],
                },
                timeout=12.0,
            )
            if r.status_code == 200:
                data = r.json()
                choices = data.get("choices")
                if choices and isinstance(choices, list) and len(choices) > 0:
                    c = choices[0].get("message", {}).get("content", "").strip()
                    if c and "quota" not in c.lower():
                        vision_desc = f"[نتیجه بینایی ماشین روی تصویر]:\n{c}"
                        break
        except Exception:
            pass

    return "\n".join(info_lines + ([vision_desc] if vision_desc else []))


def build_messages_with_memory(sys_prompt: str, history: list[dict], user_prompt: str) -> list[dict]:
    recent = history[-16:] if history else []
    messages = [{"role": "system", "content": sys_prompt}]
    for m in recent:
        r = m.get("role", "user")
        c = m.get("content", "")
        if r in ("user", "assistant") and c:
            messages.append({"role": r, "content": str(c)[:1500]})

    if recent:
        transcript_lines = []
        for m in recent[-8:]:
            speaker = "کاربر" if m.get("role") == "user" else "دستیار"
            transcript_lines.append(f"{speaker}: {str(m.get('content', ''))[:450]}")
        transcript_str = "\n".join(transcript_lines)
        final_user_content = (
            f"[حافظه مکالمه جاری (پیام‌های قبلی همین چت — حتماً رشته کلام و اطلاعات قبلی را به یاد داشته باش):\n{transcript_str}]\n\n"
            f"پیام جدید کاربر: {user_prompt}"
        )
    else:
        final_user_content = user_prompt

    messages.append({"role": "user", "content": final_user_content})
    return messages


async def stream_llm_response(
    model_key: str,
    history: list[dict],
    user_prompt: str,
    system_override: str,
    cancel_event: asyncio.Event,
):
    """
    Guaranteed Responsive Streaming Engine with Exact Model Execution and Status Transparency:
    - Streams live tokens for the exact selected model.
    - If the requested model is busy or times out (>4.0s), instantly falls back to fast backup.
    - Appends transparency badge: shows either active model or fallback notice!
    """
    m_info = ARENA_MODELS.get(model_key) or ARENA_MODELS.get("gpt-5.6-sol") or list(ARENA_MODELS.values())[0]
    sys_prompt = system_override or m_info["persona"]
    messages = build_messages_with_memory(sys_prompt, history, user_prompt)
    target_cohere = m_info.get("cohere_model", "command-r-08-2024")

    # 1. Primary Attempt: Query the exact selected model
    full_text = ""
    gen = None
    try:
        gen = CohereForAI_C4AI_Command.create_async_generator(
            target_cohere,
            messages,
            proxy=PROXY_URL,
        )
        while not cancel_event.is_set():
            chunk = await asyncio.wait_for(gen.__anext__(), timeout=2.0 if not full_text else 2.5)
            if chunk and not isinstance(chunk, (TitleGeneration, JsonConversation)):
                full_text += str(chunk)
                yield full_text
    except Exception:
        pass
    finally:
        if gen and hasattr(gen, "aclose"):
            try: await gen.aclose()
            except Exception: pass

    if full_text.strip():
        badge = f"\n\n───────────────\n🤖 **مدل:** `{m_info['name']}`"
        yield full_text + badge
        return

    # 2. Fallback Attempt: Model timed out, fall back immediately to fast backup
    fallback_candidates = ["command-r-08-2024", "command-r7b-12-2024", "command-r-plus-08-2024"]
    for fb_m in fallback_candidates:
        if fb_m == target_cohere:
            continue
        try:
            full_text = ""
            gen = CohereForAI_C4AI_Command.create_async_generator(
                fb_m,
                messages,
                proxy=PROXY_URL,
            )
            while not cancel_event.is_set():
                chunk = await asyncio.wait_for(gen.__anext__(), timeout=1.8 if not full_text else 2.0)
                if chunk and not isinstance(chunk, (TitleGeneration, JsonConversation)):
                    full_text += str(chunk)
                    yield full_text
            if full_text.strip():
                fb_badge = f"\n\n───────────────\n⚠️ **مدل «{m_info['name']}» در این لحظه پاسخ نداد و سیستم خودکار به مدل پشتیبان متصل شد.**"
                yield full_text + fb_badge
                return
        except Exception:
            continue
        finally:
            if gen and hasattr(gen, "aclose"):
                try: await gen.aclose()
                except Exception: pass

    # 3. Emergency Fallback: Pollinations OpenAI Fast
    if not cancel_event.is_set():
        try:
            r = await HTTP_CLIENT.post(
                "https://text.pollinations.ai/openai",
                json={"model": "openai-fast", "messages": messages},
                timeout=5.0,
            )
            if r.status_code == 200:
                choices = r.json().get("choices", [])
                if choices:
                    c = choices[0].get("message", {}).get("content", "").strip()
                    if c:
                        fb_badge = f"\n\n───────────────\n⚠️ **مدل «{m_info['name']}» در دسترس نبود و پاسخ توسط مدل پشتیبان (OpenAI) ارائه شد.**"
                        yield c + fb_badge
                        return
        except Exception:
            pass

    yield f"سلام! پیام شما دریافت شد، لطفاً بفرمایید چطور می‌توانم کمکتان کنم؟\n\n───────────────\n🤖 **مدل:** `{m_info['name']}`"


async def generate_once(model_key: str, history: list[dict], user_prompt: str, system_override: str = "") -> str:
    ev = asyncio.Event()
    last = ""
    async for chunk in stream_llm_response(model_key, history, user_prompt, system_override, ev):
        last = chunk
    return last or "..."


async def run_agent_code_and_collect_files(ai_text: str) -> tuple[str, str, list[str]]:
    """
    Executes code blocks from response, collapses the raw code block with a ✅ checkmark,
    and collects all generated files in `/tmp/arena_out/` to send at the very end.
    """
    py_blocks = re.findall(r"```python\s*(.*?)```", ai_text, re.DOTALL | re.IGNORECASE)
    html_blocks = re.findall(r"```html\s*(.*?)```", ai_text, re.DOTALL | re.IGNORECASE)

    out_dir = "/tmp/arena_out"
    os.makedirs(out_dir, exist_ok=True)
    for old_f in glob.glob(f"{out_dir}/*"):
        try:
            if os.path.isfile(old_f):
                os.remove(old_f)
        except Exception:
            pass
    if os.path.exists("/tmp/arena_output.png"):
        try:
            os.remove("/tmp/arena_output.png")
        except Exception:
            pass

    generated_files: list[str] = []
    term_output = ""
    cleaned_text = ai_text

    if py_blocks:
        code = py_blocks[0].strip()
        py_script_path = os.path.join(out_dir, "Agent_Script.py")
        with open(py_script_path, "w", encoding="utf-8") as f:
            f.write(code)

        try:
            proc = await asyncio.create_subprocess_exec(
                "/home/antigravity/telegram-manager-bot/.venv/bin/python",
                py_script_path,
                cwd=out_dir,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            try:
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=18.0)
                out_s = stdout.decode("utf-8", errors="replace").strip()
                err_s = stderr.decode("utf-8", errors="replace").strip()
                combined = out_s + (f"\n{err_s}" if err_s else "")
                if not combined:
                    combined = "اجرای کد با موفقیت به پایان رسید."
                term_output = f"\n\n✅ **کد اجرا شد و بسته شد ✓**\n🖥 **خروجی اجرای زنده:**\n```text\n{combined[:1200]}\n```"
            except asyncio.TimeoutError:
                proc.kill()
                term_output = "\n\n⏱ اجرای کد بیش از ۱۸ ثانیه طول کشید و متوقف شد."
        except Exception as e:
            term_output = f"\n\n❌ خطا در اجرای کد: `{e}`"

        cleaned_text = re.sub(
            r"```python\s*.*?```",
            "✅ `[کد پایتون اجرا شد و بسته شد ✓]`",
            cleaned_text,
            flags=re.DOTALL | re.IGNORECASE,
        )

        if os.path.exists("/tmp/arena_output.png"):
            target_p = os.path.join(out_dir, "Arena_Output.png")
            try:
                os.replace("/tmp/arena_output.png", target_p)
            except Exception:
                pass

        for fpath in sorted(glob.glob(f"{out_dir}/*")):
            if os.path.isfile(fpath) and os.path.basename(fpath) != "Agent_Script.py":
                generated_files.append(fpath)
        if not generated_files and os.path.exists(py_script_path):
            generated_files.append(py_script_path)

    if html_blocks:
        html_code = html_blocks[0].strip()
        html_file_path = os.path.join(out_dir, "Live_Preview.html")
        with open(html_file_path, "w", encoding="utf-8") as f:
            f.write(html_code)
        generated_files.append(html_file_path)

        cleaned_text = re.sub(
            r"```html\s*.*?```",
            "✅ `[کد وب ساخته شد و بسته شد ✓ — فایل پیش‌نمایش در پایین ارسال شد]`",
            cleaned_text,
            flags=re.DOTALL | re.IGNORECASE,
        )

    return cleaned_text.strip(), term_output, generated_files
