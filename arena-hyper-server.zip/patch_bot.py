import re

with open('bot.py', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Regex replacement
old_regex = '''VIDEO_PROMPT_REGEX = re.compile(
    r"(ویدیو|فیلم|کلیپ|انیمیشن|\\bvideo\\b|\\bclip\\b|بساز.*ویدیو|ویدیو.*بساز)",
    re.IGNORECASE,
)'''
new_regex = '''VIDEO_CMD_REGEX = re.compile(
    r"(بساز.*(ویدیو|کلیپ|فیلم)|(ویدیو|کلیپ|فیلم).*بساز|تولید.*(ویدیو|کلیپ)|(ویدیو|کلیپ).*تولید|make.*video|generate.*video)",
    re.IGNORECASE,
)'''
if old_regex in content:
    content = content.replace(old_regex, new_regex)
    print("1. Replaced VIDEO_PROMPT_REGEX")
else:
    print("1. old_regex not found, checking...")

content = content.replace('VIDEO_PROMPT_REGEX.search(prompt)', 'VIDEO_CMD_REGEX.search(prompt)')

# 2. build_bottom_menu video view
old_menu_start = '''    state = db.get_user_state(user_id)
    ui = ui_sessions[user_id]
    view = ui.get("menu_view", "main")
    m_info = ai_arena.ARENA_MODELS.get(state["model"]) or ai_arena.ARENA_MODELS.get("gpt-5.6-sol") or list(ai_arena.ARENA_MODELS.values())[0]
    mode_info = ai_arena.ARENA_MODES.get(state["mode"], ai_arena.ARENA_MODES["direct"])

    if view == "models":'''

new_menu_start = '''    state = db.get_user_state(user_id)
    ui = ui_sessions[user_id]
    view = ui.get("menu_view", "main")
    m_info = ai_arena.ARENA_MODELS.get(state["model"]) or ai_arena.ARENA_MODELS.get("gpt-5.6-sol") or list(ai_arena.ARENA_MODELS.values())[0]
    mode_info = ai_arena.ARENA_MODES.get(state["mode"], ai_arena.ARENA_MODES["direct"])

    if view == "video" or state["mode"] == "video_battle":
        rows = [
            [KeyboardButton("🔙 بازگشت به گفتگوی متنی"), KeyboardButton("🧹 چت جدید")],
        ]
        return ReplyKeyboardMarkup(rows, resize_keyboard=True)

    if view == "models":'''

if old_menu_start in content:
    content = content.replace(old_menu_start, new_menu_start)
    print("2. Added video view to build_bottom_menu")
else:
    print("2. old_menu_start not found")

# 3. handle_messages sections 3, 4, 5, 6, 7, 8
old_handlers = '''    # 3. BACK TO MAIN MENU
    if text == "🔙 بازگشت":
        ui["menu_view"] = "main"
        await msg.reply_text("👌 منوی اصلی:", reply_markup=build_bottom_menu(user.id))
        return

    # 4. OPEN MODEL PICKER IN BOTTOM MENU
    if text.startswith("🧠 مدل:"):
        ui["menu_view"] = "models"
        await msg.reply_text(
            f"🧠 مدل را انتخاب کنید ({len(ai_arena.ARENA_MODELS)} مدل چت و ویدیو فعال — با حفظ حافظه همین چت):",
            reply_markup=build_bottom_menu(user.id),
        )
        return

    # 5. SELECT SPECIFIC MODEL FROM BOTTOM MENU (Keeps current chat history!)
    for m_key, m_info in ai_arena.ARENA_MODELS.items():
        if text == m_info["btn"]:
            db.set_user_model(user.id, m_key)
            if m_info.get("type") == "video":
                db.set_user_mode(user.id, "video_gen")
            elif db.get_user_state(user.id)["mode"] in ("video_gen", "video_battle"):
                db.set_user_mode(user.id, "direct")
            ui["menu_view"] = "main"
            await msg.reply_text(
                f"✅ `{m_info['name']}`",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=build_bottom_menu(user.id),
            )
            return

    # 6. OPEN MODE PICKER IN BOTTOM MENU
    if text.startswith("🎭 حالت:"):
        ui["menu_view"] = "modes"
        await msg.reply_text("🎭 حالت را انتخاب کنید:", reply_markup=build_bottom_menu(user.id))
        return

    # 7. SELECT SPECIFIC MODE FROM BOTTOM MENU
    for mode_key, mode_info in ai_arena.ARENA_MODES.items():
        if text == mode_info["btn"]:
            db.set_user_mode(user.id, mode_key)
            ui["menu_view"] = "main"
            await msg.reply_text(
                f"🎯 `{mode_info['name']}`",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=build_bottom_menu(user.id),
            )
            return

    # 8. HANDLE BATTLE VOTE & REVEAL ANONYMOUS MODELS (Chat OR Video!)
    if any(k in text for k in ("مدل A", "ویدیو A", "مدل B", "ویدیو B", "مساوی", "هیچ‌کدام")):
        secret = ui.get("battle_secret")
        ui["menu_view"] = "main"
        if secret:'''

new_handlers = '''    # 3. BACK TO MAIN MENU / RETURN TO CHAT
    if text in ("🔙 بازگشت", "🔙 بازگشت به گفتگوی متنی", "بازگشت"):
        db.set_user_mode(user.id, "direct")
        ui["menu_view"] = "main"
        await msg.reply_text("👌 منوی اصلی گفتگوی متنی:", reply_markup=build_bottom_menu(user.id))
        return

    # 4. OPEN MODEL PICKER IN BOTTOM MENU
    if text.startswith("🧠") or "مدل چت" in text or "انتخاب مدل" in text:
        ui["menu_view"] = "models"
        await msg.reply_text(
            f"🧠 مدل مورد نظر را انتخاب کنید ({len(ai_arena.ARENA_MODELS)} مدل فعال — با حفظ سابقه گفتگو):",
            reply_markup=build_bottom_menu(user.id),
        )
        return

    # 5. SELECT SPECIFIC MODEL FROM BOTTOM MENU (Keeps current chat history!)
    for m_key, m_info in ai_arena.ARENA_MODELS.items():
        if text == m_info["btn"] or text == m_info["name"]:
            db.set_user_model(user.id, m_key)
            db.set_user_mode(user.id, "direct")
            ui["menu_view"] = "main"
            await msg.reply_text(
                f"✅ **مدل با موفقیت تغییر کرد:** `{m_info['name']}`\\n\\n💬 اکنون پیام خود را بنویسید (پاسخ توسط این مدل و با حفظ سابقه گفتگو ارسال می‌شود):",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=build_bottom_menu(user.id),
            )
            return

    # 6. OPEN MODE PICKER IN BOTTOM MENU
    if text.startswith("🎭") or "حالت:" in text:
        ui["menu_view"] = "modes"
        await msg.reply_text("🎭 حالت کاری ارنا را انتخاب کنید:", reply_markup=build_bottom_menu(user.id))
        return

    # 7. SELECT SPECIFIC MODE FROM BOTTOM MENU
    for mode_key, mode_info in ai_arena.ARENA_MODES.items():
        if text == mode_info["btn"]:
            db.set_user_mode(user.id, mode_key)
            if mode_key == "video_battle":
                ui["menu_view"] = "video"
                await msg.reply_text(
                    "🎬 **حالت نبرد ویدیویی ارنا (Video Battle)**\\n\\n"
                    "در این بخش موضوع یا صحنه‌ای که می‌خواهید ساخته شود را بنویسید تا ۲ ویدیوی واقعی توسط ۲ مدل ناشناس ساخته و ارسال شود:\\n\\n"
                    "*(برای بازگشت به چت متنی، دکمه «🔙 بازگشت به گفتگوی متنی» را بزنید)*",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=build_bottom_menu(user.id),
                )
            else:
                ui["menu_view"] = "main"
                await msg.reply_text(
                    f"🎯 حالت فعال: `{mode_info['name']}`",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=build_bottom_menu(user.id),
                )
            return

    # 8. HANDLE BATTLE VOTE & REVEAL ANONYMOUS MODELS (Chat OR Video!)
    if any(k in text for k in ("مدل A", "ویدیو A", "مدل B", "ویدیو B", "مساوی", "هیچ‌کدام")):
        secret = ui.get("battle_secret")
        ui["menu_view"] = "main"
        db.set_user_mode(user.id, "direct")
        if secret:'''

if old_handlers in content:
    content = content.replace(old_handlers, new_handlers)
    print("3. Updated button handlers in handle_messages")
else:
    print("3. old_handlers not found")

with open('bot.py', 'w', encoding='utf-8') as f:
    f.write(content)
print("Updated bot.py successfully!")
