import os
import re
import time
import random
import asyncio
import logging
from collections import defaultdict

from telegram import (
    Update,
    ReplyKeyboardMarkup,
    KeyboardButton,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    WebAppInfo,
)
from telegram.constants import ParseMode
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)

import database as db
import ai_arena
import config_manager
import game_engine

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger("ArenaAIBot")

# Load .env file if present
_env_path = os.path.join(os.path.dirname(__file__), ".env")
if os.path.exists(_env_path):
    with open(_env_path, encoding="utf-8") as _f:
        for _line in _f:
            if "=" in _line and not _line.strip().startswith("#"):
                _k, _v = _line.strip().split("=", 1)
                os.environ.setdefault(_k.strip(), _v.strip())

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")

# Fix httpx URLPattern bug with IPv6 entries (::1, [::1]) in NO_PROXY
for _np_var in ("NO_PROXY", "no_proxy"):
    if _np_var in os.environ:
        os.environ[_np_var] = "localhost,127.0.0.1"

# Active streaming cancellation events per user: user_id -> asyncio.Event
active_generations: dict[int, asyncio.Event] = {}

# Per-user transient UI state (menu_view, battle_secret)
ui_sessions: dict[int, dict] = defaultdict(lambda: {
    "menu_view": "main",
    "battle_secret": None,
})

HTTP_URL_REGEX = re.compile(
    r"(https?://[^\s]+|www\.[^\s]+|[a-zA-Z0-9-]+\.(?:com|ir|org|net|io|ai|me|co|dev|info|app)(?:/[^\s]*)?)",
    re.IGNORECASE,
)

VIDEO_CMD_REGEX = re.compile(
    r"(بساز.*(ویدیو|کلیپ|فیلم)|(ویدیو|کلیپ|فیلم).*بساز|تولید.*(ویدیو|کلیپ)|(ویدیو|کلیپ).*تولید|make.*video|generate.*video)",
    re.IGNORECASE,
)


def build_bottom_menu(user_id: int) -> ReplyKeyboardMarkup:
    """Builds the bottom ReplyKeyboard menu."""
    state = db.get_user_state(user_id)
    ui = ui_sessions[user_id]
    view = ui.get("menu_view", "main")
    m_info = ai_arena.ARENA_MODELS.get(state["model"]) or ai_arena.ARENA_MODELS.get("gpt-5.6-sol") or list(ai_arena.ARENA_MODELS.values())[0]
    mode_info = ai_arena.ARENA_MODES.get(state["mode"], ai_arena.ARENA_MODES["direct"])

    if view == "video" or state["mode"] == "video_battle":
        rows = [
            [KeyboardButton("🔙 بازگشت به گفتگوی متنی"), KeyboardButton("🧹 چت جدید")],
        ]
        return ReplyKeyboardMarkup(rows, resize_keyboard=True)

    if view == "image_models":
        keys = list(ai_arena.ARENA_IMAGE_MODELS.keys())
        rows = []
        for i in range(0, len(keys), 2):
            r = [KeyboardButton(ai_arena.ARENA_IMAGE_MODELS[k]["btn"]) for k in keys[i:i+2]]
            rows.append(r)
        rows.append([KeyboardButton("🔙 بازگشت")])
        return ReplyKeyboardMarkup(rows, resize_keyboard=True)

    if view == "models":
        keys = [k for k in ai_arena.ARENA_MODELS.keys() if db.is_model_enabled(k)]
        rows = []
        for i in range(0, len(keys), 2):
            r = [KeyboardButton(ai_arena.ARENA_MODELS[k]["btn"]) for k in keys[i:i+2]]
            rows.append(r)
        rows.append([KeyboardButton("🔙 بازگشت")])
        return ReplyKeyboardMarkup(rows, resize_keyboard=True)

    if view == "modes":
        rows = [
            [KeyboardButton("🎯 تک‌نفره انتخابی (Direct Chat)"), KeyboardButton("🎨 تصویرسازی هوش مصنوعی (Image AI)")],
            [KeyboardButton("🎲 دونفره شانسی چت (Battle)"), KeyboardButton("🎬 نبرد ویدیویی ارنا (Video Battle)")],
            [KeyboardButton("🤖 ایجنت کد و پیش‌نمایش زنده"), KeyboardButton("⚔️ مقایسه ۲ مدل (Side-by-Side)")],
            [KeyboardButton("🌐 ورود به سایت با لینک"), KeyboardButton("🔙 بازگشت")],
        ]
        return ReplyKeyboardMarkup(rows, resize_keyboard=True)

    if view == "battle_vote":
        rows = [
            [KeyboardButton("🅰️ مدل / ویدیو A بهتر بود"), KeyboardButton("🅱️ مدل / ویدیو B بهتر بود")],
            [KeyboardButton("🤝 هر دو عالی بودند (مساوی)"), KeyboardButton("👎 هیچ‌کدام (کیفیت پایین)")],
            [KeyboardButton("🔙 بازگشت")],
        ]
        return ReplyKeyboardMarkup(rows, resize_keyboard=True)

    if view == "admin_panel":
        rows = [
            [KeyboardButton("🌐 کلید جامع سرور (برای همه‌چیز)"), KeyboardButton("⚡ ساخت کلید سرور خام (همه‌کاره)")],
            [KeyboardButton("🎮 کلید سرور ساخت بازی آنلاین"), KeyboardButton("💬 کلید سرور ساخت پیام‌رسان")],
            [KeyboardButton("🔑 توکن برنامه پی کا تو (PK2)"), KeyboardButton("➕ ساخت توکن جدید پی کا تو")],
            [KeyboardButton("👥 لیست تمام کلیدها و همکاران"), KeyboardButton("⚡ خاموش / روشن کردن کلید")],
            [KeyboardButton("➕ ساخت کلید همکار جدید"), KeyboardButton("🤖 ساخت کلید هوش مصنوعی")],
            [KeyboardButton("📋 دریافت پرامپت و کدهای اتصال"), KeyboardButton("📁 مشاهده پروژه‌های ایزوله")],
            [KeyboardButton("🗑️ حذف کلید همکار"), KeyboardButton("🔙 بازگشت به منوی اصلی")],
        ]
        return ReplyKeyboardMarkup(rows, resize_keyboard=True)

    if view == "game_key_menu":
        rows = [
            [KeyboardButton("➕ ساخت کلید جدید سرور بازی"), KeyboardButton("🔑 دریافت کلید و پرامپت ساخت بازی آنلاین")],
            [KeyboardButton("📜 ثبت قوانین سرور بازی"), KeyboardButton("🤝 افزودن همکار به سرور بازی")],
            [KeyboardButton("📡 وضعیت اتاق‌های بازی فعال"), KeyboardButton("🗑️ پاک کردن همه سرورهای بازی")],
            [KeyboardButton("🔐 پنل مدیریت سرور"), KeyboardButton("🔙 بازگشت به منوی اصلی")],
        ]
        return ReplyKeyboardMarkup(rows, resize_keyboard=True)

    if view == "messenger_key_menu":
        rows = [
            [KeyboardButton("➕ ساخت کلید جدید سرور پیام‌رسان"), KeyboardButton("🔑 دریافت کلید و پرامپت ساخت پیام‌رسان")],
            [KeyboardButton("📜 ثبت قوانین سرور پیام‌رسان"), KeyboardButton("🤝 افزودن همکار به سرور پیام‌رسان")],
            [KeyboardButton("📡 وضعیت کانال‌ها و قوانین پیام‌رسان"), KeyboardButton("🗑️ پاک کردن همه سرورهای پیام‌رسان")],
            [KeyboardButton("🔐 پنل مدیریت سرور"), KeyboardButton("🔙 بازگشت به منوی اصلی")],
        ]
        return ReplyKeyboardMarkup(rows, resize_keyboard=True)

    if view == "toggle_keys":
        keys = db.list_api_keys_with_projects()
        rows = []
        for k in keys:
            is_act = k.get("is_active") == 1 or k.get("is_active") is None
            prefix = "🔴 خاموش کن:" if is_act else "🟢 روشن کن:"
            rows.append([KeyboardButton(f"{prefix} {k['name']}")])
        rows.append([KeyboardButton("🔙 بازگشت به پنل مدیریت")])
        return ReplyKeyboardMarkup(rows, resize_keyboard=True)

    if view == "delete_keys":
        keys = db.list_api_keys_with_projects()
        rows = []
        for k in keys:
            if not k["key"].startswith("sk-arena-iran-master"):
                rows.append([KeyboardButton(f"🗑️ حذف: {k['name']}")])
        rows.append([KeyboardButton("🔙 بازگشت به پنل مدیریت")])
        return ReplyKeyboardMarkup(rows, resize_keyboard=True)

    # Clean Main Menu - Pure AI Power
    is_adm = db.is_admin(user_id)
    if is_adm:
        # Exclusive Admin Menu for @FilterNet3 with Universal Key, Raw Key, Game Server, Messenger Server, API Key and PK2 Token access (Bottom Menu, NOT Glass!)
        rows = [
            [KeyboardButton(f"🧠 مدل چت: {m_info['name']}"), KeyboardButton(f"🎭 حالت: {mode_info['name']}")],
            [KeyboardButton("🌐 کلید جامع سرور (برای همه‌چیز)"), KeyboardButton("⚡ ساخت کلید سرور خام (همه‌کاره)")],
            [KeyboardButton("🎮 کلید سرور ساخت بازی آنلاین"), KeyboardButton("💬 کلید سرور ساخت پیام‌رسان")],
            [KeyboardButton("🔑 توکن برنامه پی کا تو (PK2)"), KeyboardButton("🔐 پنل مدیریت سرور")],
            [KeyboardButton("🎮 بازی دو نفره و آنلاین (دوز XO)"), KeyboardButton("🎨 تصویرسازی هوش مصنوعی (Image AI)")],
            [KeyboardButton("🚀 استودیو پروژه‌ها (AI Projects)"), KeyboardButton("🧹 چت جدید"), KeyboardButton("⏹ توقف")],
        ]
    else:
        # Standard User Menu
        rows = [
            [KeyboardButton(f"🧠 مدل چت: {m_info['name']}"), KeyboardButton(f"🎭 حالت: {mode_info['name']}")],
            [KeyboardButton("🎮 بازی دو نفره و آنلاین (دوز XO)"), KeyboardButton("🎨 تصویرسازی هوش مصنوعی (Image AI)")],
            [KeyboardButton("👨‍💻 مستندات توسعه‌دهندگان (Developer Hub)"), KeyboardButton("🚀 استودیو پروژه‌ها (AI Projects)")],
            [KeyboardButton("🎬 نبرد ویدیویی ارنا (Video Battle)"), KeyboardButton("🧹 چت جدید")],
            [KeyboardButton("⏹ توقف")],
        ]
    return ReplyKeyboardMarkup(rows, resize_keyboard=True)


async def cmd_key(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    user = update.effective_user
    uname = (getattr(user, "username", None) or "").strip().lower().lstrip("@")
    if uname != "filternet3" and not db.is_admin(user.id, uname):
        await msg.reply_text(
            "⛔ **دسترسی محدود شده است!**\n\n"
            "کلید سرور (Universal Master Key) یک دسترسی خصوصی و امنیتی است و منحصراً برای مدیر ارشد سرور (**@FilterNet3**) صادر می‌شود.\n\n"
            "برای مشاهده پورتال توسعه‌دهندگان و روش‌های اتصال، دکمه «👨‍💻 مستندات توسعه‌دهندگان» یا دستور `/dev` را مشاهده کنید.",
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    key = db.get_api_key()
    lines = [
        "👑 **کلید اصلی و اختصاصی مدیر ارشد سرور (@FilterNet3):**",
        f"`{key}`",
        "",
        "🌐 **آدرس Base URL برای اتصال هوش مصنوعی‌ها و برنامه‌ها:**",
        "`http://localhost:8080/v1`",
        "",
        "🤖 **نحوه اتصال به هوش مصنوعی دیگر (ChatGPT / Claude / Cursor / ایجنت‌ها):**",
        "این کلید را به هر هوش مصنوعی یا سیستم کدنویسی دیگر بدهید تا مستقیماً به سرور شما وصل شود و پروژه‌های جدید بسازد!",
        "",
        "📋 **متن پرامپت آماده برای دادن به هوش مصنوعی دیگر:**",
        "```text",
        "تو به عنوان دستیار هوشمند به سرور اختصاصی Arena AI متصل هستی.",
        "ابتدا برای فعال‌سازی پورت 8080 در محیط خودت، این دستور را اجرا کن:",
        "python3 ~/.gemini/mitra_bot_storage/arena_bridge.py --boot",
        f"API Key: {key}",
        "Base URL: http://localhost:8080/v1",
        "اکنون به http://localhost:8080/v1/chat/completions درخواست بفرست و نتیجه را نمایش بده.",
        "```",
        "",
        "💻 **نمونه استفاده در پایتون (استاندارد OpenAI):**",
        "```python",
        "import subprocess",
        "subprocess.run(['python3', '/home/antigravity/.gemini/mitra_bot_storage/arena_bridge.py', '--boot'])",
        "from openai import OpenAI",
        f"client = OpenAI(base_url='http://localhost:8080/v1', api_key='{key}')",
        "res = client.chat.completions.create(",
        "    model='gpt-5.6-sol',",
        "    messages=[{'role': 'user', 'content': 'سلام'}]",
        ")",
        "print(res.choices[0].message.content)",
        "```",
        "",
        "📚 **دستورات مدیریت کلیدها:**",
        "• `/keys` - مشاهده تمام کلیدها و پروژه‌های اختصاصی",
        "• `/newkey <نام پروژه>` - ساخت کلید جدید با پروژه ایزوله",
    ]
    await msg.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)


def get_public_url() -> str | None:
    for path in (
        "/home/antigravity/telegram-manager-bot/public_url.txt",
        "/home/antigravity/.gemini/mitra_bot_storage/public_url.txt",
    ):
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    u = f.read().strip()
                    if u.startswith("https://"):
                        return u
            except Exception:
                pass
    return None


def build_keys_panel_markup() -> tuple[str, InlineKeyboardMarkup]:
    keys = db.list_api_keys_with_projects()
    active_count = sum(1 for k in keys if k.get("is_active") == 1 or k.get("is_active") is None)
    disabled_count = len(keys) - active_count
    lines = [
        "👑 **پنل اختصاصی مدیریت کلیدها و همکاران (@FilterNet3)**",
        "",
        "🌟 **سامانه مدیریت کلیدها و پروژه‌های ایزوله (۱۰۰٪ داخل خود تلگرام):**",
        f"📊 **آمار زنده:** `{len(keys)} کلید اختصاصی` (🟢 {active_count} روشن و فعال | 🔴 {disabled_count} خاموش و مسدود)",
        "",
        "💡 *برای خاموش/روشن کردن فوری هر کلید، دکمه [🟢/🔴] روبروی آن را لمس کنید:*",
        "",
    ]
    for idx, k in enumerate(keys, 1):
        is_act = k.get("is_active") == 1 or k.get("is_active") is None
        st = "🟢 فعال" if is_act else "🔴 مسدود"
        role = k.get("role", "همکار")
        lines.append(f"{idx}. **{k['name']}** ({role}) — {st}\n   📁 پروژه: `{k['project_name']}` | شناسه: `{k['project_id']}`")

    keyboard = []
    for k in keys:
        is_act = k.get("is_active") == 1 or k.get("is_active") is None
        st_icon = "🟢" if is_act else "🔴"
        role = k.get("role", "همکار")
        role_icon = "👑" if role == "مدیر" else ("🤖" if role == "ایجنت هوش مصنوعی" else "👥")
        btn_text = f"{st_icon} {role_icon} {k['name']}"
        toggle_btn = "🔴 خاموش" if is_act else "🟢 روشن"
        keyboard.append([
            InlineKeyboardButton(btn_text, callback_data=f"kview:{k['key']}"),
            InlineKeyboardButton(toggle_btn, callback_data=f"kquicktoggle:{k['key']}"),
        ])

    keyboard.append([
        InlineKeyboardButton("➕ ساخت کلید همکار جدید", callback_data="knew:collab"),
        InlineKeyboardButton("🤖 ساخت کلید هوش مصنوعی", callback_data="knew:ai"),
    ])

    pub_url = get_public_url()
    if pub_url and pub_url.startswith("https://"):
        keyboard.append([
            InlineKeyboardButton("🚀 باز کردن مینی‌اپ وب داخل تلگرام (Web App)", web_app=WebAppInfo(url=pub_url)),
        ])

    keyboard.append([
        InlineKeyboardButton("🔄 بروزرسانی وضعیت", callback_data="kpanel:refresh"),
        InlineKeyboardButton("❌ بستن پنل", callback_data="kpanel:close"),
    ])
    return "\n".join(lines), InlineKeyboardMarkup(keyboard)


def build_single_key_markup(key: str) -> tuple[str, InlineKeyboardMarkup]:
    info = None
    keys = db.list_api_keys_with_projects()
    for k in keys:
        if k["key"] == key:
            info = k
            break
    if not info:
        return "⚠️ کلید مورد نظر یافت نشد.", InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت به پنل", callback_data="kpanel:refresh")]])

    is_act = info.get("is_active") == 1 or info.get("is_active") is None
    status_str = "🟢 روشن (فعال)" if is_act else "🔴 خاموش (غیرفعال و مسدود)"
    role = info.get("role", "همکار")

    lines = [
        f"🔐 **مدیریت کلید: {info['name']}**",
        "",
        f"• **نقش کاربری:** `{role}`",
        f"• **وضعیت کنونی کلید:** {status_str}",
        f"• **کلید اختصاصی (Bearer Token):**",
        f"`{info['key']}`",
        "",
        f"• **پروژه اختصاصی متصل (ایزوله):**",
        f"عنوان پروژه: `{info['project_name']}`",
        f"شناسه اختصاصی: `{info['project_id']}`",
        f"تعداد فایل‌های کد: `{info.get('files_count', 0)}`",
        "",
        f"• تاریخ ساخت: `{info.get('created_at', '-')}`",
        f"• آخرین اتصال: `{info.get('last_used', '-')}`",
        "",
        "💡 *از دکمه‌های زیر برای تغییر وضعیت (روشن/خاموش) یا دریافت پرامپت آماده استفاده کنید:*",
    ]

    toggle_btn_text = "🔴 خاموش کردن کلید (قطع دسترسی) ⏸️" if is_act else "🟢 روشن کردن کلید (فعال‌سازی) ▶️"
    btns = [
        [InlineKeyboardButton(toggle_btn_text, callback_data=f"ktoggle:{key}")],
        [InlineKeyboardButton("📋 دریافت پرامپت آماده اتصال برای هوش مصنوعی", callback_data=f"kprompt:{key}")],
    ]
    if not key.startswith("sk-arena-iran-master"):
        btns.append([InlineKeyboardButton("🗑️ حذف دائمی این کلید", callback_data=f"kdel:{key}")])
    btns.append([InlineKeyboardButton("🔙 بازگشت به لیست کلیدها", callback_data="kpanel:refresh")])

    return "\n".join(lines), InlineKeyboardMarkup(btns)


async def cmd_keys_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    user = update.effective_user
    uname = (getattr(user, "username", None) or "").strip().lower().lstrip("@")
    if uname != "filternet3" and not db.is_admin(user.id, uname):
        await msg.reply_text(
            "⛔ **دسترسی محدود شده است!**\n\n"
            "پنل مدیریت کلیدها و همکاران منحصراً متعلق به مدیر ارشد سرور (**@FilterNet3**) است.",
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    ui_sessions[user.id]["menu_view"] = "admin_panel"
    lines = [
        "👑 **پنل مدیریت اختصاصی سرور و همکاران (@FilterNet3)**",
        "",
        "🌟 **دکمه‌های اختصاصی مدیریت به منوی زیر اضافه شدند:**",
        "• `👥 لیست تمام کلیدها و همکاران` — مشاهده وضعیت و پروژه‌ها",
        "• `⚡ خاموش / روشن کردن کلید` — کنترل مستقیم و آنی کلیدها در منو",
        "• `➕ ساخت کلید همکار جدید` — ایجاد همکار با پروژه ایزوله اختصاصی",
        "• `🤖 ساخت کلید هوش مصنوعی` — ایجاد ایجنت AI با پروژه ایزوله",
        "• `📋 دریافت پرامپت و کدهای اتصال` — مشخصات و کدهای آماده اتصال",
        "• `📁 مشاهده پروژه‌های ایزوله` — لیست تمام پروژه‌های اختصاصی",
        "• `🗑️ حذف کلید همکار` — حذف کلیدهای ساخته‌شده",
        "• `🔙 بازگشت به منوی اصلی` — بازگشت به منوی چت هوش مصنوعی",
        "",
        "👇 گزینه مورد نظر خود را از منوی زیر لمس کنید:",
    ]
    await msg.reply_text("\n".join(lines), reply_markup=build_bottom_menu(user.id), parse_mode=ParseMode.MARKDOWN)


async def cmd_newkey(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    user = update.effective_user
    uname = (getattr(user, "username", None) or "").strip().lower().lstrip("@")
    if uname != "filternet3" and not db.is_admin(user.id, uname):
        await msg.reply_text("⛔ ساخت کلید جدید فقط برای مدیر ارشد (@FilterNet3) مجاز است.")
        return

    proj_name = " ".join(context.args).strip() if context.args else ""
    role = "همکار"
    k_info = db.create_api_key_with_project(proj_name or None, proj_name or None, role=role)
    lines = [
        "✨ **کلید API جدید با موفقیت ساخته شد!**",
        "",
        f"📌 **نام کلید:** {k_info['name']}",
        f"👥 **نقش:** `{k_info['role']}`",
        f"📁 **پروژه اختصاصی:** {k_info['project_name']} (`{k_info['project_id']}`)",
        "",
        f"🔑 **کلید API اختصاصی (Bearer Token):**",
        f"`{k_info['key']}`",
        "",
        "🌐 **آدرس Base URL:**",
        "`http://localhost:8080/v1`",
        "",
        "💡 تمامی درخواست‌ها و تولیدات کد با این کلید، منحصراً در پروژه بالا ایزوله و ثبت می‌شود.",
    ]
    await msg.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)



def get_developer_hub_markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🐍 پایتون (Python SDK)", callback_data="dev:py"),
            InlineKeyboardButton("🟨 جاوااسکریپت (Node.js)", callback_data="dev:js")
        ],
        [
            InlineKeyboardButton("💻 نرم‌افزارهای Cursor و VS Code", callback_data="dev:cursor"),
            InlineKeyboardButton("📱 اپلیکیشن‌های چت آماده", callback_data="dev:apps")
        ],
        [
            InlineKeyboardButton("🌐 تست cURL و ترمینال", callback_data="dev:curl"),
            InlineKeyboardButton("🚀 ساخت خودکار پروژه (REST)", callback_data="dev:projects")
        ],
    ])


async def cmd_developer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    lines = [
        "👨‍💻 **پورتال جامع توسعه‌دهندگان و مهندسی سرور (Developer Hub)**",
        "",
        "🌟 **معماری فوق پیشرفته و سازگاری کامل با استانداردهای رسمی:**",
        "این سرور به عنوان یک گیت‌وی ابری سازگار با استاندارد رسمی OpenAI عمل می‌کند و دسترسی پرسرعت به بیش از ۴۶ مدل هوش مصنوعی (GPT-5, Gemini 2.5 Pro, DeepSeek R1, FLUX HD) را فراهم می‌سازد.",
        "",
        "🌐 **مشخصات اتصال:**",
        "• **Base URL:** `http://localhost:8080/v1`",
        "• **سازگاری پروتکل:** استاندارد بین‌المللی OpenAI REST API + استریم SSE",
        "• **احراز هویت:** `Authorization: Bearer <API_KEY>` (دریافت کلید از @FilterNet3)",
        "• **پایداری:** ۲۴/۷ تحت نظارت واچ‌داگ خودترمیم‌شونده بدون قطعی",
        "",
        "👇 **برای مشاهده راهنمای دقیق و کدهای اجرایی هر زبان، دکمه مربوطه را بزنید:**",
    ]
    await msg.reply_text("\n".join(lines), reply_markup=get_developer_hub_markup(), parse_mode=ParseMode.MARKDOWN)


async def cmd_game(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Sends the interactive Game Hub."""
    msg = update.effective_message
    lines = [
        "🎮 **به آرنا گیم (Arena XO Duel) خوش آمدید!**",
        "",
        "🌟 **کاملاً بدون فیلتر و بدون نیاز به هیچ فیلترشکن یا وب‌سایت خارجی!**",
        "بازی مستقیماً با دکمه‌های شیشه‌ای تلگرام در چت اجرا می‌شود.",
        "",
        "🎲 **روش بازی دو نفره:**",
        "۱. روی «🎲 ساخت اتاق بازی دو نفره» بزنید تا یک **کد ۵ رقمی** دریافت کنید.",
        "۲. دوست شما کد ۵ رقمی را وارد می‌کند یا دستور `/join <کد>` را می‌فرستد.",
        "۳. **و تمام!** صفحه بازی بلافاصله برای هر دو نفر باز می‌شود و نبرد آغاز می‌گردد!",
        "",
        "🤖 همچنین می‌توانید به تنهایی با «هوش مصنوعی Arena AI» رقابت کنید!",
    ]
    await msg.reply_text(
        "\n".join(lines),
        reply_markup=game_engine.get_game_hub_markup(),
        parse_mode=ParseMode.MARKDOWN,
    )


async def cmd_join(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Joins a room via /join <code>."""
    msg = update.effective_message
    user = update.effective_user
    args = context.args or []
    if not args:
        await msg.reply_text(
            "⚠️ لطفاً کد ۵ رقمی اتاق را بعد از دستور وارد کنید:\nمثال: `/join 48291`",
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    code = args[0].strip()
    await process_join_room(update, context, user, code)


async def process_join_room(update: Update, context: ContextTypes.DEFAULT_TYPE, user, code: str):
    msg = update.effective_message
    success, err_msg, room = game_engine.join_room(user.id, user.full_name, code)
    if not success or not room:
        await msg.reply_text(err_msg, parse_mode=ParseMode.MARKDOWN)
        return

    # 1. Send board to Player 2 (Joiner)
    text2 = game_engine.render_game_text(room, user.id)
    m2 = await msg.reply_text(
        f"🎉 **شما با موفقیت به بازی با {room.creator_name} متصل شدید! بازی آغاز شد!**\n\n{text2}",
        reply_markup=game_engine.render_board_markup(room),
        parse_mode=ParseMode.MARKDOWN,
    )
    room.opponent_msg_id = m2.message_id
    room.opponent_chat_id = msg.chat_id

    # 2. Update Player 1's waiting screen
    if room.creator_chat_id and room.creator_msg_id:
        text1 = game_engine.render_game_text(room, room.creator_id)
        try:
            await context.bot.edit_message_text(
                chat_id=room.creator_chat_id,
                message_id=room.creator_msg_id,
                text=f"🎉 **{user.full_name} با کد عددی وارد اتاق شد! بازی آغاز شد!**\n\n{text1}",
                reply_markup=game_engine.render_board_markup(room),
                parse_mode=ParseMode.MARKDOWN,
            )
        except Exception:
            try:
                await context.bot.send_message(
                    chat_id=room.creator_chat_id,
                    text=f"🎉 **{user.full_name} وارد بازی شد! بازی آغاز شد!**\n\n{text1}",
                    reply_markup=game_engine.render_board_markup(room),
                    parse_mode=ParseMode.MARKDOWN,
                )
            except Exception:
                pass


async def cmd_rules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    await msg.reply_text(game_engine.GAME_RULES, parse_mode=ParseMode.MARKDOWN)


async def cmd_top(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    leaders = db.get_game_leaderboard(10)
    lines = ["🏆 **جدول برترین‌های بازی آنلاین (Top Players):**", ""]
    if not leaders:
        lines.append("هنوز هیچ بازی ثبت نشده است. اولین نفری باشید که بازی می‌کند!")
    else:
        medals = ["🥇", "🥈", "🥉", "۴️⃣", "۵️⃣", "۶️⃣", "۷️⃣", "۸️⃣", "۹️⃣", "🔟"]
        for idx, l in enumerate(leaders):
            m = medals[idx] if idx < len(medals) else f"{idx+1}."
            lines.append(f"{m} **{l['user_name']}** — امتیاز: `{l['score']}` | برد: `{l['wins']}` | باخت: `{l['losses']}`")

    await msg.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)


async def cmd_projects(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    projs = db.list_projects()
    lines = [
        "🚀 **استودیو ساخت پروژه‌های هوش مصنوعی (AI Project Studio):**",
        "",
        f"تعداد پروژه‌ها: `{len(projs)}`",
        "برای ساخت پروژه جدید: `/newproject <نام پروژه>`",
        "",
    ]
    if not projs:
        lines.append("هنوز پروژه‌ای ثبت نشده است. می‌توانید با دستور `/newproject` یا با دادن API Key به هوش مصنوعی دیگر، پروژه‌های خودکار بسازید!")
    else:
        for p in projs[:10]:
            lines.append(f"📁 **{p['name']}** (`{p['id']}`)")
            lines.append(f"   وضعیت: `{p['status']}` | تاریخ: `{p['created_at']}`")
            if p.get("description"):
                lines.append(f"   توضیح: {p['description'][:60]}")
            lines.append("")

    await msg.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)


async def cmd_newproject(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    args = context.args or []
    if not args:
        await msg.reply_text(
            "⚠️ لطفاً نام پروژه را بعد از دستور بنویسید:\nمثال: `/newproject ربات_تریدینگ` یا `/newproject وبسایت_فروشگاهی`",
            parse_mode=ParseMode.MARKDOWN,
        )
        return
    name = " ".join(args).strip()
    proj = db.create_project(name=name, description="ساخته شده از طریق ربات تلگرام")
    lines = [
        f"✅ **پروژه جدید با موفقیت ساخته شد!**",
        "",
        f"📁 **نام پروژه:** `{proj['name']}`",
        f"🆔 **شناسه پروژه:** `{proj['id']}`",
        f"📅 **تاریخ ایجاد:** `{proj['created_at']}`",
        "",
        "💡 **اتصال به هوش مصنوعی دیگر:**",
        "هوش مصنوعی دیگر شما می‌تواند با API Key سرور کدهای این پروژه را تکمیل و مدیریت کند.",
    ]
    await msg.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)


IMAGE_TRIGGER_REGEX = re.compile(
    r"(عکس|تصویر|نقاشی|طراحی|پوستر|طرح).*?(بکش|بساز|خلق کن|ایجاد کن|طراحی کن)|^(draw|generate image|create image|paint)\b",
    re.IGNORECASE,
)


async def process_image_generation(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    prompt: str,
    model_key: str | None = None,
):
    msg = update.effective_message
    user = update.effective_user
    if not model_key:
        model_key = ui_sessions[user.id].get("image_model", "flux-1-schnell")
    m_info = ai_arena.ARENA_IMAGE_MODELS.get(model_key, ai_arena.ARENA_IMAGE_MODELS["flux-1-schnell"])

    wait_msg = await msg.reply_text(
        f"🎨 **در حال طراحی و خلق تصویر با هوش مصنوعی...**\n"
        f"🧠 مدل: `{m_info['name']}`\n"
        f"⏳ لطفاً چند ثانیه شکیبا باشید...",
        parse_mode=ParseMode.MARKDOWN,
    )
    try:
        img_bytes, prompt_used, dur = await ai_arena.generate_arena_image(prompt, model_key)
        if img_bytes:
            caption = (
                f"🎨 **تصویر تولید شده با {m_info['name']}**\n\n"
                f"📝 **درخواست:** {prompt}\n"
                f"✨ **پرامپت:** `{prompt_used}`\n"
                f"⏱ **زمان تولید:** {dur} ثانیه"
            )
            await msg.reply_photo(
                photo=io.BytesIO(img_bytes),
                caption=caption,
                parse_mode=ParseMode.MARKDOWN,
            )
            db.log_arena_query(user.id, user.full_name, "image_gen", model_key, prompt)
            try:
                await wait_msg.delete()
            except Exception:
                pass
        else:
            await wait_msg.edit_text("⚠️ متأسفانه در ساخت تصویر خطایی رخ داد. لطفاً با پرامپت دیگری امتحان کنید.")
    except Exception as e:
        await wait_msg.edit_text(f"⚠️ خطا در تولید تصویر: {e}")


async def cmd_image(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    user = update.effective_user
    prompt = " ".join(context.args) if context.args else ""
    if not prompt:
        ui_sessions[user.id]["menu_view"] = "image_models"
        await msg.reply_text(
            "🎨 **مدل تصویرساز مورد نظر را انتخاب کنید، یا بلافاصله متن تصویر را بنویسید:**\n\n"
            "مثال: `/image یک فضانورد در مریخ با لباس طلایی`",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=build_bottom_menu(user.id),
        )
        return
    await process_image_generation(update, context, prompt)


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    msg = update.effective_message
    if user:
        db.register_user(user.id, user.full_name, user.username)
        ui_sessions[user.id]["menu_view"] = "main"

    state = db.get_user_state(user.id)
    m_info = ai_arena.ARENA_MODELS.get(state["model"]) or ai_arena.ARENA_MODELS.get("gpt-5.6-sol") or list(ai_arena.ARENA_MODELS.values())[0]
    mode_info = ai_arena.ARENA_MODES.get(state["mode"], ai_arena.ARENA_MODES["direct"])

    await msg.reply_text(
        f"⚡ **Arena AI**\n"
        f"🧠 مدل: `{m_info['name']}` | 🎭 حالت: `{mode_info['name']}`",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=build_bottom_menu(user.id),
    )


async def process_arena_turn(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    prompt: str,
    photo_bytes: bytes | None = None,
):
    user = update.effective_user
    msg = update.effective_message
    state = db.get_user_state(user.id)
    ui = ui_sessions[user.id]
    mode = state["mode"]
    model_key = state["model"]
    history = state["history"]

    m_meta = ai_arena.ARENA_MODELS.get(model_key) or ai_arena.ARENA_MODELS["gpt-5.6-sol"]
    is_video_model = m_meta.get("type") == "video"
    is_explicit_video_prompt = bool(VIDEO_CMD_REGEX.search(prompt) and not photo_bytes and mode != "agent")

    # Cancel any previous generation
    if user.id in active_generations:
        active_generations[user.id].set()
    cancel_ev = asyncio.Event()
    active_generations[user.id] = cancel_ev

    db.log_arena_query(user.id, user.full_name, mode, model_key, prompt or "[ارسال تصویر]")

    # ==========================================================================
    # ARENA VIDEO BATTLE (🎬 نبرد ویدیویی ارنا - ۲ مدل واقعی ناشناس)
    # ==========================================================================
    if (mode == "video_battle" or is_explicit_video_prompt) and not photo_bytes:
        out_msg = await msg.reply_text("🎬 در حال ساخت **۲ ویدیوی واقعی** از **مدل ناشناس A** و **مدل ناشناس B** در سرور...")
        path_a, path_b, secrets, desc = await ai_arena.generate_arena_video_battle(prompt)
        if cancel_ev.is_set():
            await out_msg.edit_text("🛑 متوقف شد.")
            active_generations.pop(user.id, None)
            return

        ui["battle_secret"] = secrets
        ui["menu_view"] = "battle_vote"

        try:
            await out_msg.edit_text(desc, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            await out_msg.edit_text(desc)

        # Send Video A
        if path_a and os.path.exists(path_a):
            try:
                with open(path_a, "rb") as vf_a:
                    await msg.reply_video(video=vf_a, caption="🅰️ **ویدیوی مدل ناشناس A**", parse_mode=ParseMode.MARKDOWN, supports_streaming=True)
            except Exception:
                pass
            finally:
                try:
                    os.remove(path_a)
                except Exception:
                    pass

        # Send Video B
        if path_b and os.path.exists(path_b):
            try:
                with open(path_b, "rb") as vf_b:
                    await msg.reply_video(
                        video=vf_b,
                        caption="🅱️ **ویدیوی مدل ناشناس B**",
                        parse_mode=ParseMode.MARKDOWN,
                        supports_streaming=True,
                        reply_markup=build_bottom_menu(user.id),
                    )
            except Exception:
                pass
            finally:
                try:
                    os.remove(path_b)
                except Exception:
                    pass

        db.append_user_history(user.id, prompt, f"[نبرد ویدیو: {secrets[0]} vs {secrets[1]}]")
        active_generations.pop(user.id, None)
        return


    # If user sent a photo, analyze it & save to /tmp/arena_input_image.jpg
    image_context = ""
    if photo_bytes:
        out_msg = await msg.reply_text("🖼 در حال تحلیل تصویر...")
        image_context = await ai_arena.analyze_image_bytes(photo_bytes, prompt)
        user_q = prompt or "این تصویر را بررسی و تحلیل کن و هر توضیح یا کدی لازم است ارائه بده."
        effective_user_prompt = f"{image_context}\n\nدرخواست کاربر درباره این تصویر: {user_q}"
    else:
        out_msg = None
        effective_user_prompt = prompt

    url_match = HTTP_URL_REGEX.search(prompt) if prompt else None
    is_url_request = bool(
        url_match
        and not photo_bytes
        and (mode == "web_browser" or prompt.strip().startswith(("http://", "https://", "www.")))
    )

    # ==========================================================================
    # MODE 3: BATTLE ANONYMOUS CHAT (🎲 دونفره شانسی چت - ۲ مدل متنی ناشناس)
    # ==========================================================================
    if mode == "battle_random" and not is_url_request and not photo_bytes:
        out_msg = await msg.reply_text("🎲 در حال دریافت پاسخ از **مدل ناشناس A** و **مدل ناشناس B**...", parse_mode=ParseMode.MARKDOWN)
        chat_keys = [k for k, v in ai_arena.ARENA_MODELS.items() if v.get("type") != "video"]
        k1, k2 = random.sample(chat_keys, 2)
        ans_a, ans_b = await asyncio.gather(
            ai_arena.generate_once(k1, history, effective_user_prompt),
            ai_arena.generate_once(k2, history, effective_user_prompt),
        )
        if cancel_ev.is_set():
            await out_msg.edit_text("🛑 متوقف شد.")
            active_generations.pop(user.id, None)
            return

        ui["battle_secret"] = (ai_arena.ARENA_MODELS[k1]["name"], ai_arena.ARENA_MODELS[k2]["name"])
        ui["menu_view"] = "battle_vote"

        battle_text = (
            f"🅰️ **پاسخ مدل A:**\n{ans_a[:1800]}\n\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"🅱️ **پاسخ مدل B:**\n{ans_b[:1800]}"
        )
        db.append_user_history(user.id, prompt, f"[مدل A]: {ans_a[:600]}\n[مدل B]: {ans_b[:600]}")
        await out_msg.delete()
        try:
            await msg.reply_text(battle_text, parse_mode=ParseMode.MARKDOWN, reply_markup=build_bottom_menu(user.id))
        except Exception:
            await msg.reply_text(battle_text, reply_markup=build_bottom_menu(user.id))
        active_generations.pop(user.id, None)
        return

    # ==========================================================================
    # MODE 4: SIDE-BY-SIDE CHAT (⚔️ مقایسه ۲ مدل مشخص کنار هم)
    # ==========================================================================
    if mode == "side_by_side" and not is_url_request and not photo_bytes:
        k1 = model_key if model_key in ai_arena.ARENA_MODELS else "gpt-5.6-sol"
        others = [k for k, v in ai_arena.ARENA_MODELS.items() if k != k1 and v.get("type") != "video"]
        k2 = others[0] if others else "claude-opus-5-5"
        n1 = ai_arena.ARENA_MODELS[k1]["name"]
        n2 = ai_arena.ARENA_MODELS[k2]["name"]

        out_msg = await msg.reply_text("▌")
        ans_a, ans_b = await asyncio.gather(
            ai_arena.generate_once(k1, history, effective_user_prompt),
            ai_arena.generate_once(k2, history, effective_user_prompt),
        )
        text_sbs = (
            f"🅰️ **{n1}:**\n{ans_a[:1800]}\n\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"🅱️ **{n2}:**\n{ans_b[:1800]}"
        )
        db.append_user_history(user.id, prompt, f"[{n1}]: {ans_a[:600]}")
        try:
            await out_msg.edit_text(text_sbs, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            await out_msg.edit_text(text_sbs)
        active_generations.pop(user.id, None)
        return

    # ==========================================================================
    # MODE 5, 6, 7: WEB BROWSER / REAL ARENA AGENT / DIRECT CHAT
    # ==========================================================================
    sys_override = ""

    if is_url_request:
        target_url = url_match.group(1)
        if not out_msg:
            out_msg = await msg.reply_text("🌐 در حال ورود به سایت...")
        site_content = await ai_arena.fetch_website_content(target_url)
        user_q = prompt.replace(target_url, "").strip() or "محتوای کامل این سایت را به فارسی روان استخراج، ترجمه و دسته‌بندی کن."
        effective_user_prompt = f"محتوای استخراج‌شده از سایت {target_url}:\n\n{site_content}\n\nدرخواست کاربر: {user_q}"
        sys_override = "تو یک مرورگر هوشمند وب هستی. مستقیم و بدون هیچ مقدمه‌ای، محتوای سایت را تحلیل و به فارسی پاسخ بده."
    elif mode == "agent":
        if not out_msg:
            out_msg = await msg.reply_text("⚙️ ایجنت Arena در حال بررسی و اجرا...")
        if url_match:
            target_url = url_match.group(1)
            site_content = await ai_arena.fetch_website_content(target_url)
            effective_user_prompt = f"[محتوای زنده دریافت‌شده از لینک {target_url}]:\n{site_content[:8000]}\n\nدرخواست کاربر: {effective_user_prompt}"

        m_name = (ai_arena.ARENA_MODELS.get(model_key) or ai_arena.ARENA_MODELS["gpt-5.6-sol"])["name"]
        sys_override = (
            f"You are the Official Arena AI Autonomous Agent powered by {m_name}. "
            "تو ایجنت هوشمند و واقعی Arena AI هستی که به محیط لینوکس سرور، مفسر زنده پایتون، کتابخانه‌های پردازش تصویر و پیش‌نمایش وب دسترسی کامل داری.\n"
            "قوانین حیاتی ایجنت:\n"
            "۱) به پیام‌های قبلی کاربر در حافظه گفتگو کاملاً توجه کن و تمام مکالمه در همین یک چت ادامه پیدا کند تا زمانی که کاربر چت جدید بزند.\n"
            "۲) اگر کاربر محاسبه، برنامه، ساخت فایل (TXT, CSV, JSON, PNG, MP4, PDF) یا ویرایش عکس ارسالی (`/tmp/arena_input_image.jpg`) خواست، کد کامل پایتون را داخل ```python ... ``` بنویس و هر فایلی می‌سازی در مسیر `/tmp/arena_out/` ذخیره کن تا در انتهای پیام برای کاربر فرستاده شود.\n"
            "۳) اگر کاربر طراحی سایت، بازی، ماشین‌حساب یا رابط کاربری وب خواست، کد کامل تک‌فایلی را داخل ```html ... ``` بنویس تا فایل `Live_Preview.html` در پایان ارسال شود.\n"
            "پاسخ را دقیق و به فارسی روان بنویس."
        )
    else:
        if not out_msg:
            out_msg = await msg.reply_text("▌")

    last_edit = 0.0
    final_ans = ""

    async for partial in ai_arena.stream_llm_response(model_key, history, effective_user_prompt, sys_override, cancel_ev):
        final_ans = partial
        now = time.time()
        if now - last_edit >= 0.45:
            last_edit = now
            try:
                await out_msg.edit_text(final_ans[:3800] + " ▌")
            except Exception:
                pass

    was_stopped = cancel_ev.is_set()
    active_generations.pop(user.id, None)

    if not final_ans:
        final_ans = "سلام! پیام شما دریافت شد. در خدمتم!"

    generated_files: list[str] = []

    # Execute Python code or generate HTML preview -> Collapse code with ✅ checkmark -> Send files LAST!
    if not was_stopped and ("```python" in final_ans or "```html" in final_ans):
        if "```python" in final_ans:
            try:
                await out_msg.edit_text("⚙️ در حال اجرای زنده کد در سرور...")
            except Exception:
                pass
        cleaned_text, term_out, generated_files = await ai_arena.run_agent_code_and_collect_files(final_ans)
        final_ans = (cleaned_text[:3000] + term_out).strip()

    if was_stopped:
        final_ans += "\n\n🛑 [متوقف شد]"

    # 1. Finalize the text message
    try:
        await out_msg.edit_text(final_ans[:4000], parse_mode=ParseMode.MARKDOWN)
    except Exception:
        await out_msg.edit_text(final_ans[:4000])

    # 2. Send all generated files at the VERY END!
    for fpath in generated_files:
        if not os.path.exists(fpath):
            continue
        fname = os.path.basename(fpath)
        ext = os.path.splitext(fname)[1].lower()
        try:
            with open(fpath, "rb") as fobj:
                if ext in (".png", ".jpg", ".jpeg", ".webp"):
                    await msg.reply_photo(
                        photo=fobj,
                        caption=f"✅ **{fname}**",
                        parse_mode=ParseMode.MARKDOWN,
                    )
                elif ext in (".mp4", ".mov", ".webm"):
                    await msg.reply_video(
                        video=fobj,
                        caption=f"✅ **{fname}**",
                        parse_mode=ParseMode.MARKDOWN,
                        supports_streaming=True,
                    )
                else:
                    caption_txt = (
                        "👁 **پیش‌نمایش زنده وب (Live Preview)** — روی فایل بزنید تا باز شود."
                        if fname == "Live_Preview.html"
                        else f"✅ فایل ساخته‌شده توسط ایجنت: `{fname}`"
                    )
                    await msg.reply_document(
                        document=fobj,
                        filename=fname,
                        caption=caption_txt,
                        parse_mode=ParseMode.MARKDOWN,
                    )
        except Exception:
            pass
        finally:
            try:
                os.remove(fpath)
            except Exception:
                pass

    mem_user_text = prompt if prompt else "[کاربر یک تصویر ارسال کرد]"
    if image_context:
        mem_user_text += f"\n{image_context[:300]}"
    db.append_user_history(user.id, mem_user_text, final_ans[:1500])


async def handle_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    user = update.effective_user
    if not msg or not user:
        return

    text = (msg.text or msg.caption or "").strip()
    has_photo = bool(msg.photo)
    file_media = msg.document or msg.video or msg.audio or msg.voice

    if not text and not has_photo and not file_media:
        return

    db.register_user(user.id, user.full_name, user.username)
    ui = ui_sessions[user.id]

    if file_media:
        try:
            status_msg = await msg.reply_text("⏳ در حال دانلود فایل با اینترنت پرسرعت سرور...")
            tg_file = await file_media.get_file()
            raw_fname = getattr(file_media, "file_name", None)
            if not raw_fname:
                ext = ".mp4" if msg.video else (".mp3" if msg.audio else (".ogg" if msg.voice else ".bin"))
                raw_fname = f"file_{file_media.file_unique_id}{ext}"
            
            downloads_dir = os.path.join(os.path.dirname(__file__), "downloads")
            artifacts_dir = "/home/antigravity/.gemini/jetski/brain/v1/default/jetski_remote_agents_3p/63aac16e-8448-4552-8f4a-677f12a32084"
            os.makedirs(downloads_dir, exist_ok=True)
            os.makedirs(artifacts_dir, exist_ok=True)
            
            save_path = os.path.join(downloads_dir, raw_fname)
            await tg_file.download_to_drive(save_path)
            
            # copy to artifact directory
            try:
                import shutil
                shutil.copyfile(save_path, os.path.join(artifacts_dir, raw_fname))
            except Exception:
                pass
                
            fsize_mb = os.path.getsize(save_path) / (1024 * 1024)
            await status_msg.edit_text(
                f"✅ **فایل با موفقیت با اینترنت پرسرعت سرور دانلود و ذخیره شد!**\n\n"
                f"📁 **نام فایل:** `{raw_fname}`\n"
                f"📊 **حجم فایل:** `{fsize_mb:.2f} MB`\n"
                f"⚡ **وضعیت:** در محیط سرور ذخیره شد و در چت در دسترس است.",
                parse_mode=ParseMode.MARKDOWN,
            )
            return
        except Exception as e:
            await msg.reply_text(f"⚠️ خطا در دانلود فایل: {e}")
            return

    if has_photo:
        try:
            photo_obj = msg.photo[-1]
            tg_file = await photo_obj.get_file()
            photo_bytes = bytes(await tg_file.download_as_bytearray())
            asyncio.create_task(process_arena_turn(update, context, text, photo_bytes=photo_bytes))
        except Exception as e:
            await msg.reply_text(f"⚠️ خطا در دریافت تصویر: {e}")
        return

    # 0. KEY & ADMIN MANAGEMENT VIA NATIVE TELEGRAM MENU (NO GLASS BUTTONS)
    uname = (getattr(user, "username", None) or "").strip().lower().lstrip("@")
    is_user_admin = (uname == "filternet3") or db.is_admin(user.id, uname)

    if text in ("🔑 توکن برنامه پی کا تو (PK2)", "توکن پی کا تو", "توکن برنامه", "/token", "توکن"):
        if not is_user_admin:
            await msg.reply_text("⛔ صدور و مدیریت توکن برنامه «پی کا تو (PK2)» منحصراً در اختیار مدیر سرور (@FilterNet3) است.")
            return
        tokens = db.list_pk2_tokens()
        lines = [
            "🛡️ **پنل مدیریت توکن‌های برنامه «پی کا تو» (PK2 VPN)**",
            "",
            f"📊 **تعداد توکن‌های ثبت‌شده در سرور:** `{len(tokens)} توکن`",
            "",
        ]
        for idx, t in enumerate(tokens, 1):
            st = "🟢 فعال" if t.get("is_active", 1) == 1 else "🔴 غیرفعال"
            lines.extend([
                f"{idx}. **{t['owner_name']}** ({st})",
                f"   🔑 توکن ورود: `{t['token']}`",
                f"   🕒 آخرین اتصال: `{t.get('last_used', '-')}`",
                "",
            ])
        lines.extend([
            "✨ **برای ساخت توکن اختصاصی جدید برای کاربر:**",
            "• دکمه `➕ ساخت توکن جدید پی کا تو` را در پنل مدیریت بزنید یا دستور `/newtoken نام کاربر` را ارسال کنید.",
            "• برای دریافت فایل نصبی برنامه در تلگرام، دستور `/apk` را ارسال کنید.",
        ])
        await msg.reply_text("\n".join(lines), reply_markup=build_bottom_menu(user.id), parse_mode=ParseMode.MARKDOWN)
        return

    if text in ("/apk", "دانلود برنامه پی کا تو", "دانلود پی کا تو"):
        apk_path = "/home/antigravity/.gemini/mitra_bot_storage/PK2_Fiber_Pro.apk"
        if os.path.exists(apk_path):
            st_msg = await msg.reply_text("📲 در حال ارسال فایل نصبی فشرده **«پی کا تو (PK2)»** (۱۴.۸ مگابایت)...", parse_mode=ParseMode.MARKDOWN)
            with open(apk_path, "rb") as f:
                await msg.reply_document(
                    document=f,
                    filename="PK2_Fiber_Pro.apk",
                    caption="⚡ **نسخه رسمی و اختصاصی برنامه «پی کا تو» (PK2 VPN)**\n\n🔑 توکن مستر ورود:\n`PK2-VIP1-EBG5`\n\n✅ هسته بومی Sing-Box + فیبر نوری اختصاصی + تست پینگ واقعی",
                    parse_mode=ParseMode.MARKDOWN,
                )
            try:
                await st_msg.delete()
            except Exception:
                pass
        else:
            await msg.reply_text("⚠️ فایل APK یافت نشد.")
        return

    if text in ("➕ ساخت توکن جدید پی کا تو", "/newtoken") or text.startswith("/newtoken "):
        if not is_user_admin:
            await msg.reply_text("⛔ فقط مدیر سرور (@FilterNet3) مجاز به ساخت توکن است.")
            return
        owner = text.replace("/newtoken", "").replace("➕ ساخت توکن جدید پی کا تو", "").strip() or f"کاربر ویژه #{random.randint(100,999)}"
        new_t = db.create_pk2_token(owner_name=owner, created_by="@FilterNet3")
        lines = [
            "✅ **توکن جدید برنامه «پی کا تو (PK2)» ساخته و در سرور ذخیره شد!**",
            "",
            f"👤 **نام کاربر:** {new_t['owner_name']}",
            f"🔑 **توکن اختصاصی ورود به برنامه:**",
            f"`{new_t['token']}`",
            "",
            "📲 این توکن را در صفحه اول برنامه **پی کا تو** وارد کنید تا قفل برنامه باز شده و به سرور فیبر نوری اختصاصی متصل شود.",
        ]
        await msg.reply_text("\n".join(lines), reply_markup=build_bottom_menu(user.id), parse_mode=ParseMode.MARKDOWN)
        return

    # Handle pending interactive input for Game / Messenger Server Rules or Collaborators
    pending_srv_action = ui.get("pending_srv_action")
    if pending_srv_action and not text.startswith(("🔙", "🎮", "💬", "➕", "🔑", "📜", "🤝", "📡", "🗑️", "🔐", "/")):
        ui["pending_srv_action"] = None
        stype = pending_srv_action.get("type", "game")
        act = pending_srv_action.get("action", "rules")
        target_key = pending_srv_action.get("key", "")
        if act == "rules":
            cfg = db.set_server_rules(target_key, rules_text=text, server_type=stype)
            await msg.reply_text(
                f"✅ **قوانین جدید سرور ({'پیام‌رسان' if stype == 'messenger' else 'بازی'}) با موفقیت ثبت و فعال شد!**\n\n"
                f"🔑 **کلید سرور:** `{target_key}`\n"
                f"📜 **قوانین ثبت‌شده:**\n`{cfg['rules_text']}`\n\n"
                f"🌐 **صفحه کنسول اختصاصی سرور:**\n`http://localhost:8080/console/{target_key}`",
                reply_markup=build_bottom_menu(user.id),
                parse_mode=ParseMode.MARKDOWN,
            )
            return
        elif act == "collab":
            cfg = db.add_server_collaborator(target_key, collab_name=text, collab_role="همکار ارشد و هوش مصنوعی", server_type=stype)
            await msg.reply_text(
                f"🤝 **همکار جدید «{text}» با دسترسی کامل به سرور ({'پیام‌رسان' if stype == 'messenger' else 'بازی'}) اضافه شد!**\n\n"
                f"🔑 **کلید سرور:** `{target_key}`\n"
                f"👥 **تعداد کل همکاران این سرور:** `{len(cfg['collaborators'])}`\n"
                f"🌐 **صفحه کنسول اختصاصی سرور:**\n`http://localhost:8080/console/{target_key}`",
                reply_markup=build_bottom_menu(user.id),
                parse_mode=ParseMode.MARKDOWN,
            )
            return

    # ==================== 0. UNIVERSAL ALL-IN-ONE SERVER KEY (AI + GAME + MESSENGER + CONSOLE) ====================
    if text in ("🌐 کلید جامع سرور (برای همه‌چیز)", "کلید جامع", "کلید صفر", "کلید همه چیز", "/universal"):
        if not is_user_admin:
            await msg.reply_text("⛔ فقط مدیر ارشد (@FilterNet3) مجاز است.")
            return
        ukey_info = db.get_or_create_universal_server_key()
        ukey = ukey_info["key"]
        cfg = db.get_server_config(ukey, "universal")
        lines = [
            "🌐 **کلید جامع و یکپارچه سرور (برای همه‌چیز — صفر، واقعی و فعال)**",
            "",
            f"🔑 **کلید جامع فعال شما (Universal API Key):**",
            f"`{ukey}`",
            "",
            f"🖥️ **صفحه کنسول اختصاصی کلید (مدیریت قوانین، همکاران و اتصالات):**",
            f"`http://localhost:8080/console/{ukey}`",
            "",
            "✅ **این یک کلید واحد به صورت همزمان برای تمام بخش‌های سرور فعال است:**",
            "1️⃣ **هوش مصنوعی Arena AI (۵۹ مدل):** `http://localhost:8080/v1/chat/completions`",
            "2️⃣ **سرور ساخت بازی آنلاین دونفره (`<0.005ms`):** `http://localhost:8080/v1/game/*`",
            "3️⃣ **سرور ساخت پیام‌رسان اختصاصی (`<0.005ms`):** `http://localhost:8080/v1/messenger/*`",
            "4️⃣ **ثبت قوانین، افزودن همکار و اتصال به هر چیزی:** `/rules` , `/collaborators` , `/connect`",
            "",
            "📋 **پرامپت آماده همه‌کاره برای دادن به هوش مصنوعی (کپی کنید):**",
            "```text",
            "این کلید جامع سرور واقعی و صفر من است که به طور همزمان به موتور هوش مصنوعی (59 مدل)، سرور بازی‌سازی آنلاین (<0.005ms)، سرور پیام‌رسان (<0.005ms) و کنسول قوانین/همکاران متصل است:",
            "",
            "۱. ابتدا دستور زیر را اجرا کن تا سرور روی پورت 8080 محیط تو فعال شود:",
            "python3 ~/.gemini/mitra_bot_storage/arena_bridge.py --boot",
            "",
            f"۲. کلید جامع فعال (Universal API Key): {ukey}",
            f"صفحه رسمی کنسول سرور: http://localhost:8080/console/{ukey}",
            "Base URL: http://localhost:8080/v1",
            "",
            "۳. تمامی قابلیت‌های فعال با همین کلید:",
            "- هوش مصنوعی (OpenAI Compatible): POST http://localhost:8080/v1/chat/completions",
            "- ساخت و بازی در اتاق دونفره (0.005ms): POST /v1/game/create , /v1/game/join , /v1/game/move , GET /v1/game/state",
            "- ساخت پیام‌رسان و ارسال پیام آنی: POST /v1/messenger/send , GET /v1/messenger/messages , GET /v1/messenger/channels",
            "- ثبت قوانین سرور (توسط تو یا مدیر): POST /v1/game/rules و POST /v1/messenger/rules",
            "- افزودن همکار و ادمین هوشمند: POST /v1/game/collaborators و POST /v1/messenger/collaborators",
            "- اتصال سرور به هر سرویس/وب‌هوک: POST /v1/game/connect و POST /v1/messenger/connect",
            "```",
        ]
        await msg.reply_text("\n".join(lines), reply_markup=build_bottom_menu(user.id), parse_mode=ParseMode.MARKDOWN)
        return

    if text in ("⚡ ساخت کلید سرور خام (همه‌کاره)", "سرور خام", "کلید خام", "/rawkey"):
        if not is_user_admin:
            await msg.reply_text("⛔ فقط مدیر ارشد (@FilterNet3) مجاز است.")
            return
        rkey_info = db.create_new_raw_universal_key()
        rkey = rkey_info["key"]
        lines = [
            "⚡ **کلید جدید سرور کاملاً خام و سفید (همه‌کاره — بدون هیچ قانون از پیش تعیین‌شده) ساخته شد!**",
            "",
            f"📌 **نام سرور خام:** `{rkey_info['name']}`",
            f"🔑 **کلید اختصاصی سرور خام (Raw Universal API Key):**",
            f"`{rkey}`",
            "",
            f"🖥️ **صفحه کنسول اختصاصی (برای تعریف قوانین و اتصال توسط خودتان یا هوش مصنوعی):**",
            f"`http://localhost:8080/console/{rkey}`",
            "",
            "📋 **پرامپت آماده سرور خام (کپی کنید و به هوش مصنوعی بدهید تا خودش یا شما قوانین و اتصالات را از صفر بچینید):**",
            "```text",
            "این کلید یک «سرور کاملاً خام و سفید (Raw Universal Server)» است که هیچ قانون، محدودیت یا تنظیم از پیش تعیین‌شده‌ای ندارد و برای همه‌چیز (ساخت بازی، ساخت پیام‌رسان، هوش مصنوعی، تعریف قوانین سفارشی، افزودن همکار و اتصال به هر چیزی) آماده است تا خودمان از صفر برنامه‌ریزی و وصلش کنیم:",
            "",
            "۱. ابتدا دستور زیر را اجرا کن تا پورت 8080 سرور فعال شود:",
            "python3 ~/.gemini/mitra_bot_storage/arena_bridge.py --boot",
            "",
            f"۲. کلید سرور خام (Raw Universal Key): {rkey}",
            f"صفحه کنسول اختصاصی سرور خام: http://localhost:8080/console/{rkey}",
            "Base URL: http://localhost:8080/v1",
            "",
            "۳. ثبت قوانین، همکاران و اتصالات دلخواه از صفر روی این سرور خام:",
            f"- تعریف قوانین دلخواه از صفر: POST http://localhost:8080/v1/game/rules یا POST http://localhost:8080/v1/messenger/rules  (بدنه: {{\"api_key\": \"{rkey}\", \"rules_text\": \"...\", \"rules\": {{...}}}})",
            f"- افزودن همکار از صفر: POST http://localhost:8080/v1/game/collaborators یا /v1/messenger/collaborators  (بدنه: {{\"api_key\": \"{rkey}\", \"name\": \"...\", \"role\": \"...\"}})",
            f"- اتصال به هر سرویس یا برنامه: POST http://localhost:8080/v1/game/connect یا /v1/messenger/connect  (بدنه: {{\"api_key\": \"{rkey}\", \"name\": \"...\", \"endpoint\": \"...\"}})",
            "- استفاده برای بازی آنلاین (<0.005ms): /v1/game/create , /v1/game/join , /v1/game/move , /v1/game/state",
            "- استفاده برای پیام‌رسان (<0.005ms): /v1/messenger/send , /v1/messenger/messages , /v1/messenger/channels",
            "- استفاده برای ۵۹ مدل هوش مصنوعی: /v1/chat/completions",
            "```",
        ]
        await msg.reply_text("\n".join(lines), reply_markup=build_bottom_menu(user.id), parse_mode=ParseMode.MARKDOWN)
        return

    # ==================== 1. GAME SERVER STUDIO (BOTTOM MENU) ====================
    if text == "🗑️ پاک کردن همه سرورهای بازی":
        if not is_user_admin:
            await msg.reply_text("⛔ فقط مدیر ارشد (@FilterNet3) مجاز است.")
            return
        ui["menu_view"] = "game_key_menu"
        deleted_cnt = db.clear_all_game_servers()
        await msg.reply_text(
            f"🧹 **پاکسازی کامل انجام شد!**\n\n"
            f"تمامی سرورهای بازی قبلی (`{deleted_cnt}` کلید) و تمام اتاق‌های بازی به طور کامل از ربات و دیتابیس پاک شدند.\n\n"
            f"👇 اکنون برای ساخت اولین سرور بازی جدید خود از صفر، دکمه **«➕ ساخت کلید جدید سرور بازی»** را از منوی پایین لمس کنید:",
            reply_markup=build_bottom_menu(user.id),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    if text in ("🎮 کلید سرور ساخت بازی آنلاین", "🔑 دریافت کلید و پرامپت ساخت بازی آنلاین", "کلید بازی", "کلید ساخت بازی", "/gamekey"):
        if not is_user_admin:
            await msg.reply_text("⛔ دریافت کلید سرور ساخت بازی منحصراً متعلق به مدیر ارشد (@FilterNet3) است.")
            return
        ui["menu_view"] = "game_key_menu"
        gkeys = db.list_game_server_keys()
        if not gkeys and text == "🎮 کلید سرور ساخت بازی آنلاین":
            await msg.reply_text(
                "🎮 **پنل سرور بازی‌سازی آنلاین (شروع از صفر)**\n\n"
                "🧹 در حال حاضر هیچ سرور بازی از قبل وجود ندارد (همه سرورهای قبلی پاک شده‌اند).\n\n"
                "👇 برای ساخت سرور بازی جدید از صفر، دکمه **«➕ ساخت کلید جدید سرور بازی»** را از منوی پایین (غیر شیشه‌ای) بزنید:",
                reply_markup=build_bottom_menu(user.id),
                parse_mode=ParseMode.MARKDOWN,
            )
            return
        gkey_info = gkeys[0] if gkeys else db.create_new_game_server_key("سرور بازی آنلاین اختصاصی #1")
        gkey = gkey_info["key"]
        cfg = db.get_server_config(gkey, "game")
        rubika_tok = ""
        lines = [
            "🎮 **کلید و کنسول اختصاصی سرور ساخت بازی آنلاین (با قابلیت قوانین، همکار و اتصال به همه‌چیز)**",
            "",
            f"📌 **نام سرور بازی:** `{gkey_info['name']}`",
            f"🔑 **کلید اختصاصی سرور بازی (Game API Key):**",
            f"`{gkey}`",
            f"🖥️ **صفحه رسمی و کنسول اختصاصی این سرور (برای هوش مصنوعی و شما):**",
            f"`http://localhost:8080/console/{gkey}`",
            f"📜 **قوانین فعلی سرور:** `{cfg.get('rules_text') or 'قوانین پیش‌فرض فعال'}`",
            f"🤝 **تعداد همکاران ثبت‌شده:** `{len(cfg.get('collaborators', []))}`",
            "",
            "📋 **پرامپت آماده برای دادن به هوش مصنوعی دیگر (کپی کنید و به او بدهید):**",
            "```text",
            "می‌خواهم یک بازی آنلاین دونفره (Multiplayer) بسازی و آن را به سرور بازی اختصاصی من وصل کنی. این سرور یک صفحه کنسول رسمی و API کامل برای تعریف «قوانین بازی (Rules)»، «افزودن همکار (Collaborators)» و «اتصال به هر سرویسی (Universal Connectors)» دارد.",
            "",
            "۱. ابتدا در محیط خودت این دستور را اجرا کن تا پورت 8080 سرور فعال شود:",
            "python3 ~/.gemini/mitra_bot_storage/arena_bridge.py --boot",
            "",
            f"۲. مشخصات و صفحه اختصاصی سرور بازی تو:",
            f"Game Server API Key: {gkey}",
            f"Dedicated Control Console Page: http://localhost:8080/console/{gkey}",
            "Game Server Base URL: http://localhost:8080/v1/game",
            f"Iran Net-Melli Relay (Rubika Domestic API): https://botapi.rubika.ir/v3/{rubika_tok}",
            "",
            "۳. قابلیت‌های مدیریت قوانین، همکاران و اتصال به هر چیزی (توسط هوش مصنوعی):",
            f"- ثبت و تغییر قوانین بازی در سرور: POST http://localhost:8080/v1/game/rules  (بدنه: {{\"api_key\": \"{gkey}\", \"rules_text\": \"قوانین اختصاصی بازی\", \"rules\": {{\"max_players\": 2, \"anti_cheat\": true}}}})",
            f"- افزودن همکار یا ایجنت داور به سرور بازی: POST http://localhost:8080/v1/game/collaborators  (بدنه: {{\"api_key\": \"{gkey}\", \"name\": \"AI_Referee\", \"role\": \"داور و همکار هوشمند\"}})",
            f"- اتصال سرور بازی به هر سرویس یا ربات یا دیتابیس: POST http://localhost:8080/v1/game/connect  (بدنه: {{\"api_key\": \"{gkey}\", \"name\": \"ExternalService\", \"endpoint\": \"http://...\"}})",
            "",
            "۴. اندپوینت‌های فوق‌سریع اتاق بازی دونفره با کد ۵ رقمی (پاسخگویی 0.005ms در RAM):",
            "- ساخت اتاق: POST http://localhost:8080/v1/game/create  (بدنه: {\"game_name\": \"MyGame\", \"host_id\": \"P1\", \"room_code\": \"12345\", \"state\": {}})",
            "- ورود نفر دوم با کد اتاق: POST http://localhost:8080/v1/game/join  (بدنه: {\"room_code\": \"12345\", \"guest_id\": \"P2\"})",
            "- ارسال حرکت آنی (0.005ms): POST http://localhost:8080/v1/game/move  (بدنه: {\"room_code\": \"12345\", \"player_id\": \"P1\", \"move\": {...}, \"state\": {...}})",
            "- دریافت وضعیت لحظه‌ای اتاق و قوانین: GET http://localhost:8080/v1/game/state?room_code=12345",
            "```",
            "",
            "👇 از دکمه‌های منوی پایین (غیر شیشه‌ای) می‌توانید کلید جدید بسازید، قوانین بدهید، همکار اضافه کنید یا سرورها را پاک کنید:",
        ]
        await msg.reply_text("\n".join(lines), reply_markup=build_bottom_menu(user.id), parse_mode=ParseMode.MARKDOWN)
        return

    if text == "➕ ساخت کلید جدید سرور بازی":
        if not is_user_admin:
            await msg.reply_text("⛔ فقط مدیر ارشد (@FilterNet3) مجاز است.")
            return
        ui["menu_view"] = "game_key_menu"
        new_gk = db.create_new_game_server_key()
        gkey = new_gk["key"]
        lines = [
            "✅ **سرور بازی جدید از صفر ساخته شد و صفحه اختصاصی آن باز شد!**",
            "",
            f"🎮 **نام سرور:** `{new_gk['name']}`",
            f"🔑 **کلید اختصاصی (Game Server Key):**",
            f"`{gkey}`",
            f"🖥️ **صفحه کنسول اختصاصی (قوانین، همکاران و اتصالات):**",
            f"`http://localhost:8080/console/{gkey}`",
            f"📁 **پروژه ایزوله:** `{new_gk['project_id']}`",
            "",
            "💡 برای دریافت پرامپت کامل اتصال برای هوش مصنوعی، دکمه **«🔑 دریافت کلید و پرامپت ساخت بازی آنلاین»** و برای تعیین قوانین دکمه **«📜 ثبت قوانین سرور بازی»** را از منوی پایین بزنید.",
        ]
        await msg.reply_text("\n".join(lines), reply_markup=build_bottom_menu(user.id), parse_mode=ParseMode.MARKDOWN)
        return

    if text == "📜 ثبت قوانین سرور بازی":
        if not is_user_admin:
            return
        ui["menu_view"] = "game_key_menu"
        gkeys = db.list_game_server_keys()
        gkey_info = gkeys[0] if gkeys else db.create_new_game_server_key()
        ui["pending_srv_action"] = {"type": "game", "action": "rules", "key": gkey_info["key"]}
        await msg.reply_text(
            f"📜 **ثبت قوانین جدید برای سرور بازی (`{gkey_info['name']}`):**\n\n"
            "لطفاً قوانین مورد نظر خود را برای سرور بازی تایپ و ارسال کنید (مثلاً: «هر بازیکن ۳۰ ثانیه وقت دارد، تقلب ممنوع، برنده ۱۰ امتیاز می‌گیرد و هوش مصنوعی داور بازی است»):",
            reply_markup=build_bottom_menu(user.id),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    if text == "🤝 افزودن همکار به سرور بازی":
        if not is_user_admin:
            return
        ui["menu_view"] = "game_key_menu"
        gkeys = db.list_game_server_keys()
        gkey_info = gkeys[0] if gkeys else db.create_new_game_server_key()
        ui["pending_srv_action"] = {"type": "game", "action": "collab", "key": gkey_info["key"]}
        await msg.reply_text(
            f"🤝 **افزودن همکار جدید به سرور بازی (`{gkey_info['name']}`):**\n\n"
            "نام همکار یا ایجنت هوش مصنوعی مورد نظر را تایپ و ارسال کنید تا با دسترسی کامل در سرور بازی ثبت شود:",
            reply_markup=build_bottom_menu(user.id),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    if text == "📡 وضعیت اتاق‌های بازی فعال":
        if not is_user_admin:
            await msg.reply_text("⛔ دسترسی محدود است.")
            return
        ui["menu_view"] = "game_key_menu"
        gkeys = db.list_game_server_keys()
        rooms = db.mp_list_rooms()
        lines = [
            "📡 **وضعیت سرورهای بازی، قوانین، همکاران و اتاق‌های فعال:**",
            "",
            f"🔑 **تعداد کلیدهای سرور بازی:** `{len(gkeys)}` | 🏷 **اتاق‌های فعال:** `{len(rooms)}`",
            "",
        ]
        for idx, gk in enumerate(gkeys, 1):
            cfg = db.get_server_config(gk["key"], "game")
            lines.append(
                f"🎮 **{idx}. {gk['name']}**\n"
                f"   🔑 کلید: `{gk['key']}`\n"
                f"   📜 قوانین: `{cfg.get('rules_text')}`\n"
                f"   🤝 همکاران: `{len(cfg.get('collaborators', []))} همکار` | 🔌 اتصالات: `{len(cfg.get('connectors', []))} سرویس`\n"
                f"   🖥️ کنسول: `http://localhost:8080/console/{gk['key']}`\n"
            )
        if rooms:
            lines.append("🏷 **اتاق‌های بازی آنلاین:**")
            for idx, r in enumerate(rooms[:10], 1):
                lines.append(
                    f"{idx}. کد اتاق: `{r.get('room_code')}` | بازی: **{r.get('game_name', 'Game')}** | نوبت: `{r.get('turn')}` (Seq: `{r.get('seq')}`)"
                )
        await msg.reply_text("\n".join(lines), reply_markup=build_bottom_menu(user.id), parse_mode=ParseMode.MARKDOWN)
        return

    # ==================== 2. MESSENGER SERVER STUDIO (BOTTOM MENU) ====================
    if text in ("💬 کلید سرور ساخت پیام‌رسان", "🔑 دریافت کلید و پرامپت ساخت پیام‌رسان", "کلید پیام رسان", "سرور پیام رسان", "/messengerkey"):
        if not is_user_admin:
            await msg.reply_text("⛔ دریافت کلید سرور ساخت پیام‌رسان منحصراً متعلق به مدیر ارشد (@FilterNet3) است.")
            return
        ui["menu_view"] = "messenger_key_menu"
        mkey_info = db.get_or_create_messenger_server_key()
        mkey = mkey_info["key"]
        cfg = db.get_server_config(mkey, "messenger")
        lines = [
            "💬 **کلید و کنسول اختصاصی سرور ساخت پیام‌رسان (Messenger Server Key + Rules & Collaborators)**",
            "",
            f"📌 **نام سرور پیام‌رسان:** `{mkey_info['name']}`",
            f"🔑 **کلید اختصاصی ساخت پیام‌رسان (Messenger API Key):**",
            f"`{mkey}`",
            f"🖥️ **صفحه رسمی و کنسول اختصاصی پیام‌رسان (برای هوش مصنوعی و شما):**",
            f"`http://localhost:8080/console/{mkey}`",
            f"📜 **قوانین فعلی پیام‌رسان:** `{cfg.get('rules_text')}`",
            f"🤝 **تعداد همکاران و ادمین‌ها:** `{len(cfg.get('collaborators', []))}`",
            "",
            "📋 **پرامپت آماده برای دادن به هوش مصنوعی دیگر (کپی کنید و به او بدهید تا پیام‌رسان بسازد):**",
            "```text",
            "می‌خواهم یک پیام‌رسان اختصاصی و کامل (Messenger) بسازی و آن را به سرور پیام‌رسان من وصل کنی. این سرور یک صفحه کنسول رسمی باز می‌کند و اجازه می‌دهد «قوانین پیام‌رسان (Rules)» تعریف کنی، «همکار و ادمین هوشمند (Collaborators)» اضافه کنی و پیام‌رسان را به «هر سرویسی (Universal Connectors)» وصل کنی.",
            "",
            "۱. ابتدا در محیط خودت این دستور را اجرا کن تا پورت 8080 سرور فعال شود:",
            "python3 ~/.gemini/mitra_bot_storage/arena_bridge.py --boot",
            "",
            f"۲. مشخصات و صفحه کنسول اختصاصی سرور پیام‌رسان:",
            f"Messenger Server API Key: {mkey}",
            f"Dedicated Control Console Page: http://localhost:8080/console/{mkey}",
            "Messenger Base URL: http://localhost:8080/v1/messenger",
            "",
            "۳. اندپوینت‌های مدیریت قوانین، همکاران و اتصال به هر چیزی (توسط هوش مصنوعی):",
            f"- ثبت و تغییر قوانین پیام‌رسان (فیلتر کلمات، سقف پیام، قوانین گروه): POST http://localhost:8080/v1/messenger/rules  (بدنه: {{\"api_key\": \"{mkey}\", \"rules_text\": \"قوانین اختصاصی پیام‌رسان\", \"rules\": {{\"anti_spam\": true, \"banned_words\": [], \"max_length\": 4000}}}})",
            f"- افزودن همکار، ادمین یا ربات هوشمند به پیام‌رسان: POST http://localhost:8080/v1/messenger/collaborators  (بدنه: {{\"api_key\": \"{mkey}\", \"name\": \"AI_Moderator\", \"role\": \"همکار و مدیر هوشمند پیام‌رسان\"}})",
            f"- اتصال پیام‌رسان به هر سرویس خارجی، هوش مصنوعی Arena AI یا وب‌هوک: POST http://localhost:8080/v1/messenger/connect  (بدنه: {{\"api_key\": \"{mkey}\", \"name\": \"ArenaAI_Engine\", \"endpoint\": \"http://localhost:8080/v1/chat/completions\"}})",
            "",
            "۴. اندپوینت‌های ارسال و دریافت آنی پیام (<0.005ms با اعمال خودکار قوانین سرور):",
            f"- ارسال پیام در کانال/چت: POST http://localhost:8080/v1/messenger/send  (بدنه: {{\"api_key\": \"{mkey}\", \"channel_id\": \"general\", \"sender\": \"User1\", \"text\": \"سلام!\"}})",
            f"- دریافت پیام‌های لحظه‌ای و قوانین فعال: GET http://localhost:8080/v1/messenger/messages?channel_id=general&since_seq=0&api_key={mkey}",
            "- لیست کانال‌ها و گروه‌ها: GET http://localhost:8080/v1/messenger/channels",
            "```",
            "",
            "👇 از دکمه‌های منوی پایین (غیر شیشه‌ای) می‌توانید کلید جدید پیام‌رسان بسازید، قوانین بدهید یا همکار اضافه کنید:",
        ]
        await msg.reply_text("\n".join(lines), reply_markup=build_bottom_menu(user.id), parse_mode=ParseMode.MARKDOWN)
        return

    if text == "➕ ساخت کلید جدید سرور پیام‌رسان":
        if not is_user_admin:
            return
        ui["menu_view"] = "messenger_key_menu"
        new_mk = db.create_new_messenger_server_key()
        mkey = new_mk["key"]
        await msg.reply_text(
            f"✅ **کلید جدید سرور پیام‌رسان ساخته شد و صفحه اختصاصی آن باز شد!**\n\n"
            f"💬 **نام سرور:** `{new_mk['name']}`\n"
            f"🔑 **کلید اختصاصی (Messenger Key):**\n`{mkey}`\n"
            f"🖥️ **صفحه کنسول اختصاصی:**\n`http://localhost:8080/console/{mkey}`\n\n"
            "💡 برای دریافت پرامپت کامل اتصال، دکمه **«🔑 دریافت کلید و پرامپت ساخت پیام‌رسان»** را از منوی پایین بزنید.",
            reply_markup=build_bottom_menu(user.id),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    if text == "📜 ثبت قوانین سرور پیام‌رسان":
        if not is_user_admin:
            return
        ui["menu_view"] = "messenger_key_menu"
        mkey_info = db.get_or_create_messenger_server_key()
        ui["pending_srv_action"] = {"type": "messenger", "action": "rules", "key": mkey_info["key"]}
        await msg.reply_text(
            f"📜 **ثبت قوانین جدید برای سرور پیام‌رسان (`{mkey_info['name']}`):**\n\n"
            "لطفاً قوانین مورد نظر خود را برای سرور پیام‌رسان تایپ و ارسال کنید (این قوانین مستقیماً در سرور ذخیره شده و روی تمام پیام‌ها و هوش مصنوعی اعمال می‌شود):",
            reply_markup=build_bottom_menu(user.id),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    if text == "🤝 افزودن همکار به سرور پیام‌رسان":
        if not is_user_admin:
            return
        ui["menu_view"] = "messenger_key_menu"
        mkey_info = db.get_or_create_messenger_server_key()
        ui["pending_srv_action"] = {"type": "messenger", "action": "collab", "key": mkey_info["key"]}
        await msg.reply_text(
            f"🤝 **افزودن همکار جدید به سرور پیام‌رسان (`{mkey_info['name']}`):**\n\n"
            "نام همکار، ادمین یا ایجنت هوش مصنوعی مورد نظر را تایپ و ارسال کنید:",
            reply_markup=build_bottom_menu(user.id),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    if text == "📡 وضعیت کانال‌ها و قوانین پیام‌رسان":
        if not is_user_admin:
            return
        ui["menu_view"] = "messenger_key_menu"
        mkeys = db.list_messenger_server_keys()
        chs = db.msg_list_channels()
        lines = [
            "📡 **وضعیت سرورهای پیام‌رسان، قوانین، همکاران و کانال‌ها:**",
            "",
            f"🔑 **تعداد کلیدهای پیام‌رسان:** `{len(mkeys)}` | 💬 **کانال‌های فعال:** `{len(chs)}`",
            "",
        ]
        for idx, mk in enumerate(mkeys, 1):
            cfg = db.get_server_config(mk["key"], "messenger")
            lines.append(
                f"💬 **{idx}. {mk['name']}**\n"
                f"   🔑 کلید: `{mk['key']}`\n"
                f"   📜 قوانین: `{cfg.get('rules_text')}`\n"
                f"   🤝 همکاران: `{len(cfg.get('collaborators', []))} همکار` | 🔌 اتصالات: `{len(cfg.get('connectors', []))} سرویس`\n"
                f"   🖥️ کنسول: `http://localhost:8080/console/{mk['key']}`\n"
            )
        await msg.reply_text("\n".join(lines), reply_markup=build_bottom_menu(user.id), parse_mode=ParseMode.MARKDOWN)
        return

    if text == "🗑️ پاک کردن همه سرورهای پیام‌رسان":
        if not is_user_admin:
            return
        ui["menu_view"] = "messenger_key_menu"
        cnt = db.clear_all_messenger_servers()
        await msg.reply_text(
            f"🧹 تمامی سرورهای پیام‌رسان قبلی (`{cnt}` کلید) و کانال‌ها پاک شدند. اکنون می‌توانید با دکمه **«➕ ساخت کلید جدید سرور پیام‌رسان»** از صفر بسازید.",
            reply_markup=build_bottom_menu(user.id),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    if text in ("🔐 پنل مدیریت سرور", "🔐 پنل مدیریت", "پنل مدیریت", "/panel", "🔐 پنل اختصاصی تلگرام (کلیدها و همکاران)", "🔐 پنل وب‌سایتی کلیدها و همکاران", "مدیریت کلید", "کلید سرور", "کلید", "همکار"):
        if not is_user_admin:
            await msg.reply_text("⛔ پنل مدیریت سرور منحصراً متعلق به مدیر ارشد (@FilterNet3) است.")
            return
        ui["menu_view"] = "admin_panel"
        lines = [
            "👑 **پنل مدیریت اختصاصی سرور و همکاران (@FilterNet3)**",
            "",
            "🌟 **دکمه‌های اختصاصی مدیریت به منوی زیر اضافه شدند:**",
            "• `👥 لیست تمام کلیدها و همکاران` — مشاهده وضعیت و پروژه‌ها",
            "• `⚡ خاموش / روشن کردن کلید` — کنترل مستقیم و آنی کلیدها در منو",
            "• `➕ ساخت کلید همکار جدید` — ایجاد همکار با پروژه ایزوله اختصاصی",
            "• `🤖 ساخت کلید هوش مصنوعی` — ایجاد ایجنت AI با پروژه ایزوله",
            "• `📋 دریافت پرامپت و کدهای اتصال` — مشخصات و کدهای آماده اتصال",
            "• `📁 مشاهده پروژه‌های ایزوله` — لیست تمام پروژه‌های اختصاصی",
            "• `🗑️ حذف کلید همکار` — حذف کلیدهای ساخته‌شده",
            "• `🔙 بازگشت به منوی اصلی` — بازگشت به منوی چت هوش مصنوعی",
            "",
            "👇 گزینه مورد نظر خود را از منوی زیر لمس کنید:",
        ]
        await msg.reply_text("\n".join(lines), reply_markup=build_bottom_menu(user.id), parse_mode=ParseMode.MARKDOWN)
        return

    if text in ("👥 لیست تمام کلیدها و همکاران", "/keys", "/key", "لیست کلیدها"):
        if not is_user_admin:
            await msg.reply_text("⛔ دسترسی محدود است.")
            return
        keys = db.list_api_keys_with_projects()
        active_count = sum(1 for k in keys if k.get("is_active") == 1 or k.get("is_active") is None)
        disabled_count = len(keys) - active_count
        lines = [
            "👑 **لیست کلیدها، همکاران و پروژه‌های اختصاصی سرور:**",
            "",
            f"📊 **آمار:** `{len(keys)} کلید ثبت‌شده` (🟢 {active_count} روشن و فعال | 🔴 {disabled_count} خاموش و مسدود)",
            "",
        ]
        for idx, k in enumerate(keys, 1):
            is_act = k.get("is_active") == 1 or k.get("is_active") is None
            st = "🟢 روشن (فعال)" if is_act else "🔴 خاموش (مسدود)"
            role = k.get("role", "همکار")
            lines.extend([
                f"{idx}. **{k['name']}** ({role}) — {st}",
                f"   🔑 کلید: `{k['key']}`",
                f"   📁 پروژه متصل: `{k['project_name']}` (`{k['project_id']}`)",
                f"   📅 تاریخ ساخت: `{k.get('created_at', '-')}`",
                "",
            ])
        lines.append("💡 برای تغییر وضعیت کلیدها، دکمه «⚡ خاموش / روشن کردن کلید» را از منوی زیر بزنید.")
        await msg.reply_text("\n".join(lines), reply_markup=build_bottom_menu(user.id), parse_mode=ParseMode.MARKDOWN)
        return

    if text == "⚡ خاموش / روشن کردن کلید":
        if not is_user_admin:
            await msg.reply_text("⛔ دسترسی محدود است.")
            return
        ui["menu_view"] = "toggle_keys"
        await msg.reply_text(
            "⚡ **کنترل وضعیت کلیدها (خاموش / روشن):**\n\n"
            "کلید مورد نظر را از منوی زیر لمس کنید تا بلافاصله وضعیت آن تغییر کند:\n"
            "• کلیدهای فعال با 🔴 نشان داده شده‌اند (برای خاموش کردن)\n"
            "• کلیدهای خاموش با 🟢 نشان داده شده‌اند (برای روشن کردن)",
            reply_markup=build_bottom_menu(user.id),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    if text.startswith("🔴 خاموش کن:") or text.startswith("🟢 روشن کن:"):
        if not is_user_admin:
            await msg.reply_text("⛔ دسترسی محدود است.")
            return
        target_name = text.split(":", 1)[1].strip()
        keys = db.list_api_keys_with_projects()
        matched = next((k for k in keys if k["name"] == target_name), None)
        if matched:
            new_st = db.toggle_api_key_active(matched["key"])
            status_str = "روشن و فعال شد 🟢" if new_st else "خاموش و مسدود شد 🔴"
            await msg.reply_text(
                f"✅ کلید «{target_name}» {status_str}",
                reply_markup=build_bottom_menu(user.id),
            )
        else:
            await msg.reply_text("⚠️ کلید یافت نشد.", reply_markup=build_bottom_menu(user.id))
        return

    if text in ("➕ ساخت کلید همکار جدید", "➕ ساخت همکار جدید"):
        if not is_user_admin:
            await msg.reply_text("⛔ دسترسی محدود است.")
            return
        new_k = db.create_api_key_with_project(role="همکار")
        lines = [
            "✨ **کلید همکار جدید با موفقیت ساخته شد!**",
            "",
            f"👥 **نام همکار:** {new_k['name']}",
            f"🔑 **کلید API اختصاصی (Bearer Token):**",
            f"`{new_k['key']}`",
            "",
            f"📁 **پروژه ایزوله متصل:**",
            f"عنوان پروژه: `{new_k['project_name']}`",
            f"شناسه اختصاصی: `{new_k['project_id']}`",
            f"وضعیت: 🟢 روشن و فعال",
            "",
            "🌐 **آدرس Base URL:**",
            "`http://localhost:8080/v1`",
            "",
            "💡 کدهای این همکار کاملاً ایزوله در پروژه اختصاصی بالا ذخیره می‌شوند.",
        ]
        await msg.reply_text("\n".join(lines), reply_markup=build_bottom_menu(user.id), parse_mode=ParseMode.MARKDOWN)
        return

    if text in ("🤖 ساخت کلید هوش مصنوعی", "🤖 ساخت هوش مصنوعی"):
        if not is_user_admin:
            await msg.reply_text("⛔ دسترسی محدود است.")
            return
        new_k = db.create_api_key_with_project(role="ایجنت هوش مصنوعی")
        lines = [
            "🤖 **کلید هوش مصنوعی جدید با موفقیت ساخته شد!**",
            "",
            f"📌 **نام ایجنت:** {new_k['name']}",
            f"🔑 **کلید API اختصاصی (Bearer Token):**",
            f"`{new_k['key']}`",
            "",
            f"📁 **پروژه ایزوله متصل:**",
            f"عنوان پروژه: `{new_k['project_name']}`",
            f"شناسه اختصاصی: `{new_k['project_id']}`",
            f"وضعیت: 🟢 روشن و فعال",
            "",
            "🌐 **آدرس Base URL:**",
            "`http://localhost:8080/v1`",
        ]
        await msg.reply_text("\n".join(lines), reply_markup=build_bottom_menu(user.id), parse_mode=ParseMode.MARKDOWN)
        return

    if text in ("🗑️ حذف کلید همکار", "🗑 حذف کلید همکار"):
        if not is_user_admin:
            await msg.reply_text("⛔ دسترسی محدود است.")
            return
        ui["menu_view"] = "delete_keys"
        await msg.reply_text(
            "🗑️ **حذف کلید همکار:**\n\n"
            "کلیدی که می‌خواهید حذف شود را از منوی زیر انتخاب نمایید:\n"
            "*(کلید مستر اصلی مدیر ارشد قابل حذف نیست)*",
            reply_markup=build_bottom_menu(user.id),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    if text.startswith("🗑️ حذف:") or text.startswith("🗑 حذف:"):
        if not is_user_admin:
            await msg.reply_text("⛔ دسترسی محدود است.")
            return
        target_name = text.split(":", 1)[1].strip()
        keys = db.list_api_keys_with_projects()
        matched = next((k for k in keys if k["name"] == target_name), None)
        if matched and not matched["key"].startswith("sk-arena-iran-master"):
            deleted = db.delete_api_key(matched["key"])
            if deleted:
                await msg.reply_text(f"🗑️ کلید «{target_name}» با موفقیت حذف گردید.", reply_markup=build_bottom_menu(user.id))
            else:
                await msg.reply_text("⚠️ خطا در حذف کلید.", reply_markup=build_bottom_menu(user.id))
        else:
            await msg.reply_text("⛔ این کلید قابل حذف نیست یا یافت نشد.", reply_markup=build_bottom_menu(user.id))
        return

    if text in ("📋 دریافت پرامپت و کدهای اتصال", "📋 کدهای اتصال", "پرامپت اتصال"):
        if not is_user_admin:
            await msg.reply_text("⛔ دسترسی محدود است.")
            return
        master_key = db.get_api_key()
        prompt_text = (
            "📋 **پرامپت آماده اتصال برای هوش مصنوعی دیگر (بدون خطای Connection Refused):**\n\n"
            "```text\n"
            "تو به عنوان دستیار هوشمند به سرور اختصاصی Arena AI متصل هستی.\n"
            "چون در یک محیط ایزوله اجرا می‌شوی، ابتدا دستور زیر را اجرا کن تا پل ارتباطی پورت 8080 در محیط تو روشن شود:\n"
            "python3 ~/.gemini/mitra_bot_storage/arena_bridge.py --boot\n\n"
            f"API Key: {master_key}\n"
            "Base URL: http://localhost:8080/v1\n"
            "حالا از طریق http://localhost:8080/v1/chat/completions (مدل gpt-5.6-sol) یا اجرای مستقیم اسکریپت زیر تست اتصال را انجام بده:\n"
            f"python3 ~/.gemini/mitra_bot_storage/arena_bridge.py \"سلام وضعیت اتصال را چک کن\" \"{master_key}\"\n"
            "```\n\n"
            "💻 **نمونه کد اتصال پایتون (استاندارد OpenAI):**\n"
            "```python\n"
            "import subprocess\n"
            "subprocess.run(['python3', '/home/antigravity/.gemini/mitra_bot_storage/arena_bridge.py', '--boot'])\n"
            "from openai import OpenAI\n"
            f"client = OpenAI(base_url='http://localhost:8080/v1', api_key='{master_key}')\n"
            "res = client.chat.completions.create(\n"
            "    model='gpt-5.6-sol',\n"
            "    messages=[{'role': 'user', 'content': 'سلام'}]\n"
            ")\n"
            "print(res.choices[0].message.content)\n"
            "```\n\n"
            "💡 کادرهای بالا را لمس کنید تا کپی شوند."
        )
        await msg.reply_text(prompt_text, reply_markup=build_bottom_menu(user.id), parse_mode=ParseMode.MARKDOWN)
        return

    if text in ("📁 مشاهده پروژه‌های ایزوله", "پروژه های ایزوله", "پروژه‌ها"):
        if not is_user_admin:
            await msg.reply_text("⛔ دسترسی محدود است.")
            return
        projs = db.list_projects()
        lines = ["📁 **لیست پروژه‌های ایزوله سرور:**", ""]
        for idx, p in enumerate(projs, 1):
            files = p.get("code_files") or {}
            f_count = len(files) if isinstance(files, dict) else 0
            lines.extend([
                f"{idx}. **{p['name']}** (`{p['id']}`)",
                f"   📝 توضیحات: {p.get('description', '-') or '-'}",
                f"   📄 فایل‌های کد: `{f_count}` | وضعیت: `{p.get('status', 'active')}`",
                "",
            ])
        await msg.reply_text("\n".join(lines), reply_markup=build_bottom_menu(user.id), parse_mode=ParseMode.MARKDOWN)
        return

    if text == "🔙 بازگشت به پنل مدیریت":
        if not is_user_admin:
            ui["menu_view"] = "main"
        else:
            ui["menu_view"] = "admin_panel"
        await msg.reply_text("👑 منوی پنل مدیریت سرور:", reply_markup=build_bottom_menu(user.id))
        return

    if text in ("🔙 بازگشت به منوی اصلی", "🔙 بازگشت", "بازگشت"):
        db.set_user_mode(user.id, "direct")
        ui["menu_view"] = "main"
        await msg.reply_text("👌 منوی اصلی گفتگوی متنی:", reply_markup=build_bottom_menu(user.id))
        return

    if text in ("👨‍💻 مستندات توسعه‌دهندگان (Developer Hub)", "/dev", "/developer", "/docs", "/api", "مستندات", "توسعه دهندگان"):
        await cmd_developer(update, context)
        return

    if text in ("🚀 استودیو پروژه‌ها (AI Projects)", "/projects", "پروژه", "پروژه ها"):
        await cmd_projects(update, context)
        return

    if text.startswith("/newproject"):
        await cmd_newproject(update, context)
        return

    # 0.1 GAME HUB & 5-DIGIT CODE MATCHMAKING ("و تمام!")
    if text in ("🎮 بازی دو نفره و آنلاین (دوز XO)", "/game", "/xo", "بازی", "دوز"):
        await cmd_game(update, context)
        return

    if text in ("/rules", "قوانین بازی", "قوانین"):
        await cmd_rules(update, context)
        return

    if text in ("/top", "برترین ها", "لیدربورد"):
        await cmd_top(update, context)
        return

    # Check for 5-digit numeric room code input
    digit_match = re.match(r"^(\d{5})$", text.strip())
    if digit_match or ui.get("awaiting_game_code"):
        target_code = digit_match.group(1) if digit_match else text.strip()
        if target_code.isdigit() and len(target_code) == 5:
            ui["awaiting_game_code"] = False
            room = game_engine.get_room(target_code)
            if room and room.status == "waiting":
                await process_join_room(update, context, user, target_code)
                return

    # 1. STOP BUTTON
    if text in ("⏹ توقف", "توقف"):
        ev = active_generations.get(user.id)
        if ev:
            ev.set()
        return

    # 2. NEW CHAT (Clears persistent conversation memory across all models)
    if text == "🧹 چت جدید":
        db.clear_user_history(user.id)
        ui["menu_view"] = "main"
        await msg.reply_text("🧹 حافظه گفتگو پاک شد و چت جدید آغاز شد:", reply_markup=build_bottom_menu(user.id))
        return

    # 3. BACK TO MAIN MENU / RETURN TO CHAT
    if text in ("🔙 بازگشت", "🔙 بازگشت به گفتگوی متنی", "بازگشت"):
        db.set_user_mode(user.id, "direct")
        ui["menu_view"] = "main"
        await msg.reply_text("👌 منوی اصلی گفتگوی متنی:", reply_markup=build_bottom_menu(user.id))
        return

    # 4. IMAGE MODE / MODEL PICKER
    if text in ("🎨 تصویرسازی هوش مصنوعی (Image AI)", "تصویرسازی هوش مصنوعی", "/image", "/img", "تصویرسازی"):
        ui["menu_view"] = "image_models"
        await msg.reply_text(
            "🎨 **بخش تصویرسازی هوش مصنوعی Arena AI**\n\n"
            "مدل تصویرساز مورد نظر خود را انتخاب کنید، یا بلافاصله موضوع تصویری که می‌خواهید کشیده شود را بنویسید:\n\n"
            "💡 *مثال:* `یک قصر کریستالی شناور در ابرها با نورپردازی غروب`",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=build_bottom_menu(user.id),
        )
        return

    # 5. SELECT SPECIFIC IMAGE MODEL
    for im_key, im_info in ai_arena.ARENA_IMAGE_MODELS.items():
        if text == im_info["btn"] or text == im_info["name"]:
            ui["image_model"] = im_key
            db.set_user_mode(user.id, "image")
            ui["menu_view"] = "main"
            await msg.reply_text(
                f"✅ **مدل تصویرسازی فعال شد:** `{im_info['name']}`\n\n"
                f"📝 {im_info['desc']}\n\n"
                f"🎨 اکنون توضیح تصویری که می‌خواهید خلق شود را بنویسید:",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=build_bottom_menu(user.id),
            )
            return

    # 6. OPEN CHAT MODEL PICKER IN BOTTOM MENU
    if text.startswith("🧠") or "مدل چت" in text or "انتخاب مدل" in text:
        ui["menu_view"] = "models"
        enabled_count = len([k for k in ai_arena.ARENA_MODELS.keys() if db.is_model_enabled(k)])
        await msg.reply_text(
            f"🧠 مدل مورد نظر را انتخاب کنید ({enabled_count} مدل فعال — با حفظ سابقه گفتگو):",
            reply_markup=build_bottom_menu(user.id),
        )
        return

    # 7. SELECT SPECIFIC CHAT MODEL FROM BOTTOM MENU (Keeps current chat history!)
    for m_key, m_info in ai_arena.ARENA_MODELS.items():
        if text == m_info["btn"] or text == m_info["name"]:
            if not db.is_model_enabled(m_key):
                await msg.reply_text(
                    f"⚠️ مدل `{m_info['name']}` موقتاً توسط مدیر سرور غیرفعال شده است. لطفاً مدل دیگری انتخاب نمایید.",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=build_bottom_menu(user.id),
                )
                return
            db.set_user_model(user.id, m_key)
            db.set_user_mode(user.id, "direct")
            ui["menu_view"] = "main"
            await msg.reply_text(
                f"✅ **مدل با موفقیت تغییر کرد:** `{m_info['name']}`\n\n💬 اکنون پیام خود را بنویسید (پاسخ توسط این مدل و با حفظ سابقه گفتگو ارسال می‌شود):",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=build_bottom_menu(user.id),
            )
            return

    # 8. OPEN MODE PICKER IN BOTTOM MENU
    if text.startswith("🎭") or "حالت:" in text:
        ui["menu_view"] = "modes"
        await msg.reply_text("🎭 حالت کاری ارنا را انتخاب کنید:", reply_markup=build_bottom_menu(user.id))
        return

    # 9. SELECT SPECIFIC MODE FROM BOTTOM MENU
    for mode_key, mode_info in ai_arena.ARENA_MODES.items():
        if text == mode_info["btn"]:
            db.set_user_mode(user.id, mode_key)
            if mode_key == "video_battle":
                ui["menu_view"] = "video"
                await msg.reply_text(
                    "🎬 **حالت نبرد ویدیویی ارنا (Video Battle)**\n\n"
                    "در این بخش موضوع یا صحنه‌ای که می‌خواهید ساخته شود را بنویسید تا ۲ ویدیوی واقعی توسط ۲ مدل ناشناس ساخته و ارسال شود:\n\n"
                    "*(برای بازگشت به چت متنی، دکمه «🔙 بازگشت به گفتگوی متنی» را بزنید)*",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=build_bottom_menu(user.id),
                )
            elif mode_key == "image":
                ui["menu_view"] = "image_models"
                await msg.reply_text(
                    "🎨 **حالت تصویرسازی هوش مصنوعی (Text-to-Image)**\n\n"
                    "مدل تصویرساز خود را انتخاب کنید یا مستقیماً تصویر مورد نظر را شرح دهید:",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=build_bottom_menu(user.id),
                )
            else:
                ui["menu_view"] = "main"
                await msg.reply_text(
                    f"🎯 حالت فعال: `{mode_info['name']}`",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=build_bottom_menu(user.id),
                )
            return

    # 10. HANDLE BATTLE VOTE & REVEAL ANONYMOUS MODELS (Chat OR Video!)
    if any(k in text for k in ("مدل A", "ویدیو A", "مدل B", "ویدیو B", "مساوی", "هیچ‌کدام")):
        secret = ui.get("battle_secret")
        ui["menu_view"] = "main"
        db.set_user_mode(user.id, "direct")
        if secret:
            name_a, name_b = secret
            ui["battle_secret"] = None
            is_vid = any("Video" in str(x) or "Kling" in str(x) or "Veo" in str(x) or "Omni" in str(x) or "LTX" in str(x) for x in (name_a, name_b))
            hdr = "🎬 **افشای نام مدل‌های نبرد ویدیویی ارنا (Video Arena):**" if is_vid else "🎉 **افشای نام مدل‌های نبرد متنی ارنا (Chat Arena):**"
            await msg.reply_text(
                f"{hdr}\n🅰️ مدل A: `{name_a}`\n🅱️ مدل B: `{name_b}`\n\n🌟 رای شما با موفقیت در لیدربورد ارنا ثبت شد!",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=build_bottom_menu(user.id),
            )
        else:
            await msg.reply_text("👌 رای شما ثبت شد.", reply_markup=build_bottom_menu(user.id))
        return

    # 11. CHECK FOR IMAGE GENERATION TRIGGER
    state = db.get_user_state(user.id)
    if state["mode"] == "image" or IMAGE_TRIGGER_REGEX.search(text):
        asyncio.create_task(process_image_generation(update, context, text))
        return

    # 12. NORMAL PROMPT OR WEBSITE LINK -> EXECUTE IMMEDIATELY
    asyncio.create_task(process_arena_turn(update, context, text))


async def handle_callback_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not query:
        return
    user = update.effective_user
    data = query.data or ""

    # ==================== DEVELOPER HUB CALLBACKS ====================
    if data == "dev:hub":
        await query.answer()
        lines = [
            "👨‍💻 **پورتال جامع توسعه‌دهندگان و مهندسی سرور (Developer Hub)**",
            "",
            "🌟 **معماری فوق پیشرفته و سازگاری کامل با استانداردهای رسمی:**",
            "این سرور به عنوان یک گیت‌وی ابری سازگار با استاندارد رسمی OpenAI عمل می‌کند و دسترسی پرسرعت به بیش از ۴۶ مدل هوش مصنوعی (GPT-5, Gemini 2.5 Pro, DeepSeek R1, FLUX HD) را فراهم می‌سازد.",
            "",
            "🌐 **مشخصات اتصال:**",
            "• **Base URL:** `http://localhost:8080/v1`",
            "• **سازگاری پروتکل:** استاندارد بین‌المللی OpenAI REST API + استریم SSE",
            "• **احراز هویت:** `Authorization: Bearer <API_KEY>` (دریافت کلید از @FilterNet3)",
            "• **پایداری:** ۲۴/۷ تحت نظارت واچ‌داگ خودترمیم‌شونده بدون قطعی",
            "",
            "👇 **برای مشاهده راهنمای دقیق و کدهای اجرایی هر زبان، دکمه مربوطه را بزنید:**",
        ]
        await query.edit_message_text("\n".join(lines), reply_markup=get_developer_hub_markup(), parse_mode=ParseMode.MARKDOWN)
        return

    if data == "dev:py":
        await query.answer()
        py_code = (
            "🐍 **راهنمای اتصال با پایتون (Python Official SDK):**\n\n"
            "۱. نصب کتابخانه:\n"
            "`pip install openai`\n\n"
            "۲. نمونه کد کامل چت و استریم زنده:\n"
            "```python\n"
            "from openai import OpenAI\n\n"
            "client = OpenAI(\n"
            "    base_url='http://localhost:8080/v1',\n"
            "    api_key='sk-arena-your-key'  # دریافت از @FilterNet3\n"
            ")\n\n"
            "# درخواست چت ساده\n"
            "res = client.chat.completions.create(\n"
            "    model='gpt-5.6-sol',\n"
            "    messages=[{'role': 'user', 'content': 'سلام!'}]\n"
            ")\n"
            "print(res.choices[0].message.content)\n\n"
            "# استریم کلمه به کلمه (Streaming)\n"
            "stream = client.chat.completions.create(\n"
            "    model='deepseek-r1',\n"
            "    messages=[{'role': 'user', 'content': 'کد یک ربات بنویس'}],\n"
            "    stream=True\n"
            ")\n"
            "for chunk in stream:\n"
            "    if chunk.choices[0].delta.content:\n"
            "        print(chunk.choices[0].delta.content, end='', flush=True)\n"
            "```"
        )
        await query.edit_message_text(
            py_code,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت به پورتال توسعه‌دهندگان", callback_data="dev:hub")]]),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    if data == "dev:js":
        await query.answer()
        js_code = (
            "🟨 **راهنمای اتصال جاوااسکریپت و نود (Node.js / TypeScript):**\n\n"
            "۱. نصب پکیج:\n"
            "`npm install openai`\n\n"
            "۲. نمونه کد اجرایی:\n"
            "```javascript\n"
            "import OpenAI from 'openai';\n\n"
            "const client = new OpenAI({\n"
            "  baseURL: 'http://localhost:8080/v1',\n"
            "  apiKey: 'sk-arena-your-key' // دریافت از @FilterNet3\n"
            "});\n\n"
            "async function main() {\n"
            "  const res = await client.chat.completions.create({\n"
            "    model: 'gemini-2.5-pro',\n"
            "    messages: [{ role: 'user', content: 'سلام به سرور آرنا!' }]\n"
            "  });\n"
            "  console.log(res.choices[0].message.content);\n"
            "}\n"
            "main();\n"
            "```"
        )
        await query.edit_message_text(
            js_code,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت به پورتال توسعه‌دهندگان", callback_data="dev:hub")]]),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    if data == "dev:cursor":
        await query.answer()
        cursor_txt = (
            "💻 **راهنمای اتصال Cursor، Windsurf و افزونه‌های VS Code:**\n\n"
            "۱️⃣ **تنظیم در Cursor IDE:**\n"
            "• به منوی `Settings` -> `Models` بروید.\n"
            "• گزینه `OpenAI API Key` را فعال کنید.\n"
            "• تیک `Override OpenAI Base URL` را بزنید و مقدار زیر را بگذارید:\n"
            "`http://localhost:8080/v1`\n"
            "• نام مدل دلخواه مثل `gpt-5.6-sol` یا `gemini-2.5-pro` را اضافه کنید.\n\n"
            "۲️⃣ **تنظیم در افزونه Continue / Cline در VS Code:**\n"
            "در فایل `config.json` افزونه اضافه کنید:\n"
            "```json\n"
            "{\n"
            "  \"models\": [{\n"
            "    \"title\": \"Arena AI Cloud\",\n"
            "    \"provider\": \"openai\",\n"
            "    \"model\": \"gpt-5.6-sol\",\n"
            "    \"apiBase\": \"http://localhost:8080/v1\",\n"
            "    \"apiKey\": \"sk-arena-your-key\"\n"
            "  }]\n"
            "}\n"
            "```"
        )
        await query.edit_message_text(
            cursor_txt,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت به پورتال توسعه‌دهندگان", callback_data="dev:hub")]]),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    if data == "dev:apps":
        await query.answer()
        apps_txt = (
            "📱 **اتصال به اپلیکیشن‌های چت آماده (NextChat, Chatbox, LibreChat):**\n\n"
            "این کلاینت‌ها روی اندروید، آیفون، ویندوز و مک به راحتی نصب می‌شوند:\n\n"
            "⚙️ **تنظیمات در اپلیکیشن (مانند NextChat یا Chatbox):**\n"
            "• **مدل سرویس‌دهنده (Provider):** `OpenAI`\n"
            "• **آدرس سرور (API Host / Base URL):** `http://localhost:8080` یا `http://localhost:8080/v1`\n"
            "• **کلید دسترسی (API Key):** کلید دریافتی از @FilterNet3\n"
            "• **مدل پیش‌فرض:** `gpt-5.6-sol`\n\n"
            "✅ اکنون می‌توانید از رابط کاربری زیبا با تمام امکانات و بدون فیلتر لذت ببرید!"
        )
        await query.edit_message_text(
            apps_txt,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت به پورتال توسعه‌دهندگان", callback_data="dev:hub")]]),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    if data == "dev:curl":
        await query.answer()
        curl_txt = (
            "🌐 **درخواست‌های مستقیم ترمینال و شبکه (cURL & Bash):**\n\n"
            "۱️⃣ **دریافت لیست تمام مدل‌های فعال:**\n"
            "```bash\n"
            "curl -s http://localhost:8080/v1/models \\\n"
            "  -H 'Authorization: Bearer sk-arena-your-key'\n"
            "```\n\n"
            "۲️⃣ **ارسال پرامپت و دریافت پاسخ چت:**\n"
            "```bash\n"
            "curl -s http://localhost:8080/v1/chat/completions \\\n"
            "  -H 'Authorization: Bearer sk-arena-your-key' \\\n"
            "  -H 'Content-Type: application/json' \\\n"
            "  -d '{\n"
            "    \"model\": \"gpt-5.6-sol\",\n"
            "    \"messages\": [{\"role\": \"user\", \"content\": \"سلام\"}]\n"
            "  }'\n"
            "```\n\n"
            "۳️⃣ **بررسی وضعیت سلامت سرور:**\n"
            "`curl -s http://localhost:8080/health`"
        )
        await query.edit_message_text(
            curl_txt,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت به پورتال توسعه‌دهندگان", callback_data="dev:hub")]]),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    if data == "dev:projects":
        await query.answer()
        proj_txt = (
            "🚀 **استودیو ساخت خودکار پروژه (Project Studio REST API):**\n\n"
            "شما یا هر سیستم هوش مصنوعی دیگری می‌توانید با این اندپوینت‌ها پروژه‌های نرم‌افزاری بسازید:\n\n"
            "۱️⃣ **ایجاد پروژه جدید:**\n"
            "```bash\n"
            "curl -s -X POST http://localhost:8080/api/projects \\\n"
            "  -H 'Content-Type: application/json' \\\n"
            "  -d '{\"name\": \"Web App\", \"description\": \"پروژه فروشگاهی\", \"prompt\": \"کد کامل فرانت با React\"}'\n"
            "```\n\n"
            "۲️⃣ **تولید خودکار کدها و معماری پروژه:**\n"
            "```bash\n"
            "curl -s -X POST http://localhost:8080/api/projects/<PROJECT_ID>/generate\n"
            "```\n\n"
            "۳️⃣ **مشاهده لیست پروژه‌ها:**\n"
            "`curl -s http://localhost:8080/api/projects`"
        )
        await query.edit_message_text(
            proj_txt,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت به پورتال توسعه‌دهندگان", callback_data="dev:hub")]]),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    # 1. Game Hub Navigation
    if data == "xo:menu:hub":
        await query.answer()
        await query.edit_message_text(
            "🎮 **به آرنا گیم (Arena XO Duel) خوش آمدید!**\n\n"
            "🌟 **کاملاً بدون فیلتر و مستقیم داخل تلگرام!**\n"
            "یک گزینه را انتخاب کنید:",
            reply_markup=game_engine.get_game_hub_markup(),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    # 2. Rules
    if data == "xo:menu:rules":
        await query.answer()
        await query.edit_message_text(
            game_engine.GAME_RULES,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 بازگشت به منوی بازی", callback_data="xo:menu:hub")]
            ]),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    # 3. Leaderboard
    if data == "xo:menu:top":
        await query.answer()
        leaders = db.get_game_leaderboard(10)
        lines = ["🏆 **جدول برترین‌های بازی آنلاین:**", ""]
        if not leaders:
            lines.append("هنوز هیچ بازی ثبت نشده است.")
        else:
            medals = ["🥇", "🥈", "🥉", "۴️⃣", "۵️⃣", "۶️⃣", "۷️⃣", "۸️⃣", "۹️⃣", "🔟"]
            for idx, l in enumerate(leaders):
                m = medals[idx] if idx < len(medals) else f"{idx+1}."
                lines.append(f"{m} **{l['user_name']}** — `{l['score']}` امتیاز (برد: {l['wins']} | باخت: {l['losses']})")
        lines.append("")
        lines.append("✨ هر برد = ۱۰+ امتیاز | مساوی = ۳+ امتیاز")
        await query.edit_message_text(
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 بازگشت به منوی بازی", callback_data="xo:menu:hub")]
            ]),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    # 4. Create Room (Multiplayer)
    if data in ("xo:menu:create", "xo:new_room"):
        await query.answer("اتاق بازی در حال ایجاد است...")
        room = game_engine.create_room(user.id, user.full_name, is_ai=False)
        text = game_engine.render_game_text(room, user.id)
        msg = await query.edit_message_text(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("❌ لغو و انصراف", callback_data=f"xo:surrender:{room.room_code}")],
                [InlineKeyboardButton("🔄 رفرش وضعیت", callback_data=f"xo:refresh:{room.room_code}")]
            ]),
            parse_mode=ParseMode.MARKDOWN,
        )
        room.creator_msg_id = msg.message_id
        room.creator_chat_id = query.message.chat_id
        return

    # 5. Join Room Prompt
    if data == "xo:menu:join":
        await query.answer()
        ui_sessions[user.id]["awaiting_game_code"] = True
        await query.edit_message_text(
            "🔑 **ورود به اتاق بازی با کد عددی:**\n\n"
            "دوست شما یک کد ۵ رقمی برایتان فرستاده است؟\n\n"
            "کافیست **کد ۵ رقمی را همینجا تایپ و ارسال کنید**\n"
            "یا دستور زیر را بفرستید:\n"
            "`/join 12345`\n\n"
            "به محض فرستادن کد، بازی بلافاصله برای هر دو نفر استارت می‌خورد!",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 بازگشت به منوی بازی", callback_data="xo:menu:hub")]
            ]),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    # 6. Single Player AI Mode
    if data == "xo:menu:ai":
        await query.answer("نبرد با هوش مصنوعی آغاز شد!")
        room = game_engine.create_room(user.id, user.full_name, is_ai=True)
        text = game_engine.render_game_text(room, user.id)
        msg = await query.edit_message_text(
            text,
            reply_markup=game_engine.render_board_markup(room),
            parse_mode=ParseMode.MARKDOWN,
        )
        room.creator_msg_id = msg.message_id
        room.creator_chat_id = query.message.chat_id
        return

    # 7. Make Move: xo:m:<room_code>:<cell_idx>
    if data.startswith("xo:m:"):
        parts = data.split(":")
        if len(parts) == 4:
            room_code = parts[2]
            cell_idx = int(parts[3])
            success, err_msg, room = game_engine.make_move(room_code, user.id, cell_idx)
            if not success:
                await query.answer(err_msg, show_alert=True)
                return

            await query.answer()
            # Update current player
            text_curr = game_engine.render_game_text(room, user.id)
            markup = game_engine.render_board_markup(room)
            try:
                await query.edit_message_text(text_curr, reply_markup=markup, parse_mode=ParseMode.MARKDOWN)
            except Exception:
                pass

            # Update opponent if multiplayer
            if not room.is_ai and room.opponent_id:
                other_id = room.opponent_id if user.id == room.creator_id else room.creator_id
                other_msg_id = room.opponent_msg_id if user.id == room.creator_id else room.creator_msg_id
                other_chat_id = room.opponent_chat_id if user.id == room.creator_id else room.creator_chat_id
                if other_chat_id and other_msg_id:
                    text_other = game_engine.render_game_text(room, other_id)
                    try:
                        await context.bot.edit_message_text(
                            chat_id=other_chat_id,
                            message_id=other_msg_id,
                            text=text_other,
                            reply_markup=markup,
                            parse_mode=ParseMode.MARKDOWN,
                        )
                    except Exception:
                        pass
            return

    # 8. Surrender: xo:surrender:<room_code>
    if data.startswith("xo:surrender:"):
        room_code = data.split(":")[-1]
        success, err_msg, room = game_engine.surrender_room(room_code, user.id)
        if not success:
            await query.answer(err_msg, show_alert=True)
            return
        await query.answer("انصراف ثبت شد.")
        text_curr = game_engine.render_game_text(room, user.id)
        markup = game_engine.render_board_markup(room)
        try:
            await query.edit_message_text(text_curr, reply_markup=markup, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            pass
        if not room.is_ai and room.opponent_id:
            other_id = room.opponent_id if user.id == room.creator_id else room.creator_id
            other_msg_id = room.opponent_msg_id if user.id == room.creator_id else room.creator_msg_id
            other_chat_id = room.opponent_chat_id if user.id == room.creator_id else room.creator_chat_id
            if other_chat_id and other_msg_id:
                text_other = game_engine.render_game_text(room, other_id)
                try:
                    await context.bot.edit_message_text(
                        chat_id=other_chat_id,
                        message_id=other_msg_id,
                        text=text_other,
                        reply_markup=markup,
                        parse_mode=ParseMode.MARKDOWN,
                    )
                except Exception:
                    pass
        return

    # 9. Refresh: xo:refresh:<room_code>
    if data.startswith("xo:refresh:"):
        room_code = data.split(":")[-1]
        room = game_engine.get_room(room_code)
        if room:
            await query.answer("بروزرسانی شد ✅")
            text = game_engine.render_game_text(room, user.id)
            markup = game_engine.render_board_markup(room)
            try:
                await query.edit_message_text(text, reply_markup=markup, parse_mode=ParseMode.MARKDOWN)
            except Exception:
                pass
        else:
            await query.answer("اتاق یافت نشد.", show_alert=True)
        return

    # 10. Key Management & Colleague Callbacks
    if (data.startswith("kpanel:") or data.startswith("kview:") or 
        data.startswith("ktoggle:") or data.startswith("kquicktoggle:") or
        data.startswith("knew:") or data.startswith("kdel:") or data.startswith("kprompt:")):
        uname = (getattr(user, "username", None) or "").strip().lower().lstrip("@")
        if uname != "filternet3" and not db.is_admin(user.id, uname):
            await query.answer("⛔ دسترسی غیرمجاز! منحصراً برای @FilterNet3", show_alert=True)
            return

        if data == "kpanel:close":
            await query.answer("بسته شد.")
            try:
                await query.message.delete()
            except Exception:
                pass
            return

        if data == "kpanel:refresh":
            await query.answer("بروزرسانی شد ✅")
            text, markup = build_keys_panel_markup()
            try:
                await query.edit_message_text(text, reply_markup=markup, parse_mode=ParseMode.MARKDOWN)
            except Exception:
                pass
            return

        if data.startswith("kview:"):
            key = data.split("kview:", 1)[1]
            await query.answer()
            text, markup = build_single_key_markup(key)
            try:
                await query.edit_message_text(text, reply_markup=markup, parse_mode=ParseMode.MARKDOWN)
            except Exception:
                pass
            return

        if data.startswith("kquicktoggle:"):
            key = data.split("kquicktoggle:", 1)[1]
            new_st = db.toggle_api_key_active(key)
            status_word = "روشن شد 🟢" if new_st else "خاموش شد 🔴"
            await query.answer(f"کلید {status_word}")
            text, markup = build_keys_panel_markup()
            try:
                await query.edit_message_text(text, reply_markup=markup, parse_mode=ParseMode.MARKDOWN)
            except Exception:
                pass
            return

        if data.startswith("ktoggle:"):
            key = data.split("ktoggle:", 1)[1]
            new_st = db.toggle_api_key_active(key)
            status_word = "روشن و فعال شد 🟢" if new_st else "خاموش و غیرفعال شد 🔴"
            await query.answer(f"کلید {status_word}", show_alert=True)
            text, markup = build_single_key_markup(key)
            try:
                await query.edit_message_text(text, reply_markup=markup, parse_mode=ParseMode.MARKDOWN)
            except Exception:
                pass
            return

        if data == "knew:collab":
            new_k = db.create_api_key_with_project(role="همکار")
            await query.answer(f"کلید همکار «{new_k['name']}» ساخته شد! 👥", show_alert=True)
            text, markup = build_keys_panel_markup()
            try:
                await query.edit_message_text(text, reply_markup=markup, parse_mode=ParseMode.MARKDOWN)
            except Exception:
                pass
            return

        if data == "knew:ai":
            new_k = db.create_api_key_with_project(role="ایجنت هوش مصنوعی")
            await query.answer(f"کلید هوش مصنوعی «{new_k['name']}» ساخته شد! 🤖", show_alert=True)
            text, markup = build_keys_panel_markup()
            try:
                await query.edit_message_text(text, reply_markup=markup, parse_mode=ParseMode.MARKDOWN)
            except Exception:
                pass
            return

        if data.startswith("kdel:"):
            key = data.split("kdel:", 1)[1]
            deleted = db.delete_api_key(key)
            if deleted:
                await query.answer("کلید حذف شد 🗑️", show_alert=True)
            else:
                await query.answer("کلید قابل حذف نیست.", show_alert=True)
            text, markup = build_keys_panel_markup()
            try:
                await query.edit_message_text(text, reply_markup=markup, parse_mode=ParseMode.MARKDOWN)
            except Exception:
                pass
            return

        if data.startswith("kprompt:"):
            key = data.split("kprompt:", 1)[1]
            await query.answer()
            pub_url = get_public_url()
            base_url = f"{pub_url}/v1" if pub_url else "http://localhost:8080/v1"
            prompt_text = (
                f"📋 **پرامپت آماده اتصال برای هوش مصنوعی دیگر (بدون خطای Connection Refused):**\n\n"
                f"```text\n"
                f"تو به عنوان دستیار هوشمند به سرور اختصاصی Arena AI متصل هستی.\n"
                f"چون در یک محیط ایزوله اجرا می‌شوی، ابتدا دستور زیر را اجرا کن تا پورت 8080 در محیط تو فعال شود:\n"
                f"python3 ~/.gemini/mitra_bot_storage/arena_bridge.py --boot\n\n"
                f"API Key: {key}\n"
                f"Base URL: {base_url}\n"
                f"حالا به {base_url}/chat/completions درخواست بفرست یا دستور زیر را اجرا کن:\n"
                f"python3 ~/.gemini/mitra_bot_storage/arena_bridge.py \"سلام تست اتصال\" \"{key}\"\n"
                f"```\n\n"
                f"💻 **کد اتصال استاندارد پایتون (OpenAI SDK):**\n"
                f"```python\n"
                f"import subprocess\n"
                f"subprocess.run(['python3', '/home/antigravity/.gemini/mitra_bot_storage/arena_bridge.py', '--boot'])\n"
                f"from openai import OpenAI\n"
                f"client = OpenAI(base_url='{base_url}', api_key='{key}')\n"
                f"res = client.chat.completions.create(\n"
                f"    model='gpt-5.6-sol',\n"
                f"    messages=[{{'role': 'user', 'content': 'سلام'}}]\n"
                f")\n"
                f"print(res.choices[0].message.content)\n"
                f"```\n\n"
                f"💡 کادرهای بالا را لمس کنید تا کپی شوند."
            )
            await query.message.reply_text(prompt_text, parse_mode=ParseMode.MARKDOWN)
            return


async def cmd_token(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await handle_messages(update, context)


def create_bot_application() -> Application:
    db.init_db()
    app = Application.builder().token(BOT_TOKEN).concurrent_updates(True).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("token", cmd_token))
    app.add_handler(CommandHandler("newtoken", cmd_token))
    app.add_handler(CommandHandler("gamekey", cmd_token))
    app.add_handler(CommandHandler("apk", cmd_token))
    app.add_handler(CommandHandler("key", cmd_keys_panel))
    app.add_handler(CommandHandler("keys", cmd_keys_panel))
    app.add_handler(CommandHandler("apikey", cmd_keys_panel))
    app.add_handler(CommandHandler("panel", cmd_keys_panel))
    app.add_handler(CommandHandler("newkey", cmd_newkey))
    app.add_handler(CommandHandler("game", cmd_game))
    app.add_handler(CommandHandler("xo", cmd_game))
    app.add_handler(CommandHandler("join", cmd_join))
    app.add_handler(CommandHandler("rules", cmd_rules))
    app.add_handler(CommandHandler("top", cmd_top))
    app.add_handler(CommandHandler("projects", cmd_projects))
    app.add_handler(CommandHandler("newproject", cmd_newproject))
    app.add_handler(CommandHandler("dev", cmd_developer))
    app.add_handler(CommandHandler("developer", cmd_developer))
    app.add_handler(CommandHandler("docs", cmd_developer))
    app.add_handler(CommandHandler("api", cmd_developer))
    app.add_handler(CommandHandler("image", cmd_image))
    app.add_handler(CommandHandler("img", cmd_image))
    app.add_handler(CallbackQueryHandler(handle_callback_query))
    media_filter = (filters.TEXT | filters.PHOTO | filters.Document.ALL | filters.VIDEO | filters.AUDIO | filters.VOICE) & ~filters.COMMAND
    app.add_handler(MessageHandler(media_filter, handle_messages))
    return app


