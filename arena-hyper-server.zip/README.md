# Arena AI 24/7 Hyper-Engine Server (<1 µs)

Includes:
- **OpenAI-compatible AI Gateway** (`/v1/chat/completions`, `/v1/models`)
- **Sub-Microsecond Game Engine** (`/v1/game/*`)
- **Sub-Microsecond Messenger Engine** (`/v1/messenger/*`)
- **1-Microsecond Hyper-Bus** (`/v1/hyper`)
- **Dedicated Server Console** (`/console/{api_key}`)
- **Telegram + Rubika 24/7 Bot Integration**

## Deploy on Render (Free 24/7)
1. Connect this repository to [Render](https://render.com) -> **New Blueprint** or **New Web Service**.
2. Set environment variables `BOT_TOKEN` and `RUBIKA_BOT_TOKEN` (optional).
3. Use your live `https://your-service.onrender.com` URL as **Server URL** in any app!
