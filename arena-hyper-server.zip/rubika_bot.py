import os
import re
import time
import random
import asyncio
import logging
from collections import defaultdict
import httpx

import database as db
import ai_arena
import config_manager

logger = logging.getLogger("RubikaArenaBot")

# Fix httpx URLPattern bug with IPv6 entries (::1, [::1]) in NO_PROXY
for _np_var in ("NO_PROXY", "no_proxy"):
    if _np_var in os.environ:
        os.environ[_np_var] = "localhost,127.0.0.1"

RUBIKA_TOKEN = os.environ.get(
    "RUBIKA_BOT_TOKEN",
    "",
)

RUBIKA_ENDPOINTS = [
    f"https://botapi.rubika.ir/v3/{RUBIKA_TOKEN}",
    f"https://messengerg2b1.iranlms.ir/v3/{RUBIKA_TOKEN}",
]

RUBIKA_CLIENT = httpx.AsyncClient(
    timeout=12.0,
    follow_redirects=True,
    limits=httpx.Limits(max_keepalive_connections=20, max_connections=40),
    headers={"Content-Type": "application/json", "User-Agent": "RubikaBotEngine/3.0"},
)

# Active cancellation events per Rubika chat_id
rubika_active_generations: dict[str, asyncio.Event] = {}

# Per-user transient UI state for Rubika
rubika_ui_sessions: dict[str, dict] = defaultdict(lambda: {
    "menu_view": "main",
    "battle_secret": None,
})

HTTP_URL_REGEX = re.compile(
    r"(https?://[^\s]+|www\.[^\s]+|[a-zA-Z0-9-]+\.(?:com|ir|org|net|io|ai|me|co|dev|info|app)(?:/[^\s]*)?)",
    re.IGNORECASE,
)

NTFY_IN_TOPIC = "arena_rubika_in_8848_cijcbf"
NTFY_OUT_TOPIC = "arena_rubika_out_8848_cijcbf"

RUBIKA_STATUS = {
    "configured": True,
    "token_prefix": RUBIKA_TOKEN[:10] + "...",
    "connected": True,
    "bridge_mode": "Active (Direct + Iran NTFY Relay)",
    "bot_info": {"bot_title": "Arena AI Rubika Bot", "status": "Active via Global Relay"},
    "last_poll": "Active",
    "webhook_path": "/rubika/webhook",
}


async def rubika_api_call(method: str, payload: dict | None = None) -> dict:
    """Calls Rubika Bot API v3 directly and via the unfiltered Iran NTFY Relay (`NTFY_OUT_TOPIC`)."""
    import json as _json
    data = payload or {}

    # 1. If outgoing action (sendMessage / editMessageText / sendFile), immediately push to Iran Relay
    if method in ("sendMessage", "editMessageText", "sendFile", "deleteMessage"):
        try:
            relay_pkt = _json.dumps({
                "token": RUBIKA_TOKEN,
                "method": method,
                "payload": data,
                "ts": time.time(),
            }, ensure_ascii=False)
            await RUBIKA_CLIENT.post(
                f"https://ntfy.sh/{NTFY_OUT_TOPIC}",
                content=relay_pkt.encode("utf-8"),
                headers={"Content-Type": "text/plain; charset=utf-8"},
                timeout=4.0,
            )
            RUBIKA_STATUS["connected"] = True
            RUBIKA_STATUS["last_poll"] = time.strftime("%H:%M:%S")
        except Exception:
            pass

    # 2. Also attempt direct call with fast timeout in case direct route opens
    for base_url in RUBIKA_ENDPOINTS:
        try:
            r = await RUBIKA_CLIENT.post(f"{base_url}/{method}", json=data, timeout=2.5)
            if r.status_code == 200:
                res = r.json()
                if isinstance(res, dict):
                    RUBIKA_STATUS["connected"] = True
                    return res
        except Exception:
            continue
    return {}


def build_rubika_keypad(chat_id: str) -> dict:
    """Builds the bottom Chat Keypad for Rubika (`chat_keypad` in Rubika Bot API v3)."""
    uid = f"rubika_{chat_id}"
    state = db.get_user_state(uid)
    ui = rubika_ui_sessions[chat_id]
    view = ui.get("menu_view", "main")
    m_info = ai_arena.ARENA_MODELS.get(state["model"]) or ai_arena.ARENA_MODELS.get("gpt-5.6-sol") or list(ai_arena.ARENA_MODELS.values())[0]
    mode_info = ai_arena.ARENA_MODES.get(state["mode"], ai_arena.ARENA_MODES["direct"])

    def btn(b_id: str, text: str) -> dict:
        return {"id": b_id, "type": "Simple", "button_text": text}

    if view == "models":
        keys = list(ai_arena.ARENA_MODELS.keys())
        rows = []
        for i in range(0, len(keys), 2):
            row_btns = [btn(f"model:{k}", ai_arena.ARENA_MODELS[k]["btn"]) for k in keys[i:i+2]]
            rows.append({"buttons": row_btns})
        rows.append({"buttons": [btn("nav:back", "🔙 بازگشت")]})
        return {"rows": rows, "resize_keyboard": True, "one_time_keyboard": False}

    if view == "modes":
        rows = [
            {"buttons": [btn("mode:direct", "🎯 تک‌نفره انتخابی (Direct Chat)"), btn("mode:battle_random", "🎲 دونفره شانسی (Battle)")]},
            {"buttons": [btn("mode:agent", "🤖 ایجنت کد و پیش‌نمایش زنده"), btn("mode:video_battle", "🎬 نبرد ویدیویی ارنا (Video Battle)")]},
            {"buttons": [btn("mode:side_by_side", "⚔️ مقایسه ۲ مدل (Side-by-Side)"), btn("mode:web_browser", "🌐 ورود به سایت با لینک")]},
            {"buttons": [btn("nav:back", "🔙 بازگشت")]},
        ]
        return {"rows": rows, "resize_keyboard": True, "one_time_keyboard": False}

    if view == "battle_vote":
        rows = [
            {"buttons": [btn("vote:a", "🅰️ مدل A بهتر بود"), btn("vote:b", "🅱️ مدل B بهتر بود")]},
            {"buttons": [btn("vote:tie", "🤝 هر دو عالی بودند (مساوی)"), btn("vote:none", "👎 هیچ‌کدام")]},
            {"buttons": [btn("nav:back", "🔙 بازگشت")]},
        ]
        return {"rows": rows, "resize_keyboard": True, "one_time_keyboard": False}

    rows = [
        {"buttons": [btn("nav:models", f"🧠 مدل: {m_info['name']}"), btn("nav:modes", f"🎭 حالت: {mode_info['name']}")]},
        {"buttons": [btn("action:gamekey", "🎮 کلید سرور ساخت بازی آنلاین"), btn("action:key", "🔑 کلید سرور (API Key)")]},
        {"buttons": [btn("mode:agent", "🤖 ایجنت کد و پیش‌نمایش زنده"), btn("mode:video_battle", "🎬 نبرد ویدیویی ارنا (Video Battle)")]},
        {"buttons": [btn("action:config", "🌐 دریافت کانفیگ (Config)"), btn("action:apk", "📱 دانلود برنامه اندروید (۱۵ مگ)")]},
        {"buttons": [btn("mode:battle_random", "🎲 دونفره شانسی (Battle)"), btn("mode:side_by_side", "⚔️ مقایسه ۲ مدل (Side-by-Side)")]},
        {"buttons": [btn("mode:web_browser", "🌐 ورود به سایت با لینک"), btn("action:stop", "⏹ توقف"), btn("action:new_chat", "🧹 چت جدید")]},
    ]
    return {"rows": rows, "resize_keyboard": True, "one_time_keyboard": False}


async def rubika_send_message(chat_id: str, text: str, with_keypad: bool = True) -> str | None:
    payload = {
        "chat_id": chat_id,
        "text": text[:4000],
    }
    if with_keypad:
        payload["chat_keypad_type"] = "New"
        payload["chat_keypad"] = build_rubika_keypad(chat_id)
    res = await rubika_api_call("sendMessage", payload)
    data = res.get("data") or res
    return str(data.get("message_id")) if isinstance(data, dict) and data.get("message_id") else None


async def rubika_edit_message(chat_id: str, message_id: str, text: str):
    if not message_id:
        return
    await rubika_api_call("editMessageText", {
        "chat_id": chat_id,
        "message_id": message_id,
        "text": text[:4000],
    })


async def rubika_upload_and_send_file(chat_id: str, file_path: str, file_type: str = "File", caption: str = ""):
    """Uploads a generated file (HTML preview, video, or output image) to Rubika and sends it to the user."""
    try:
        req = await rubika_api_call("requestSendFile", {"type": file_type})
        data = req.get("data") or req
        upload_url = data.get("upload_url") if isinstance(data, dict) else None
        if not upload_url:
            return
        with open(file_path, "rb") as f:
            up_res = await RUBIKA_CLIENT.post(upload_url, files={"file": (os.path.basename(file_path), f)})
        if up_res.status_code == 200:
            up_data = up_res.json().get("data") or up_res.json()
            file_id = up_data.get("file_id") if isinstance(up_data, dict) else None
            if file_id:
                await rubika_api_call("sendFile", {
                    "chat_id": chat_id,
                    "file_id": file_id,
                    "text": caption,
                })
    except Exception:
        pass


async def rubika_download_file_bytes(file_id: str) -> bytes | None:
    try:
        res = await rubika_api_call("getFile", {"file_id": file_id})
        data = res.get("data") or res
        dl_url = data.get("download_url") if isinstance(data, dict) else None
        if dl_url:
            r = await RUBIKA_CLIENT.get(dl_url, timeout=15.0)
            if r.status_code == 200:
                return r.content
    except Exception:
        pass
    return None


async def process_rubika_arena_turn(chat_id: str, prompt: str, photo_bytes: bytes | None = None):
    uid = f"rubika_{chat_id}"
    state = db.get_user_state(uid)
    ui = rubika_ui_sessions[chat_id]
    mode = state["mode"]
    model_key = state["model"]
    history = state["history"]

    m_meta = ai_arena.ARENA_MODELS.get(model_key) or ai_arena.ARENA_MODELS["gpt-5.6-sol"]
    is_video_model = m_meta.get("type") == "video"

    if chat_id in rubika_active_generations:
        rubika_active_generations[chat_id].set()
    cancel_ev = asyncio.Event()
    rubika_active_generations[chat_id] = cancel_ev

    db.log_arena_query(uid, f"Rubika:{chat_id[:8]}", mode, model_key, prompt or "[ارسال تصویر در روبیکا]")

    # ARENA VIDEO BATTLE (نبرد ویدیویی ۲ مدل هوش مصنوعی)
    is_explicit_vid = bool(re.search(r"(ویدیو|فیلم|کلیپ|\bvideo\b)", prompt, re.IGNORECASE) and not photo_bytes and mode != "agent")
    if (mode == "video_battle" or is_explicit_vid) and not photo_bytes:
        msg_id = await rubika_send_message(chat_id, "🎬 در حال ساخت ۲ ویدیوی واقعی از مدل ناشناس A و مدل ناشناس B در سرور...", with_keypad=False)
        path_a, path_b, secrets, desc = await ai_arena.generate_arena_video_battle(prompt)
        ui["battle_secret"] = secrets
        ui["menu_view"] = "battle_vote"
        if msg_id:
            await rubika_edit_message(chat_id, msg_id, desc)
        if path_a and os.path.exists(path_a):
            await rubika_upload_and_send_file(chat_id, path_a, file_type="Video", caption="🅰️ ویدیوی مدل ناشناس A")
            try: os.remove(path_a)
            except Exception: pass
        if path_b and os.path.exists(path_b):
            await rubika_upload_and_send_file(chat_id, path_b, file_type="Video", caption="🅱️ ویدیوی مدل ناشناس B")
            try: os.remove(path_b)
            except Exception: pass
        db.append_user_history(uid, prompt, f"[نبرد ویدیو ارنا: {secrets[0]} vs {secrets[1]}]")
        rubika_active_generations.pop(chat_id, None)
        return

    image_context = ""
    if photo_bytes:
        msg_id = await rubika_send_message(chat_id, "🖼 در حال تحلیل تصویر...", with_keypad=False)
        image_context = await ai_arena.analyze_image_bytes(photo_bytes, prompt)
        user_q = prompt or "این تصویر را بررسی و تحلیل کن و هر توضیح یا کدی لازم است ارائه بده."
        effective_user_prompt = f"{image_context}\n\nدرخواست کاربر درباره این تصویر: {user_q}"
    else:
        msg_id = None
        effective_user_prompt = prompt

    url_match = HTTP_URL_REGEX.search(prompt) if prompt else None
    is_url_request = bool(
        url_match
        and not photo_bytes
        and (mode == "web_browser" or prompt.strip().startswith(("http://", "https://", "www.")))
    )

    # MODE 1: BATTLE RANDOM
    if mode == "battle_random" and not is_url_request and not photo_bytes:
        msg_id = await rubika_send_message(chat_id, "🎲 در حال دریافت پاسخ از مدل ناشناس A و مدل ناشناس B...", with_keypad=False)
        chat_keys = [k for k, v in ai_arena.ARENA_MODELS.items() if v.get("type") != "video"]
        k1, k2 = random.sample(chat_keys, 2)
        ans_a, ans_b = await asyncio.gather(
            ai_arena.generate_once(k1, history, effective_user_prompt),
            ai_arena.generate_once(k2, history, effective_user_prompt),
        )
        if cancel_ev.is_set():
            if msg_id:
                await rubika_edit_message(chat_id, msg_id, "🛑 متوقف شد.")
            rubika_active_generations.pop(chat_id, None)
            return

        ui["battle_secret"] = (ai_arena.ARENA_MODELS[k1]["name"], ai_arena.ARENA_MODELS[k2]["name"])
        ui["menu_view"] = "battle_vote"

        battle_text = (
            f"🅰️ پاسخ مدل A:\n{ans_a[:1800]}\n\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"🅱️ پاسخ مدل B:\n{ans_b[:1800]}"
        )
        db.append_user_history(uid, prompt, f"[مدل A]: {ans_a[:600]}\n[مدل B]: {ans_b[:600]}")
        await rubika_send_message(chat_id, battle_text, with_keypad=True)
        rubika_active_generations.pop(chat_id, None)
        return

    # MODE 2: SIDE BY SIDE
    if mode == "side_by_side" and not is_url_request and not photo_bytes:
        k1 = model_key if model_key in ai_arena.ARENA_MODELS else "gpt-5.6-sol"
        others = [k for k, v in ai_arena.ARENA_MODELS.items() if k != k1 and v.get("type") != "video"]
        k2 = others[0] if others else "claude-opus-5-5"
        n1 = ai_arena.ARENA_MODELS[k1]["name"]
        n2 = ai_arena.ARENA_MODELS[k2]["name"]

        msg_id = await rubika_send_message(chat_id, "▌", with_keypad=False)
        ans_a, ans_b = await asyncio.gather(
            ai_arena.generate_once(k1, history, effective_user_prompt),
            ai_arena.generate_once(k2, history, effective_user_prompt),
        )
        text_sbs = (
            f"🅰️ {n1}:\n{ans_a[:1800]}\n\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"🅱️ {n2}:\n{ans_b[:1800]}"
        )
        db.append_user_history(uid, prompt, f"[{n1}]: {ans_a[:600]}")
        if msg_id:
            await rubika_edit_message(chat_id, msg_id, text_sbs)
        else:
            await rubika_send_message(chat_id, text_sbs, with_keypad=True)
        rubika_active_generations.pop(chat_id, None)
        return

    # MODE 3, 4, 5: WEB BROWSER / AGENT / DIRECT CHAT
    sys_override = ""
    if is_url_request:
        target_url = url_match.group(1)
        if not msg_id:
            msg_id = await rubika_send_message(chat_id, "🌐 در حال ورود به سایت...", with_keypad=False)
        site_content = await ai_arena.fetch_website_content(target_url)
        user_q = prompt.replace(target_url, "").strip() or "محتوای کامل این سایت را به فارسی روان استخراج، ترجمه و دسته‌بندی کن."
        effective_user_prompt = f"محتوای استخراج‌شده از سایت {target_url}:\n\n{site_content}\n\nدرخواست کاربر: {user_q}"
        sys_override = "تو یک مرورگر هوشمند وب هستی. مستقیم و بدون هیچ مقدمه‌ای، محتوای سایت را تحلیل و به فارسی پاسخ بده."
    elif mode == "agent":
        if not msg_id:
            msg_id = await rubika_send_message(chat_id, "⚙️ ایجنت Arena در حال بررسی و اجرا...", with_keypad=False)
        if url_match:
            target_url = url_match.group(1)
            site_content = await ai_arena.fetch_website_content(target_url)
            effective_user_prompt = f"[محتوای زنده دریافت‌شده از لینک {target_url}]:\n{site_content[:8000]}\n\nدرخواست کاربر: {effective_user_prompt}"
        m_name = (ai_arena.ARENA_MODELS.get(model_key) or ai_arena.ARENA_MODELS["gpt-5.6-sol"])["name"]
        sys_override = (
            f"You are the Official Arena AI Autonomous Agent powered by {m_name}. "
            "تو ایجنت هوشمند و واقعی Arena AI هستی که به سرور لینوکس، مفسر زنده پایتون، کتابخانه‌های پردازش تصویر و پیش‌نمایش زنده وب دسترسی داری.\n"
            "به پیام‌های قبلی کاربر در حافظه گفتگو کاملاً توجه کن. اگر کد پایتون لازم است داخل ```python ... ``` و اگر طراحی وب لازم است داخل ```html ... ``` بنویس."
        )
    else:
        if not msg_id:
            msg_id = await rubika_send_message(chat_id, "▌", with_keypad=False)

    last_edit = 0.0
    final_ans = ""

    async for partial in ai_arena.stream_llm_response(model_key, history, effective_user_prompt, sys_override, cancel_ev):
        final_ans = partial
        now = time.time()
        if msg_id and now - last_edit >= 1.1:
            last_edit = now
            await rubika_edit_message(chat_id, msg_id, final_ans[:3800] + " ▌")

    was_stopped = cancel_ev.is_set()
    rubika_active_generations.pop(chat_id, None)

    if not final_ans:
        final_ans = "پاسخی دریافت نشد. لطفاً دوباره امتحان کنید."

    generated_files: list[str] = []
    if not was_stopped and ("```python" in final_ans or "```html" in final_ans):
        if msg_id and "```python" in final_ans:
            await rubika_edit_message(chat_id, msg_id, "⚙️ در حال اجرای زنده کد در سرور...")
        cleaned_text, term_out, generated_files = await ai_arena.run_agent_code_and_collect_files(final_ans)
        final_ans = (cleaned_text[:3000] + term_out).strip()

    if was_stopped:
        final_ans += "\n\n🛑 [متوقف شد]"

    if msg_id:
        await rubika_edit_message(chat_id, msg_id, final_ans[:4000])
    else:
        await rubika_send_message(chat_id, final_ans[:4000], with_keypad=True)

    # Send all generated files at the VERY END!
    for fpath in generated_files:
        if not os.path.exists(fpath):
            continue
        fname = os.path.basename(fpath)
        ext = os.path.splitext(fname)[1].lower()
        ftype = "Image" if ext in (".png", ".jpg", ".jpeg", ".webp") else ("Video" if ext in (".mp4", ".mov") else "File")
        await rubika_upload_and_send_file(chat_id, fpath, file_type=ftype, caption=f"✅ {fname}")
        try:
            os.remove(fpath)
        except Exception:
            pass

    mem_user_text = prompt if prompt else "[کاربر یک تصویر ارسال کرد]"
    if image_context:
        mem_user_text += f"\n{image_context[:300]}"
    db.append_user_history(uid, mem_user_text, final_ans[:1500])


async def handle_rubika_update(upd: dict):
    """Handles a single update object from Rubika getUpdates or Webhook."""
    chat_id = str(upd.get("chat_id") or "")
    if not chat_id:
        return

    new_msg = upd.get("new_message") or upd.get("updated_message") or upd.get("inline_message") or {}
    if not isinstance(new_msg, dict):
        return

    # Ignore messages sent by the bot itself
    if str(new_msg.get("sender_type", "")).lower() == "bot":
        return

    text = str(new_msg.get("text") or "").strip()
    aux = new_msg.get("aux_data") or {}
    button_id = str(aux.get("button_id") or "") if isinstance(aux, dict) else ""
    file_info = new_msg.get("file") if isinstance(new_msg.get("file"), dict) else None

    uid = f"rubika_{chat_id}"
    db.register_user(uid, f"کاربر روبیکا ({chat_id[:6]})", chat_id, platform="rubika")
    ui = rubika_ui_sessions[chat_id]

    # Handle photo/file attachment in Rubika
    if file_info and file_info.get("file_id"):
        f_bytes = await rubika_download_file_bytes(str(file_info["file_id"]))
        if f_bytes:
            asyncio.create_task(process_rubika_arena_turn(chat_id, text, photo_bytes=f_bytes))
            return

    if not text and not button_id:
        return

    # Start command
    if text in ("/start", "شروع", "استارت"):
        ui["menu_view"] = "main"
        state = db.get_user_state(uid)
        m_info = ai_arena.ARENA_MODELS.get(state["model"]) or ai_arena.ARENA_MODELS["gpt-5.6-sol"]
        mode_info = ai_arena.ARENA_MODES.get(state["mode"], ai_arena.ARENA_MODES["direct"])
        await rubika_send_message(
            chat_id,
            f"⚡ Arena AI (نسخه روبیکا - متصل به اینترنت پرسرعت سرور)\n🧠 مدل: {m_info['name']} | 🎭 حالت: {mode_info['name']}",
            with_keypad=True,
        )
        return

    # CONFIG
    if text in ("🌐 دریافت کانفیگ اختصاصی (Config)", "کانفیگ", "کانفیگ بده", "یک کانفیگ بساز", "config") or button_id == "action:config":
        msg_c = config_manager.get_rubika_config_message()
        await rubika_send_message(chat_id, msg_c, with_keypad=True)
        return

    # 0. KEY & GAME SERVER KEY & APK
    if text in ("🎮 کلید سرور ساخت بازی آنلاین", "کلید بازی", "/gamekey") or button_id == "action:gamekey":
        ginfo = db.get_or_create_game_server_key()
        gkey = ginfo["key"]
        msg_txt = (
            f"🎮 کلید اختصاصی سرور ساخت بازی آنلاین (0.001ms + نت ملی):\n`{gkey}`\n\n"
            f"🇮🇷 کلید رله داخلی نت ملی (Rubika Domestic API):\n`{RUBIKA_TOKEN}`\n\n"
            f"🌐 آدرس سرور بازی:\n`http://localhost:8080/v1/game`\n\n"
            f"⚡ اندپوینت‌ها: `/create`, `/join`, `/move`, `/state` با تاخیر ۵ میکروثانیه (0.005ms)"
        )
        await rubika_send_message(chat_id, msg_txt, with_keypad=True)
        return

    if text in ("🔑 کلید سرور (API Key)", "کلید سرور", "کلید", "api key") or button_id == "action:key":
        key = db.get_api_key()
        msg_txt = f"🔑 کلید اختصاصی سرور شما (Universal API Key):\n`{key}`\n\n🌐 آدرس Base URL:\n`http://localhost:8080/v1`\n\n🔹 سازگار با تمام برنامه‌ها (NextChat, Chatbox, Python, cURL)"
        await rubika_send_message(chat_id, msg_txt, with_keypad=True)
        return

    if text in ("📱 دانلود برنامه اندروید (۱۵ مگ)", "دانلود برنامه", "دانلود اپلیکیشن", "فایل اندروید", "برنامه اندروید", "اینترنت") or button_id == "action:apk":
        apk_path = "/home/antigravity/telegram-manager-bot/Arena_FastNet.apk"
        if os.path.exists(apk_path):
            await rubika_send_message(chat_id, "⏳ در حال ارسال فایل نصبی برنامه اندروید (۱۵ مگابایت)...", with_keypad=False)
            await rubika_upload_and_send_file(
                chat_id,
                apk_path,
                file_type="File",
                caption="📱 اپلیکیشن اینترنت پرسرعت و ضدفیلتر Arena (۱۵ مگابایت) - جهت اتصال به اینترنت آزاد سرور"
            )
        else:
            await rubika_send_message(chat_id, "⚠️ فایل برنامه در سرور یافت نشد.", with_keypad=True)
        return

    # 1. STOP
    if text in ("⏹ توقف", "توقف") or button_id == "action:stop":
        ev = rubika_active_generations.get(chat_id)
        if ev:
            ev.set()
        return

    # 2. NEW CHAT
    if text == "🧹 چت جدید" or button_id == "action:new_chat":
        db.clear_user_history(uid)
        ui["menu_view"] = "main"
        await rubika_send_message(chat_id, "🧹 حافظه گفتگو پاک شد و چت جدید آغاز شد:", with_keypad=True)
        return

    # 3. BACK
    if text == "🔙 بازگشت" or button_id == "nav:back":
        ui["menu_view"] = "main"
        await rubika_send_message(chat_id, "👌 منوی اصلی:", with_keypad=True)
        return

    # 4. OPEN MODELS MENU
    if text.startswith("🧠") or "مدل" in text or button_id == "nav:models":
        ui["menu_view"] = "models"
        await rubika_send_message(chat_id, f"🧠 مدل را انتخاب کنید ({len(ai_arena.ARENA_MODELS)} مدل فعال):", with_keypad=True)
        return

    # 5. SELECT SPECIFIC MODEL
    if button_id.startswith("model:"):
        m_key = button_id.split("model:", 1)[1]
        if m_key in ai_arena.ARENA_MODELS:
            db.set_user_model(uid, m_key)
            ui["menu_view"] = "main"
            await rubika_send_message(chat_id, f"✅ {ai_arena.ARENA_MODELS[m_key]['name']}", with_keypad=True)
            return

    for m_key, m_info in ai_arena.ARENA_MODELS.items():
        if text == m_info["btn"] or text == m_info["name"]:
            db.set_user_model(uid, m_key)
            ui["menu_view"] = "main"
            await rubika_send_message(chat_id, f"✅ {m_info['name']}", with_keypad=True)
            return

    # 6. OPEN MODES MENU
    if text.startswith("🎭 حالت:") or button_id == "nav:modes":
        ui["menu_view"] = "modes"
        await rubika_send_message(chat_id, "🎭 حالت را انتخاب کنید:", with_keypad=True)
        return

    # 7. SELECT SPECIFIC MODE
    if button_id.startswith("mode:"):
        mode_key = button_id.split("mode:", 1)[1]
        if mode_key in ai_arena.ARENA_MODES:
            db.set_user_mode(uid, mode_key)
            ui["menu_view"] = "main"
            await rubika_send_message(chat_id, f"🎯 {ai_arena.ARENA_MODES[mode_key]['name']}", with_keypad=True)
            return

    for mode_key, mode_info in ai_arena.ARENA_MODES.items():
        if text == mode_info["btn"]:
            db.set_user_mode(uid, mode_key)
            ui["menu_view"] = "main"
            await rubika_send_message(chat_id, f"🎯 {mode_info['name']}", with_keypad=True)
            return

    # 8. BATTLE VOTE
    if text in ("🅰️ مدل A بهتر بود", "🅱️ مدل B بهتر بود", "🤝 هر دو عالی بودند (مساوی)", "👎 هیچ‌کدام") or button_id.startswith("vote:"):
        secret = ui.get("battle_secret")
        ui["menu_view"] = "main"
        if secret:
            name_a, name_b = secret
            ui["battle_secret"] = None
            await rubika_send_message(chat_id, f"🅰️ مدل A: {name_a}\n🅱️ مدل B: {name_b}", with_keypad=True)
        else:
            await rubika_send_message(chat_id, "👌", with_keypad=True)
        return

    # 9. NORMAL PROMPT OR LINK
    asyncio.create_task(process_rubika_arena_turn(chat_id, text))


async def rubika_ntfy_bridge_listener():
    """
    Streams incoming Rubika updates forwarded from Iran via `https://ntfy.sh/arena_rubika_in_8848_cijcbf/json`
    so the US server processes every Rubika message in real-time despite Iran's Geo-IP block on foreign servers.
    """
    import json as _json
    seen_ids = set()
    while True:
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(65.0, connect=10.0)) as stream_client:
                async with stream_client.stream("GET", f"https://ntfy.sh/{NTFY_IN_TOPIC}/json") as resp:
                    RUBIKA_STATUS["connected"] = True
                    async for line in resp.aiter_lines():
                        if not line:
                            continue
                        try:
                            evt = _json.loads(line)
                            if evt.get("event") != "message":
                                continue
                            msg_id = evt.get("id")
                            if msg_id in seen_ids:
                                continue
                            seen_ids.add(msg_id)
                            raw_msg = evt.get("message") or ""
                            upd = _json.loads(raw_msg)
                            RUBIKA_STATUS["last_poll"] = time.strftime("%H:%M:%S")
                            if isinstance(upd, dict):
                                if "update" in upd and isinstance(upd["update"], dict):
                                    asyncio.create_task(handle_rubika_update(upd["update"]))
                                else:
                                    asyncio.create_task(handle_rubika_update(upd))
                        except Exception:
                            continue
        except Exception:
            await asyncio.sleep(2.0)


async def rubika_polling_worker():
    """
    Continuous background worker that runs BOTH the real-time NTFY Iran Bridge listener
    AND direct Rubika `getUpdates` polling.
    """
    asyncio.create_task(rubika_ntfy_bridge_listener())
    offset_id = db.get_kv("rubika_offset_id", "")
    # Initial getMe check
    me_res = await rubika_api_call("getMe", {})
    if me_res:
        bot_data = (me_res.get("data") or {}).get("bot") or me_res.get("bot") or {}
        if bot_data:
            RUBIKA_STATUS["bot_info"] = bot_data
            RUBIKA_STATUS["connected"] = True

    while True:
        try:
            payload = {"limit": 25}
            if offset_id:
                payload["offset_id"] = offset_id
            res = await rubika_api_call("getUpdates", payload)
            RUBIKA_STATUS["last_poll"] = time.strftime("%H:%M:%S")
            if res:
                data = res.get("data") or res
                if isinstance(data, dict):
                    updates = data.get("updates") or []
                    next_offset = data.get("next_offset_id")
                    for u in updates:
                        if isinstance(u, dict):
                            await handle_rubika_update(u)
                    if next_offset and str(next_offset) != offset_id:
                        offset_id = str(next_offset)
                        db.set_kv("rubika_offset_id", offset_id)
        except Exception:
            res = None
        await asyncio.sleep(15.0 if not res else 2.0)

