"""
Filter-free, Ultra-Fast Interactive Multiplayer & AI XO Game Engine for Telegram.
Runs 100% natively inside Telegram chat via InlineKeyboardMarkup and CallbackQueries.
No external web links, no VPN/filter issues in Iran.
Supports 5-digit numeric room codes for instant 2-player matchmaking ("و تمام").
"""

import time
import random
import logging
from typing import Optional, Tuple
from telegram import InlineKeyboardMarkup, InlineKeyboardButton

import database as db

logger = logging.getLogger("GameEngine")

GAME_RULES = """📜 **قوانین رسمی بازی آنلاین دو نفره Arena XO:**

۱️⃣ **کد عددی اتاق:** به محض انتخاب «ساخت اتاق بازی»، یک کد ۵ رقمی اختصاصی دریافت می‌کنید.
۲️⃣ **اتصال دوست شما:** دوست شما کافیست دکمه «🔑 ورود با کد عددی» را بزند یا دستور `/join <کد>` را بفرستد تا **فوراً و بدون نیاز به هیچ تنظیماتی** بازی آغاز شود!
۳️⃣ **بدون فیلتر (۱۰۰٪ تضمینی):** این بازی مستقیماً از طریق دکمه‌های شیشه‌ای تلگرام کنترل می‌شود و هیچ لینک خارجی یا وب‌سایتی ندارد و هرگز فیلتر نمی‌شود.
۴️⃣ **مهلت نوبت:** هر بازیکن در نوبت خود ۳۰ ثانیه مهلت بازی دارد. نماد بازیکن اول ❌ و بازیکن دوم ⭕ است.
۵️⃣ **شرط برد:** اولین بازیکنی که ۳ مهره خود را در یک خط (افقی، عمودی یا مورب) بچیند برنده می‌شود (۱۰+ امتیاز).
۶️⃣ **مساوی:** در صورت پر شدن تمام ۹ خانه بدون برنده، بازی مساوی اعلام شده و به هر دو بازیکن ۳ امتیاز تعلق می‌گیرد.
۷️⃣ **انصراف:** خروج یا زدن دکمه تسلیم به منزله باخت قطعی است."""

WINNING_COMBINATIONS = [
    (0, 1, 2), (3, 4, 5), (6, 7, 8),  # Rows
    (0, 3, 6), (1, 4, 7), (2, 5, 8),  # Columns
    (0, 4, 8), (2, 4, 6),             # Diagonals
]


class GameRoom:
    def __init__(self, room_code: str, creator_id: int, creator_name: str, is_ai: bool = False):
        self.room_code = room_code
        self.creator_id = creator_id
        self.creator_name = creator_name
        self.creator_chat_id = creator_id
        self.creator_msg_id: Optional[int] = None

        self.opponent_id: Optional[int] = -1 if is_ai else None
        self.opponent_name: Optional[str] = "🤖 هوش مصنوعی Arena" if is_ai else None
        self.opponent_chat_id: Optional[int] = None
        self.opponent_msg_id: Optional[int] = None

        self.is_ai = is_ai
        self.board = [""] * 9  # 9 cells: "" or "X" or "O"
        self.current_turn = "X"  # "X" goes first (creator)
        self.status = "playing" if is_ai else "waiting"  # "waiting", "playing", "finished"
        self.winner: Optional[str] = None  # "X", "O", "draw", None
        self.winner_id: Optional[int] = None
        self.winning_line: Optional[Tuple[int, int, int]] = None
        self.created_at = time.time()
        self.last_move_at = time.time()

    def is_participant(self, user_id: int) -> bool:
        return user_id == self.creator_id or user_id == self.opponent_id

    def get_symbol(self, user_id: int) -> str:
        if user_id == self.creator_id:
            return "X"
        if user_id == self.opponent_id:
            return "O"
        return ""

    def get_player_name(self, symbol: str) -> str:
        if symbol == "X":
            return self.creator_name
        if symbol == "O":
            return self.opponent_name or "حریف"
        return ""


# Active in-memory rooms: room_code -> GameRoom
active_rooms: dict[str, GameRoom] = {}
user_active_room: dict[int, str] = {}


def generate_room_code() -> str:
    """Generates a unique 5-digit numeric room code."""
    for _ in range(100):
        code = str(random.randint(10000, 99999))
        if code not in active_rooms:
            return code
    return str(int(time.time()) % 100000)


def create_room(user_id: int, user_name: str, is_ai: bool = False) -> GameRoom:
    """Creates a new game room."""
    # Clean up any existing room user was in
    old_code = user_active_room.get(user_id)
    if old_code and old_code in active_rooms:
        if active_rooms[old_code].status == "waiting":
            del active_rooms[old_code]

    code = generate_room_code()
    room = GameRoom(code, user_id, user_name, is_ai=is_ai)
    active_rooms[code] = room
    user_active_room[user_id] = code
    return room


def get_room(room_code: str) -> Optional[GameRoom]:
    return active_rooms.get(str(room_code).strip())


def join_room(user_id: int, user_name: str, room_code: str) -> Tuple[bool, str, Optional[GameRoom]]:
    """Player 2 joins the room via numeric code."""
    room = get_room(room_code)
    if not room:
        return False, "❌ اتاق با این کد عددی یافت نشد یا منقضی شده است.", None

    if room.status != "waiting":
        return False, "⚠️ این اتاق در حال بازی است یا قبلاً تکمیل شده است.", None

    if room.creator_id == user_id:
        return False, "⚠️ شما سازنده همین اتاق هستید! کد را به دوست خود بدهید تا وارد شود.", None

    room.opponent_id = user_id
    room.opponent_name = user_name
    room.opponent_chat_id = user_id
    room.status = "playing"
    room.last_move_at = time.time()
    user_active_room[user_id] = room.room_code

    return True, "✅ شما با موفقیت وارد بازی شدید!", room


def check_winner(board: list[str]) -> Tuple[Optional[str], Optional[Tuple[int, int, int]]]:
    """Returns ('X'|'O'|'draw'|None, winning_line)."""
    for line in WINNING_COMBINATIONS:
        a, b, c = line
        if board[a] and board[a] == board[b] == board[c]:
            return board[a], line

    if all(cell != "" for cell in board):
        return "draw", None

    return None, None


def get_best_ai_move(board: list[str]) -> int:
    """Returns best cell index (0-8) for AI ('O')."""
    # 1. Can AI win immediately?
    for cell in range(9):
        if board[cell] == "":
            board[cell] = "O"
            w, _ = check_winner(board)
            board[cell] = ""
            if w == "O":
                return cell

    # 2. Can player ('X') win immediately? Block them!
    for cell in range(9):
        if board[cell] == "":
            board[cell] = "X"
            w, _ = check_winner(board)
            board[cell] = ""
            if w == "X":
                return cell

    # 3. Take center if available
    if board[4] == "":
        return 4

    # 4. Take random corner (0, 2, 6, 8)
    corners = [i for i in [0, 2, 6, 8] if board[i] == ""]
    if corners:
        return random.choice(corners)

    # 5. Take any empty cell
    empties = [i for i in range(9) if board[i] == ""]
    return random.choice(empties) if empties else -1


def make_move(room_code: str, user_id: int, cell_idx: int) -> Tuple[bool, str, Optional[GameRoom]]:
    """Processes a move by user_id."""
    room = get_room(room_code)
    if not room or room.status != "playing":
        return False, "بازی فعال نیست.", None

    if not (0 <= cell_idx < 9):
        return False, "خانه نامعتبر است.", None

    user_symbol = room.get_symbol(user_id)
    if not user_symbol:
        return False, "شما بازیکن این اتاق نیستید.", None

    if room.current_turn != user_symbol:
        return False, "⚠️ نوبت شما نیست! لطفاً صبر کنید تا حریف بازی کند.", None

    if room.board[cell_idx] != "":
        return False, "این خانه قبلاً انتخاب شده است.", None

    # Apply move
    room.board[cell_idx] = user_symbol
    room.last_move_at = time.time()

    # Check for win or draw
    winner, line = check_winner(room.board)
    if winner:
        room.status = "finished"
        room.winner = winner
        room.winning_line = line
        if winner == "X":
            room.winner_id = room.creator_id
            db.record_game_stats(room.creator_id, room.creator_name, won=True)
            if not room.is_ai and room.opponent_id:
                db.record_game_stats(room.opponent_id, room.opponent_name or "", lost=True)
        elif winner == "O":
            room.winner_id = room.opponent_id
            if not room.is_ai and room.opponent_id:
                db.record_game_stats(room.opponent_id, room.opponent_name or "", won=True)
            db.record_game_stats(room.creator_id, room.creator_name, lost=True)
        elif winner == "draw":
            db.record_game_stats(room.creator_id, room.creator_name, draw=True)
            if not room.is_ai and room.opponent_id:
                db.record_game_stats(room.opponent_id, room.opponent_name or "", draw=True)
        return True, "حرکت ثبت شد.", room

    # Switch turn
    room.current_turn = "O" if room.current_turn == "X" else "X"

    # If opponent is AI, make AI move
    if room.is_ai and room.current_turn == "O" and room.status == "playing":
        ai_cell = get_best_ai_move(room.board)
        if ai_cell != -1:
            room.board[ai_cell] = "O"
            room.last_move_at = time.time()
            ai_w, ai_line = check_winner(room.board)
            if ai_w:
                room.status = "finished"
                room.winner = ai_w
                room.winning_line = ai_line
                if ai_w == "O":
                    room.winner_id = -1
                    db.record_game_stats(room.creator_id, room.creator_name, lost=True)
                elif ai_w == "draw":
                    db.record_game_stats(room.creator_id, room.creator_name, draw=True)
            else:
                room.current_turn = "X"

    return True, "حرکت ثبت شد.", room


def surrender_room(room_code: str, user_id: int) -> Tuple[bool, str, Optional[GameRoom]]:
    """Player surrenders."""
    room = get_room(room_code)
    if not room or room.status != "playing":
        return False, "بازی فعالی یافت نشد.", None

    if not room.is_participant(user_id):
        return False, "شما عضو این بازی نیستید.", None

    room.status = "finished"
    surrender_symbol = room.get_symbol(user_id)
    winner_symbol = "O" if surrender_symbol == "X" else "X"
    room.winner = winner_symbol

    if winner_symbol == "X":
        room.winner_id = room.creator_id
        db.record_game_stats(room.creator_id, room.creator_name, won=True)
        if not room.is_ai and room.opponent_id:
            db.record_game_stats(room.opponent_id, room.opponent_name or "", lost=True)
    else:
        room.winner_id = room.opponent_id
        if not room.is_ai and room.opponent_id:
            db.record_game_stats(room.opponent_id, room.opponent_name or "", won=True)
        db.record_game_stats(room.creator_id, room.creator_name, lost=True)

    return True, "انصراف شما ثبت شد و بازی به پایان رسید.", room


def render_board_markup(room: GameRoom) -> InlineKeyboardMarkup:
    """Renders the 3x3 interactive board."""
    symbols = {"X": "❌", "O": "⭕", "": "⬜"}
    keyboard = []
    for r in range(3):
        row = []
        for c in range(3):
            idx = r * 3 + c
            val = room.board[idx]
            txt = symbols.get(val, "⬜")
            # If game finished and this cell is in winning line, mark with star
            if room.status == "finished" and room.winning_line and idx in room.winning_line:
                txt = "⭐" + txt
            cb = f"xo:m:{room.room_code}:{idx}"
            row.append(InlineKeyboardButton(txt, callback_data=cb))
        keyboard.append(row)

    if room.status == "playing":
        keyboard.append([
            InlineKeyboardButton("🏳️ انصراف و تسلیم", callback_data=f"xo:surrender:{room.room_code}"),
            InlineKeyboardButton("🔄 رفرش صفحه", callback_data=f"xo:refresh:{room.room_code}")
        ])
    elif room.status == "finished":
        keyboard.append([
            InlineKeyboardButton("🎲 ساخت اتاق جدید", callback_data="xo:menu:create"),
            InlineKeyboardButton("🤖 بازی با AI", callback_data="xo:menu:ai"),
        ])
        keyboard.append([
            InlineKeyboardButton("🏆 جدول امتیازات", callback_data="xo:menu:top"),
            InlineKeyboardButton("🎮 منوی اصلی بازی", callback_data="xo:menu:hub")
        ])

    return InlineKeyboardMarkup(keyboard)


def render_game_text(room: GameRoom, viewer_id: int) -> str:
    """Generates rich Persian game status message."""
    c_name = room.creator_name
    o_name = room.opponent_name or "در انتظار بازیکن..."

    lines = [
        "🎮 **نبرد آنلاین دوز (Arena XO Duel)**",
        f"🔢 کد عددی اتاق: `{room.room_code}`",
        "━━━━━━━━━━━━━━━━━━━━━",
        f"❌ بازیکن ۱: **{c_name}**",
        f"⭕ بازیکن ۲: **{o_name}**",
        "━━━━━━━━━━━━━━━━━━━━━",
    ]

    if room.status == "waiting":
        lines.append("⏳ **در انتظار ورود بازیکن دوم...**")
        lines.append(f"کد عددی اتاق: `{room.room_code}`")
        lines.append("کافیست دوست شما این کد ۵ رقمی را وارد کند تا بازی شروع شود!")
    elif room.status == "playing":
        turn_symbol = room.current_turn
        turn_name = room.get_player_name(turn_symbol)
        is_my_turn = (viewer_id == room.creator_id and turn_symbol == "X") or \
                     (viewer_id == room.opponent_id and turn_symbol == "O")
        badge = "👉 **نوبت شماست!**" if is_my_turn else f"⏳ نوبت: **{turn_symbol} {turn_name}**"
        lines.append(badge)
        lines.append("*(روی یکی از خانه‌های خالی ⬜ کلیک کنید)*")
    elif room.status == "finished":
        if room.winner == "draw":
            lines.append("🤝 **بازی مساوی شد!**")
            lines.append("✨ هر دو بازیکن عالی بازی کردند (+۳ امتیاز).")
        else:
            w_symbol = room.winner
            w_name = room.get_player_name(w_symbol)
            lines.append(f"🏆 **تبریک! بازیکن {w_symbol} ({w_name}) برنده شد!**")
            lines.append("🎉 **+۱۰ امتیاز** به حساب برنده اضافه شد.")

    return "\n".join(lines)


def get_game_hub_markup() -> InlineKeyboardMarkup:
    """Main Game Menu Buttons."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🎲 ساخت اتاق بازی دو نفره (کد عددی)", callback_data="xo:menu:create")],
        [InlineKeyboardButton("🔑 ورود به اتاق با کد عددی", callback_data="xo:menu:join")],
        [InlineKeyboardButton("🤖 بازی با هوش مصنوعی Arena AI", callback_data="xo:menu:ai")],
        [
            InlineKeyboardButton("🏆 برترین‌های بازی (Top)", callback_data="xo:menu:top"),
            InlineKeyboardButton("📜 قوانین بازی", callback_data="xo:menu:rules")
        ],
    ])
