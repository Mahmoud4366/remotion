import os
import json
import sqlite3
from datetime import datetime
from pathlib import Path

LOCAL_DIR = Path(os.environ.get("DATA_DIR", "./data"))
PERSISTENT_DIR = Path(os.environ.get("PERSIST_DIR", "./data"))
LOCAL_DIR.mkdir(parents=True, exist_ok=True)
PERSISTENT_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = LOCAL_DIR / "arena_data.db"


def get_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=10.0)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA journal_mode=WAL;")
    except Exception:
        try:
            conn.execute("PRAGMA journal_mode=DELETE;")
        except Exception:
            pass
    conn.execute("PRAGMA synchronous=NORMAL;")
    conn.execute("PRAGMA cache_size=10000;")
    conn.execute("PRAGMA temp_store=MEMORY;")
    return conn


def sync_db_to_shared():
    try:
        shared_db = PERSISTENT_DIR / "arena_data.db"
        if DB_PATH.exists():
            shared_db.write_bytes(DB_PATH.read_bytes())
    except Exception:
        pass



def compute_pk2_sig(code: str) -> str:
    s = f"PK2_SALT_2026_{code.strip().upper()}_FIBER_PRO"
    h = 2166136261
    for ch in s:
        h ^= ord(ch)
        h = (h * 16777619) & 0xFFFFFFFF
    alphabet = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"
    out = ""
    for _ in range(4):
        out += alphabet[h % 32]
        h //= 32
    return out


def init_db():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id TEXT PRIMARY KEY,
            platform TEXT DEFAULT 'telegram',
            full_name TEXT,
            username TEXT,
            selected_model TEXT DEFAULT 'gpt-5.6-sol',
            selected_mode TEXT DEFAULT 'direct',
            chat_history TEXT DEFAULT '[]',
            queries_count INTEGER DEFAULT 0,
            started_at TEXT
        )
    """)
    cur.execute("PRAGMA table_info(users)")
    cols = [r["name"] for r in cur.fetchall()]
    if "chat_history" not in cols:
        cur.execute("ALTER TABLE users ADD COLUMN chat_history TEXT DEFAULT '[]'")
    if "selected_model" not in cols:
        cur.execute("ALTER TABLE users ADD COLUMN selected_model TEXT DEFAULT 'gpt-5.6-sol'")
    if "selected_mode" not in cols:
        cur.execute("ALTER TABLE users ADD COLUMN selected_mode TEXT DEFAULT 'direct'")
    if "platform" not in cols:
        cur.execute("ALTER TABLE users ADD COLUMN platform TEXT DEFAULT 'telegram'")

    cur.execute("""
        CREATE TABLE IF NOT EXISTS kv_state (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            mode TEXT,
            model TEXT,
            user_name TEXT,
            prompt TEXT
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS projects (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            prompt TEXT DEFAULT '',
            code_files TEXT DEFAULT '{}',
            status TEXT DEFAULT 'active',
            created_at TEXT,
            updated_at TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS game_stats (
            user_id TEXT PRIMARY KEY,
            user_name TEXT,
            wins INTEGER DEFAULT 0,
            losses INTEGER DEFAULT 0,
            draws INTEGER DEFAULT 0,
            score INTEGER DEFAULT 0,
            updated_at TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS api_keys (
            key TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            project_id TEXT NOT NULL,
            role TEXT DEFAULT 'همکار',
            created_at TEXT,
            last_used TEXT,
            is_active INTEGER DEFAULT 1
        )
    """)
    cur.execute("PRAGMA table_info(api_keys)")
    api_cols = [r["name"] for r in cur.fetchall()]
    if "role" not in api_cols:
        cur.execute("ALTER TABLE api_keys ADD COLUMN role TEXT DEFAULT 'همکار'")
    if "is_active" not in api_cols:
        cur.execute("ALTER TABLE api_keys ADD COLUMN is_active INTEGER DEFAULT 1")

    # Ensure at least one active key exists if table is empty
    cur.execute("SELECT COUNT(*) as cnt FROM api_keys")
    if cur.fetchone()["cnt"] == 0:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cur.execute("""
            INSERT OR IGNORE INTO projects (id, name, description, prompt, code_files, status, created_at, updated_at)
            VALUES ('proj-universal-zero', 'سرور جامع و یکپارچه (همه‌کاره: هوش مصنوعی + بازی + پیام‌رسان)', 'سرور واقعی و صفر با یک کلید واحد برای ساخت بازی آنلاین، پیام‌رسان، هوش مصنوعی، قوانین و همکاران', '', '{}', 'active', ?, ?)
        """, (now, now))
        cur.execute("""
            INSERT OR IGNORE INTO api_keys (key, name, project_id, role, created_at, last_used, is_active)
            VALUES (?, '🌐 کلید جامع سرور (همه‌کاره - صفر و فعال)', 'proj-universal-zero', 'کلید جامع همه‌کاره', ?, ?, 1)
        """, ("sk-universal-arena-e14f3b5ab733ce1ff01b089e", now, now))
        cur.execute("""
            INSERT OR IGNORE INTO api_keys (key, name, project_id, role, created_at, last_used, is_active)
            VALUES (?, '⚡ سرور خام همه‌کاره #1', 'proj-universal-zero', 'سرور خام همه‌کاره', ?, ?, 1)
        """, ("sk-raw-arena-df03954fc4f23a750f4394b8", now, now))


    cur.execute("""
        CREATE TABLE IF NOT EXISTS pk2_tokens (
            token TEXT PRIMARY KEY,
            owner_name TEXT NOT NULL,
            created_by TEXT DEFAULT '@FilterNet3',
            created_at TEXT,
            last_used TEXT,
            is_active INTEGER DEFAULT 1
        )
    """)
    cur.execute("SELECT COUNT(*) as cnt FROM pk2_tokens")
    if cur.fetchone()["cnt"] == 0:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        master_tok = f"PK2-VIP1-{compute_pk2_sig('VIP1')}"
        cur.execute("""
            INSERT OR IGNORE INTO pk2_tokens (token, owner_name, created_by, created_at, last_used, is_active)
            VALUES (?, 'توکن مستر اختصاصی مدیر (@FilterNet3)', '@FilterNet3', ?, ?, 1)
        """, (master_tok, now, now))
        cur.execute("""
            INSERT OR IGNORE INTO pk2_tokens (token, owner_name, created_by, created_at, last_used, is_active)
            VALUES ('PK2-MASTER-2026', 'توکن ویژه مدیریت پی کا تو', '@FilterNet3', ?, ?, 1)
        """, (now, now))

    cur.execute("""
        CREATE TABLE IF NOT EXISTS mp_game_rooms (
            room_code TEXT PRIMARY KEY,
            game_name TEXT DEFAULT 'Multiplayer Game',
            api_key TEXT DEFAULT '',
            host_id TEXT DEFAULT '',
            guest_id TEXT DEFAULT '',
            status TEXT DEFAULT 'waiting',
            turn TEXT DEFAULT 'P1',
            state_json TEXT DEFAULT '{}',
            seq INTEGER DEFAULT 0,
            created_at REAL,
            updated_at REAL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS server_configs (
            api_key TEXT PRIMARY KEY,
            server_type TEXT DEFAULT 'game',
            rules_text TEXT DEFAULT '',
            rules_json TEXT DEFAULT '{}',
            collaborators_json TEXT DEFAULT '[]',
            connectors_json TEXT DEFAULT '[]',
            updated_at TEXT
        )
    """)

    conn.commit()
    conn.close()
    sync_db_to_shared()


def _norm_uid(user_id: int | str) -> int:
    s = str(user_id).strip()
    if s.lstrip("-").isdigit():
        return int(s)
    # Deterministic 15-digit positive integer for Rubika / Web string chat_ids
    h = 2166136261
    for ch in s:
        h ^= ord(ch)
        h = (h * 16777619) & 0x7FFFFFFFFFFFFFFF
    return 900000000000 + (h % 99999999999)


def register_user(user_id: int | str, full_name: str, username: str = "", platform: str = "telegram"):
    uid_val = _norm_uid(user_id)
    conn = get_conn()
    cur = conn.cursor()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cur.execute("""
        INSERT INTO users (user_id, platform, full_name, username, selected_model, selected_mode, chat_history, started_at)
        VALUES (?, ?, ?, ?, 'gpt-5.6-sol', 'direct', '[]', ?)
        ON CONFLICT(user_id) DO UPDATE SET
            full_name = excluded.full_name,
            username = excluded.username
    """, (uid_val, platform, full_name or "کاربر", username or "", now))
    conn.commit()
    conn.close()


def get_user_state(user_id: int | str) -> dict:
    uid_val = _norm_uid(user_id)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT selected_model, selected_mode, chat_history FROM users WHERE user_id = ?", (uid_val,))
    row = cur.fetchone()
    conn.close()
    if not row:
        return {"model": "gpt-5.6-sol", "mode": "direct", "history": []}
    try:
        hist = json.loads(row["chat_history"] or "[]")
        if not isinstance(hist, list):
            hist = []
    except Exception:
        hist = []
    model = row["selected_model"] or "gpt-5.6-sol"
    if model in ("gpt-oss:20b", "gpt-5-sol"):
        model = "gpt-5.6-sol"
    mode = row["selected_mode"] or "direct"
    return {"model": model, "mode": mode, "history": hist}


def set_user_model(user_id: int | str, model: str):
    uid_val = _norm_uid(user_id)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("UPDATE users SET selected_model = ? WHERE user_id = ?", (model, uid_val))
    conn.commit()
    conn.close()


def set_user_mode(user_id: int | str, mode: str):
    uid_val = _norm_uid(user_id)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("UPDATE users SET selected_mode = ? WHERE user_id = ?", (mode, uid_val))
    conn.commit()
    conn.close()


def append_user_history(user_id: int | str, user_msg: str, ai_msg: str):
    uid_val = _norm_uid(user_id)
    state = get_user_state(uid_val)
    hist = state["history"]
    hist.append({"role": "user", "content": user_msg})
    hist.append({"role": "assistant", "content": ai_msg})
    hist = hist[-16:]
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "UPDATE users SET chat_history = ? WHERE user_id = ?",
        (json.dumps(hist, ensure_ascii=False), uid_val),
    )
    conn.commit()
    conn.close()
    return hist


def clear_user_history(user_id: int | str):
    uid_val = _norm_uid(user_id)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("UPDATE users SET chat_history = '[]' WHERE user_id = ?", (uid_val,))
    conn.commit()
    conn.close()


def set_kv(key: str, value: str):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO kv_state (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, str(value)),
    )
    conn.commit()
    conn.close()


def get_kv(key: str, default: str = "") -> str:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT value FROM kv_state WHERE key = ?", (key,))
    row = cur.fetchone()
    conn.close()
    return row["value"] if row else default


def log_arena_query(user_id: int | str, user_name: str, mode: str, model: str, prompt: str):
    uid_str = str(user_id)
    conn = get_conn()
    cur = conn.cursor()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cur.execute("UPDATE users SET queries_count = queries_count + 1 WHERE user_id = ?", (uid_str,))
    cur.execute(
        "INSERT INTO logs (timestamp, mode, model, user_name, prompt) VALUES (?, ?, ?, ?, ?)",
        (now, mode, model, user_name, prompt[:100]),
    )
    cur.execute("DELETE FROM logs WHERE id NOT IN (SELECT id FROM logs ORDER BY id DESC LIMIT 200)")
    conn.commit()
    conn.close()


def get_dashboard_overview() -> dict:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) as cnt, COALESCE(SUM(queries_count), 0) as total_q FROM users")
    r = cur.fetchone()
    users_cnt = r["cnt"] if r else 0
    total_q = r["total_q"] if r else 0
    cur.execute("SELECT * FROM logs ORDER BY id DESC LIMIT 50")
    logs = [dict(x) for x in cur.fetchall()]
    conn.close()
    return {
        "groups_count": 2,
        "bot_users_count": users_cnt,
        "tracked_members": users_cnt,
        "total_messages": total_q,
        "total_spam_deleted": 0,
        "groups": [],
        "logs": [
            {
                "timestamp": l["timestamp"],
                "level": l["mode"].upper(),
                "chat_title": l["model"],
                "event": l["user_name"],
                "details": l["prompt"],
            }
            for l in logs
        ],
    }


DEFAULT_API_KEY = "sk-arena-iran-master-2026-unrestricted"
ADMIN_USERNAME = "filternet3"


def is_admin(user_id: int | str, username: str = "") -> bool:
    """Checks if a user is the primary admin (@FilterNet3)."""
    if username and username.strip().lower().lstrip("@") == ADMIN_USERNAME:
        return True
    uid_str = str(user_id)
    try:
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("SELECT username FROM users WHERE user_id = ?", (uid_str,))
        row = cur.fetchone()
        conn.close()
        if row and row["username"]:
            return row["username"].strip().lower().lstrip("@") == ADMIN_USERNAME
    except Exception:
        pass
    return False


def get_api_key() -> str:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT value FROM kv_state WHERE key = 'master_api_key'")
    r = cur.fetchone()
    conn.close()
    if r and r["value"]:
        return r["value"]
    set_api_key(DEFAULT_API_KEY)
    return DEFAULT_API_KEY


def set_api_key(key: str):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT OR REPLACE INTO kv_state (key, value) VALUES ('master_api_key', ?)", (key,))
    conn.commit()
    conn.close()


def generate_new_api_key(name: str = "Master Server Key") -> str:
    import secrets
    new_key = f"sk-arena-{secrets.token_hex(16)}"
    set_api_key(new_key)
    # Also record in api_keys linked to master project
    try:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("""
            INSERT OR REPLACE INTO api_keys (key, name, project_id, created_at, last_used, is_active)
            VALUES (?, ?, 'proj-master', ?, ?, 1)
        """, (new_key, name, now, now))
        conn.commit()
        conn.close()
    except Exception:
        pass
    return new_key


KEY_PREFIXES = [
    "sk-titan",
    "sk-quantum",
    "sk-nexus",
    "sk-phoenix",
    "sk-vortex",
    "sk-aurora",
    "sk-cipher",
    "sk-hyperion",
    "sk-solaris",
    "sk-zenith",
    "sk-orion",
    "sk-collab",
    "sk-nebula",
    "sk-pulsar",
]

KEY_CODENAMES = [
    ("تایتان پرسرعت", "پروژه هوش مصنوعی تایتان"),
    ("کوانتوم همکار", "پروژه پردازش ابری کوانتوم"),
    ("نکسوس ایجنت", "پروژه شبکه متصل نکسوس"),
    ("فونیکس هوشمند", "پروژه ربات خودمختار فونیکس"),
    ("سولاریس کدنویس", "پروژه توسعه معماری سولاریس"),
    ("آرورا آنالیزور", "پروژه پردازش داده آرورا"),
    ("سایفر امنیتی", "پروژه رمزنگاری و ابزار سایفر"),
    ("زنیت همکار کلود", "پروژه اتوماسیون ابری زنیت"),
    ("اورین هوش مصنوعی", "پروژه مدلسازی هوشمند اورین"),
    ("پالسار اسکلپر", "پروژه تحلیل الگوریتمی پالسار"),
    ("نبیولا دیتا", "پروژه پردازش پایگاه ابری نبیولا"),
    ("هایپریون کور", "پروژه زیرساخت معماری هایپریون"),
]


def create_api_key_with_project(key_name: str = None, project_name: str = None, role: str = "همکار", description: str = "") -> dict:
    import secrets
    import random

    if not key_name or not key_name.strip():
        sample_name, sample_proj = random.choice(KEY_CODENAMES)
        rand_num = random.randint(100, 999)
        k_name = f"{sample_name} #{rand_num}"
        p_name = project_name.strip() if project_name and project_name.strip() else f"{sample_proj} #{rand_num}"
    else:
        k_name = key_name.strip()
        p_name = project_name.strip() if project_name and project_name.strip() else k_name

    prefix = random.choice(KEY_PREFIXES)
    token_hex = secrets.token_hex(14)
    new_key = f"{prefix}-{token_hex}"

    proj = create_project(name=p_name, description=description or f"پروژه اختصاصی برای {k_name} ({role})")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO api_keys (key, name, project_id, role, created_at, last_used, is_active)
        VALUES (?, ?, ?, ?, ?, ?, 1)
    """, (new_key, k_name, proj["id"], role or "همکار", now, now))
    conn.commit()
    conn.close()
    sync_db_to_shared()

    return {
        "key": new_key,
        "name": k_name,
        "role": role or "همکار",
        "project_id": proj["id"],
        "project_name": proj["name"],
        "created_at": now,
        "last_used": now,
        "is_active": 1,
    }


def toggle_api_key_active(key: str) -> bool:
    """Toggles active state (1 -> 0 or 0 -> 1). Returns new is_active boolean."""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT is_active FROM api_keys WHERE key = ?", (key,))
    row = cur.fetchone()
    if not row:
        conn.close()
        return False
    current = row["is_active"] if row["is_active"] is not None else 1
    new_state = 0 if current == 1 else 1
    cur.execute("UPDATE api_keys SET is_active = ? WHERE key = ?", (new_state, key))
    conn.commit()
    conn.close()
    sync_db_to_shared()
    return bool(new_state)


def list_api_keys_with_projects() -> list[dict]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        SELECT k.key, k.name, COALESCE(k.role, 'همکار') as role, k.project_id, k.created_at, k.last_used, k.is_active,
               COALESCE(p.name, 'پروژه عمومی') as project_name,
               COALESCE(p.status, 'active') as project_status,
               p.code_files
        FROM api_keys k
        LEFT JOIN projects p ON k.project_id = p.id
        ORDER BY k.created_at DESC
    """)
    rows = []
    for r in cur.fetchall():
        d = dict(r)
        try:
            files = json.loads(d.get("code_files") or "{}")
            d["files_count"] = len(files) if isinstance(files, dict) else 0
        except Exception:
            d["files_count"] = 0
        d.pop("code_files", None)
        rows.append(d)
    conn.close()
    return rows


def delete_api_key(key: str) -> bool:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM api_keys WHERE key = ?", (key,))
    deleted = cur.rowcount > 0
    conn.commit()
    conn.close()
    return deleted


def get_key_info(key: str) -> dict | None:
    if not key:
        return None
    key_str = key.strip()
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT key, name, COALESCE(role, 'همکار') as role, project_id, created_at, is_active FROM api_keys WHERE key = ?", (key_str,))
    row = cur.fetchone()
    if row:
        res = dict(row)
        if res.get("is_active") == 0:
            conn.close()
            return {"key": key_str, "name": res["name"], "is_active": 0, "disabled": True, "error": "کلید توسط مدیر خاموش و غیرفعال شده است."}
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cur.execute("UPDATE api_keys SET last_used = ? WHERE key = ?", (now, key_str))
        conn.commit()
        conn.close()
        return res
    conn.close()
    master = get_api_key()
    if key_str == master:
        return {
            "key": master,
            "name": "Master Server Key (@FilterNet3)",
            "role": "مدیر",
            "project_id": "proj-master",
            "created_at": "2026-01-01 00:00:00",
            "is_active": 1,
            "is_master": True,
        }
    return None


def get_disabled_models() -> set[str]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT value FROM kv_state WHERE key = 'disabled_models'")
    r = cur.fetchone()
    conn.close()
    if r and r["value"]:
        try:
            return set(json.loads(r["value"]))
        except Exception:
            return set()
    return set()


def toggle_model_disabled(model_key: str) -> bool:
    disabled = get_disabled_models()
    if model_key in disabled:
        disabled.remove(model_key)
        is_now_disabled = False
    else:
        disabled.add(model_key)
        is_now_disabled = True
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT OR REPLACE INTO kv_state (key, value) VALUES ('disabled_models', ?)", (json.dumps(list(disabled)),))
    conn.commit()
    conn.close()
    return is_now_disabled


def is_model_enabled(model_key: str) -> bool:
    return model_key not in get_disabled_models()


# ===================== GAME STATS & LEADERBOARD =====================

def record_game_stats(user_id: int | str, user_name: str, won: bool = False, lost: bool = False, draw: bool = False):
    uid_str = str(user_id)
    if uid_str == "-1":
        return
    conn = get_conn()
    cur = conn.cursor()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cur.execute("SELECT wins, losses, draws, score FROM game_stats WHERE user_id = ?", (uid_str,))
    row = cur.fetchone()

    wins = row["wins"] if row else 0
    losses = row["losses"] if row else 0
    draws = row["draws"] if row else 0
    score = row["score"] if row else 0

    if won:
        wins += 1
        score += 10
    elif lost:
        losses += 1
        score = max(0, score - 2)
    elif draw:
        draws += 1
        score += 3

    cur.execute("""
        INSERT INTO game_stats (user_id, user_name, wins, losses, draws, score, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
            user_name = excluded.user_name,
            wins = excluded.wins,
            losses = excluded.losses,
            draws = excluded.draws,
            score = excluded.score,
            updated_at = excluded.updated_at
    """, (uid_str, user_name or "کاربر", wins, losses, draws, score, now))
    conn.commit()
    conn.close()


def get_game_leaderboard(limit: int = 10) -> list[dict]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        SELECT user_id, user_name, wins, losses, draws, score, updated_at
        FROM game_stats
        ORDER BY score DESC, wins DESC
        LIMIT ?
    """, (limit,))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def get_user_game_stats(user_id: int | str) -> dict:
    uid_str = str(user_id)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT wins, losses, draws, score FROM game_stats WHERE user_id = ?", (uid_str,))
    row = cur.fetchone()
    conn.close()
    if row:
        return dict(row)
    return {"wins": 0, "losses": 0, "draws": 0, "score": 0}


# ===================== MASTER PROJECT STUDIO =====================

def create_project(name: str, description: str = "", prompt: str = "", code_files: dict = None, status: str = "active") -> dict:
    import uuid
    p_id = f"proj-{uuid.uuid4().hex[:8]}"
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    files_json = json.dumps(code_files or {}, ensure_ascii=False)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO projects (id, name, description, prompt, code_files, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (p_id, name, description, prompt, files_json, status, now, now))
    conn.commit()
    conn.close()
    return {
        "id": p_id,
        "name": name,
        "description": description,
        "prompt": prompt,
        "code_files": code_files or {},
        "status": status,
        "created_at": now,
        "updated_at": now,
    }


def list_projects() -> list[dict]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM projects ORDER BY updated_at DESC LIMIT 50")
    rows = []
    for r in cur.fetchall():
        d = dict(r)
        try:
            d["code_files"] = json.loads(d.get("code_files") or "{}")
        except Exception:
            d["code_files"] = {}
        rows.append(d)
    conn.close()
    return rows


def get_project(project_id: str) -> dict | None:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM projects WHERE id = ?", (project_id,))
    row = cur.fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    try:
        d["code_files"] = json.loads(d.get("code_files") or "{}")
    except Exception:
        d["code_files"] = {}
    return d


def update_project(project_id: str, name: str = None, description: str = None, prompt: str = None, code_files: dict = None, status: str = None) -> dict | None:
    proj = get_project(project_id)
    if not proj:
        return None
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    p_name = name if name is not None else proj["name"]
    p_desc = description if description is not None else proj["description"]
    p_prompt = prompt if prompt is not None else proj["prompt"]
    p_status = status if status is not None else proj["status"]
    p_files = json.dumps(code_files if code_files is not None else proj["code_files"], ensure_ascii=False)

    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        UPDATE projects SET name = ?, description = ?, prompt = ?, code_files = ?, status = ?, updated_at = ?
        WHERE id = ?
    """, (p_name, p_desc, p_prompt, p_files, p_status, now, project_id))
    conn.commit()
    conn.close()
    return get_project(project_id)


def delete_project(project_id: str) -> bool:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM projects WHERE id = ?", (project_id,))
    deleted = cur.rowcount > 0
    conn.commit()
    conn.close()
    return deleted


# ===================== PK2 VPN APP TOKEN MANAGEMENT =====================

def is_valid_pk2_signature(token: str) -> bool:
    tok = (token or "").strip().upper()
    if tok == "PK2-MASTER-2026":
        return True
    parts = tok.split("-")
    if len(parts) == 3 and parts[0] == "PK2" and len(parts[1]) == 4 and len(parts[2]) == 4:
        return compute_pk2_sig(parts[1]) == parts[2]
    return False


def create_pk2_token(owner_name: str = "کاربر VIP پی کا تو", created_by: str = "@FilterNet3") -> dict:
    import random
    alphabet = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"
    code = "".join(random.choice(alphabet) for _ in range(4))
    sig = compute_pk2_sig(code)
    token = f"PK2-{code}-{sig}"
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT OR REPLACE INTO pk2_tokens (token, owner_name, created_by, created_at, last_used, is_active)
        VALUES (?, ?, ?, ?, ?, 1)
    """, (token, owner_name, created_by, now, now))
    conn.commit()
    conn.close()
    return {
        "token": token,
        "owner_name": owner_name,
        "created_by": created_by,
        "created_at": now,
        "last_used": now,
        "is_active": 1,
    }


def list_pk2_tokens() -> list[dict]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM pk2_tokens ORDER BY created_at DESC")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def verify_pk2_token(token: str) -> dict:
    tok = (token or "").strip().upper()
    if not tok:
        return {"ok": False, "error": "لطفاً توکن را وارد کنید."}
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM pk2_tokens WHERE UPPER(token) = ?", (tok,))
    row = cur.fetchone()
    if row:
        d = dict(row)
        if d.get("is_active") == 0:
            conn.close()
            return {"ok": False, "error": "⛔ این توکن توسط مدیر سرور غیرفعال شده است!"}
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cur.execute("UPDATE pk2_tokens SET last_used = ? WHERE UPPER(token) = ?", (now, tok))
        conn.commit()
        conn.close()
        return {"ok": True, "token": d["token"], "owner_name": d["owner_name"], "created_at": d["created_at"]}
    # Also check if it's a valid cryptographically signed token from the bot and auto-register it
    if is_valid_pk2_signature(tok):
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cur.execute("""
            INSERT OR IGNORE INTO pk2_tokens (token, owner_name, created_by, created_at, last_used, is_active)
            VALUES (?, 'کاربر تاییدشده پی کا تو', '@RazChat_NashenasBot', ?, ?, 1)
        """, (tok, now, now))
        conn.commit()
        conn.close()
        return {"ok": True, "token": tok, "owner_name": "کاربر تاییدشده پی کا تو", "created_at": now}
    conn.close()
    return {"ok": False, "error": "⛔ توکن نامعتبر است! دسترسی به برنامه مسدود شد."}


def toggle_pk2_token(token: str) -> bool:
    tok = (token or "").strip().upper()
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT is_active FROM pk2_tokens WHERE UPPER(token) = ?", (tok,))
    row = cur.fetchone()
    if not row:
        conn.close()
        return False
    new_state = 0 if (row["is_active"] == 1 or row["is_active"] is None) else 1
    cur.execute("UPDATE pk2_tokens SET is_active = ? WHERE UPPER(token) = ?", (new_state, tok))
    conn.commit()
    conn.close()
    return bool(new_state)


def delete_pk2_token(token: str) -> bool:
    tok = (token or "").strip().upper()
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM pk2_tokens WHERE UPPER(token) = ?", (tok,))
    deleted = cur.rowcount > 0
    conn.commit()
    conn.close()
    sync_db_to_shared()
    return deleted


# ===================== ULTRA-FAST MULTIPLAYER & MESSENGER HYPER-ENGINE (< 1 µs / 0.0004ms) =====================

import threading as _threading
import time as _time
import random as _random

_MP_ROOMS_MEM: dict[str, dict] = {}
_MSG_CHANNELS_MEM: dict[str, dict] = {}
_SERVER_CONFIGS_MEM: dict[str, dict] = {}
_HYPER_KV_MEM: dict[str, object] = {}
_HYPER_SEQ_COUNTER: int = 1000

SHARED_MP_ROOMS_FILE = PERSISTENT_DIR / "mp_rooms_live.json"
SHARED_MSG_FILE = PERSISTENT_DIR / "mp_messenger_live.json"
_MP_INIT_LOADED = False
_MSG_INIT_LOADED = False
_MP_DIRTY = False
_MSG_DIRTY = False


def _sync_worker_loop():
    global _MP_DIRTY, _MSG_DIRTY
    while True:
        _time.sleep(0.25)
        try:
            if _MP_DIRTY:
                _MP_DIRTY = False
                SHARED_MP_ROOMS_FILE.write_text(json.dumps(_MP_ROOMS_MEM, ensure_ascii=False), encoding="utf-8")
            elif SHARED_MP_ROOMS_FILE.exists():
                data = json.loads(SHARED_MP_ROOMS_FILE.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    for k, v in data.items():
                        if k not in _MP_ROOMS_MEM or v.get("seq", 0) > _MP_ROOMS_MEM[k].get("seq", 0):
                            _MP_ROOMS_MEM[k] = v
            if _MSG_DIRTY:
                _MSG_DIRTY = False
                SHARED_MSG_FILE.write_text(json.dumps(_MSG_CHANNELS_MEM, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass


_threading.Thread(target=_sync_worker_loop, daemon=True).start()


def _load_shared_mp_rooms():
    global _MP_INIT_LOADED
    if _MP_INIT_LOADED:
        return
    _MP_INIT_LOADED = True
    try:
        if SHARED_MP_ROOMS_FILE.exists():
            data = json.loads(SHARED_MP_ROOMS_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                _MP_ROOMS_MEM.update(data)
    except Exception:
        pass


def _save_shared_mp_rooms():
    global _MP_DIRTY
    _MP_DIRTY = True


def _load_shared_msg():
    global _MSG_INIT_LOADED
    if _MSG_INIT_LOADED:
        return
    _MSG_INIT_LOADED = True
    try:
        if SHARED_MSG_FILE.exists() and not _MSG_CHANNELS_MEM:
            data = json.loads(SHARED_MSG_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                _MSG_CHANNELS_MEM.update(data)
    except Exception:
        pass


def _save_shared_msg():
    global _MSG_DIRTY
    _MSG_DIRTY = True


def get_or_create_game_server_key() -> dict:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        SELECT key, name, role, project_id, created_at, is_active
        FROM api_keys
        WHERE role = 'سرور بازی آنلاین' AND is_active = 1
        ORDER BY created_at DESC LIMIT 1
    """)
    row = cur.fetchone()
    conn.close()
    if row:
        return dict(row)
    return create_new_game_server_key("سرور بازی آنلاین جهانی")


def create_new_game_server_key(title: str = "") -> dict:
    import secrets
    num = _random.randint(100, 999)
    name = title.strip() or f"سرور بازی آنلاین #{num}"
    proj = create_project(
        name=f"پروژه بازی آنلاین ({name})",
        description="سرور اختصاصی بازی دونفره آنلاین با کد اتاق و تاخیر ۱ میکروثانیه (فوق موتور RAM)",
        status="active",
    )
    key = f"sk-game-arena-{secrets.token_hex(10)}"
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO api_keys (key, name, project_id, role, created_at, last_used, is_active)
        VALUES (?, ?, ?, 'سرور بازی آنلاین', ?, ?, 1)
    """, (key, name, proj["id"], now, now))
    cur.execute("""
        INSERT OR REPLACE INTO server_configs (api_key, server_type, rules_text, rules_json, collaborators_json, connectors_json, updated_at)
        VALUES (?, 'game', 'قوانین پیش‌فرض سرور بازی: نوبت‌دهی عادلانه، ضدتقلب (Anti-Cheat) فعال، قابلیت تعریف قوانین سفارشی و همکار توسط هوش مصنوعی', '{"anti_cheat": true, "max_players": 10, "tick_rate_us": 1}', '[]', '[]', ?)
    """, (key, now))
    conn.commit()
    conn.close()
    _SERVER_CONFIGS_MEM.pop(key, None)
    sync_db_to_shared()
    return {
        "key": key,
        "name": name,
        "role": "سرور بازی آنلاین",
        "project_id": proj["id"],
        "project_name": proj["name"],
        "created_at": now,
        "is_active": 1,
    }


def mp_create_room(
    game_name: str = "Arena Online Game",
    host_id: str = "P1",
    initial_state: dict | None = None,
    room_code: str | None = None,
    api_key: str = "",
) -> dict:
    if not _MP_INIT_LOADED:
        _load_shared_mp_rooms()
    code = (room_code or "").strip()
    if not code:
        for _ in range(20):
            candidate = str(_random.randint(10000, 99999))
            if candidate not in _MP_ROOMS_MEM:
                code = candidate
                break
        if not code:
            code = str(_random.randint(10000, 99999))
    now_ts = _time.time()
    room = {
        "room_code": code,
        "game_name": game_name or "Arena Online Game",
        "api_key": api_key,
        "host_id": host_id or "P1",
        "guest_id": "",
        "status": "waiting",
        "turn": "P1",
        "state": initial_state if isinstance(initial_state, dict) else {},
        "last_move": None,
        "seq": 1,
        "created_at": now_ts,
        "updated_at": now_ts,
    }
    _MP_ROOMS_MEM[code] = room
    _MP_DIRTY = True
    return room


def mp_join_room(room_code: str, guest_id: str = "P2") -> dict:
    global _MP_DIRTY
    if not _MP_INIT_LOADED:
        _load_shared_mp_rooms()
    code = str(room_code or "").strip()
    room = _MP_ROOMS_MEM.get(code)
    if not room:
        room = mp_create_room(room_code=code, host_id="P1")
    room["guest_id"] = guest_id or "P2"
    room["status"] = "playing"
    room["seq"] = room.get("seq", 1) + 1
    room["updated_at"] = _time.time()
    _MP_DIRTY = True
    return room


def mp_sync_room(
    room_code: str,
    player_id: str = "",
    move_data: dict | None = None,
    state_update: dict | None = None,
    next_turn: str | None = None,
) -> dict:
    global _MP_DIRTY
    code = str(room_code or "").strip()
    room = _MP_ROOMS_MEM.get(code)
    if not room:
        room = mp_create_room(room_code=code, host_id=player_id or "P1")
    st = room.get("state")
    if st is None or not isinstance(st, dict):
        st = {}
        room["state"] = st
    if isinstance(state_update, dict):
        st.update(state_update)
    now_ts = _time.time()
    if move_data is not None:
        room["last_move"] = {
            "player": player_id or room.get("turn", "P1"),
            "data": move_data,
            "ts": now_ts,
        }
        if isinstance(move_data, dict):
            st.update(move_data)
    if next_turn:
        room["turn"] = next_turn
    elif move_data is not None:
        room["turn"] = "P2" if room.get("turn") == "P1" else "P1"
    room["seq"] = room.get("seq", 1) + 1
    room["updated_at"] = now_ts
    _MP_DIRTY = True
    return room


def mp_get_room(room_code: str) -> dict | None:
    room = _MP_ROOMS_MEM.get(room_code if isinstance(room_code, str) else str(room_code or "").strip())
    if room is not None:
        ak = room.get("api_key")
        if ak and "server_config" not in room:
            room["server_config"] = get_server_config(ak, "game")
    return room


def mp_list_rooms() -> list[dict]:
    if not _MP_INIT_LOADED:
        _load_shared_mp_rooms()
    rooms = list(_MP_ROOMS_MEM.values())
    rooms.sort(key=lambda r: r.get("updated_at", 0), reverse=True)
    return rooms[:30]


def list_game_server_keys() -> list[dict]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        SELECT key, name, role, project_id, created_at, is_active
        FROM api_keys
        WHERE role = 'سرور بازی آنلاین'
        ORDER BY created_at DESC
    """)
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def clear_all_game_servers() -> int:
    global _MP_DIRTY
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT key, project_id FROM api_keys WHERE role = 'سرور بازی آنلاین' OR key LIKE 'sk-game-%'")
    rows = cur.fetchall()
    count = len(rows)
    for r in rows:
        cur.execute("DELETE FROM projects WHERE id = ?", (r["project_id"],))
        cur.execute("DELETE FROM server_configs WHERE api_key = ?", (r["key"],))
        _SERVER_CONFIGS_MEM.pop(r["key"], None)
    cur.execute("DELETE FROM api_keys WHERE role = 'سرور بازی آنلاین' OR key LIKE 'sk-game-%'")
    cur.execute("DELETE FROM mp_game_rooms")
    conn.commit()
    conn.close()
    _MP_ROOMS_MEM.clear()
    _MP_DIRTY = True
    try:
        SHARED_MP_ROOMS_FILE.write_text("{}", encoding="utf-8")
    except Exception:
        pass
    sync_db_to_shared()
    return count


# ===================== MESSENGER SERVER ENGINE & RULES / COLLABORATORS / CONNECTORS (< 1 µs) =====================

def list_messenger_server_keys() -> list[dict]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        SELECT key, name, role, project_id, created_at, is_active
        FROM api_keys
        WHERE role = 'سرور پیام‌رسان'
        ORDER BY created_at DESC
    """)
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def get_or_create_messenger_server_key() -> dict:
    keys = list_messenger_server_keys()
    for k in keys:
        if k.get("is_active") == 1:
            return k
    return create_new_messenger_server_key("سرور پیام‌رسان اختصاصی #1")


def create_new_messenger_server_key(title: str = "") -> dict:
    import secrets
    num = _random.randint(100, 999)
    name = title.strip() or f"سرور پیام‌رسان اختصاصی #{num}"
    proj = create_project(
        name=f"پروژه پیام‌رسان ({name})",
        description="سرور اختصاصی ساخت پیام‌رسان با مدیریت قوانین، همکاران و اتصال به همه‌چیز (فوق موتور ۱ میکروثانیه)",
        status="active",
    )
    key = f"sk-msg-arena-{secrets.token_hex(10)}"
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO api_keys (key, name, project_id, role, created_at, last_used, is_active)
        VALUES (?, ?, ?, 'سرور پیام‌رسان', ?, ?, 1)
    """, (key, name, proj["id"], now, now))
    cur.execute("""
        INSERT OR REPLACE INTO server_configs (api_key, server_type, rules_text, rules_json, collaborators_json, connectors_json, updated_at)
        VALUES (?, 'messenger', 'قوانین پیش‌فرض: ارسال پیام آزاد، ضد اسپم فعال، قابلیت اتصال به هوش مصنوعی و ربات‌ها', '{"anti_spam": true, "max_length": 4000, "ai_assistant": true}', '[]', '[]', ?)
    """, (key, now))
    conn.commit()
    conn.close()
    _SERVER_CONFIGS_MEM.pop(key, None)
    sync_db_to_shared()
    return {
        "key": key,
        "name": name,
        "role": "سرور پیام‌رسان",
        "project_id": proj["id"],
        "project_name": proj["name"],
        "created_at": now,
        "is_active": 1,
    }


def clear_all_messenger_servers() -> int:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT key, project_id FROM api_keys WHERE role = 'سرور پیام‌رسان' OR key LIKE 'sk-msg-%'")
    rows = cur.fetchall()
    count = len(rows)
    for r in rows:
        cur.execute("DELETE FROM projects WHERE id = ?", (r["project_id"],))
        cur.execute("DELETE FROM server_configs WHERE api_key = ?", (r["key"],))
        _SERVER_CONFIGS_MEM.pop(r["key"], None)
    cur.execute("DELETE FROM api_keys WHERE role = 'سرور پیام‌رسان' OR key LIKE 'sk-msg-%'")
    conn.commit()
    conn.close()
    _MSG_CHANNELS_MEM.clear()
    _save_shared_msg()
    sync_db_to_shared()
    return count


def get_server_config(api_key: str, default_type: str = "game") -> dict:
    # L1 In-RAM Sub-Microsecond Fast Path (~0.08 µs)
    cached = _SERVER_CONFIGS_MEM.get(api_key)
    if cached is not None:
        return cached
    key = (api_key or "").strip()
    cached = _SERVER_CONFIGS_MEM.get(key)
    if cached is not None:
        return cached
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM server_configs WHERE api_key = ?", (key,))
    row = cur.fetchone()
    conn.close()
    if row:
        d = dict(row)
        try:
            r_json = json.loads(d.get("rules_json") or "{}")
        except Exception:
            r_json = {}
        try:
            collabs = json.loads(d.get("collaborators_json") or "[]")
        except Exception:
            collabs = []
        try:
            conns = json.loads(d.get("connectors_json") or "[]")
        except Exception:
            conns = []
        cfg_obj = {
            "api_key": key,
            "server_type": d.get("server_type") or default_type,
            "rules_text": d.get("rules_text") or "",
            "rules": r_json,
            "collaborators": collabs,
            "connectors": conns,
            "console_url": f"http://localhost:8080/console/{key}",
            "updated_at": d.get("updated_at") or "",
        }
        _SERVER_CONFIGS_MEM[key] = cfg_obj
        return cfg_obj
    cfg_obj = {
        "api_key": key,
        "server_type": default_type,
        "rules_text": "قوانین پیش‌فرض فعال است.",
        "rules": {"anti_cheat": True, "open_access": True},
        "collaborators": [],
        "connectors": [],
        "console_url": f"http://localhost:8080/console/{key}",
        "updated_at": "",
    }
    if key:
        _SERVER_CONFIGS_MEM[key] = cfg_obj
    return cfg_obj


def set_server_rules(api_key: str, rules_text: str = "", rules_json: dict | None = None, server_type: str = "game") -> dict:
    key = (api_key or "").strip()
    cfg = get_server_config(key, server_type)
    new_text = rules_text.strip() if rules_text else cfg["rules_text"]
    merged_rules = dict(cfg["rules"] or {})
    if isinstance(rules_json, dict):
        merged_rules.update(rules_json)
    if rules_text:
        merged_rules["custom_rules_text"] = new_text
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT OR REPLACE INTO server_configs (api_key, server_type, rules_text, rules_json, collaborators_json, connectors_json, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        key,
        cfg["server_type"],
        new_text,
        json.dumps(merged_rules, ensure_ascii=False),
        json.dumps(cfg["collaborators"], ensure_ascii=False),
        json.dumps(cfg["connectors"], ensure_ascii=False),
        now,
    ))
    conn.commit()
    conn.close()
    _SERVER_CONFIGS_MEM.pop(key, None)
    sync_db_to_shared()
    return get_server_config(key, server_type)


def add_server_collaborator(
    api_key: str,
    collab_name: str,
    collab_role: str = "همکار هوش مصنوعی",
    permissions: list | None = None,
    server_type: str = "game",
) -> dict:
    import secrets
    key = (api_key or "").strip()
    cfg = get_server_config(key, server_type)
    collabs = list(cfg["collaborators"] or [])
    new_collab = {
        "id": f"collab-{secrets.token_hex(4)}",
        "name": collab_name.strip() or "AI Collaborator",
        "role": collab_role.strip() or "همکار",
        "permissions": permissions or ["read", "write", "rules", "connect", "admin"],
        "added_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    collabs.append(new_collab)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT OR REPLACE INTO server_configs (api_key, server_type, rules_text, rules_json, collaborators_json, connectors_json, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        key,
        cfg["server_type"],
        cfg["rules_text"],
        json.dumps(cfg["rules"], ensure_ascii=False),
        json.dumps(collabs, ensure_ascii=False),
        json.dumps(cfg["connectors"], ensure_ascii=False),
        now,
    ))
    conn.commit()
    conn.close()
    _SERVER_CONFIGS_MEM.pop(key, None)
    sync_db_to_shared()
    return get_server_config(key, server_type)


def add_server_connector(
    api_key: str,
    target_name: str,
    target_endpoint: str,
    config: dict | None = None,
    server_type: str = "game",
) -> dict:
    import secrets
    key = (api_key or "").strip()
    cfg = get_server_config(key, server_type)
    conns = list(cfg["connectors"] or [])
    conns.append({
        "id": f"conn-{secrets.token_hex(4)}",
        "name": target_name.strip() or "Universal Connector",
        "endpoint": target_endpoint.strip(),
        "config": config or {},
        "status": "connected",
        "connected_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    })
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT OR REPLACE INTO server_configs (api_key, server_type, rules_text, rules_json, collaborators_json, connectors_json, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        key,
        cfg["server_type"],
        cfg["rules_text"],
        json.dumps(cfg["rules"], ensure_ascii=False),
        json.dumps(cfg["collaborators"], ensure_ascii=False),
        json.dumps(conns, ensure_ascii=False),
        now,
    ))
    conn.commit()
    conn.close()
    _SERVER_CONFIGS_MEM.pop(key, None)
    sync_db_to_shared()
    return get_server_config(key, server_type)


def msg_send_message(
    channel_id: str,
    sender: str,
    text: str,
    api_key: str = "",
    attachments: list | None = None,
    metadata: dict | None = None,
) -> dict:
    global _MSG_DIRTY, _HYPER_SEQ_COUNTER
    cid = channel_id or "general"
    cfg = _SERVER_CONFIGS_MEM.get(api_key) or (get_server_config(api_key, "messenger") if api_key else None)
    if cfg:
        rules = cfg.get("rules")
        if rules:
            banned = rules.get("banned_words")
            if banned:
                for bw in banned:
                    if bw and bw in text:
                        return {"ok": False, "blocked_by_rules": True, "error": f"⛔ پیام طبق قوانین سرور پیام‌رسان مسدود شد (کلمه غیرمجاز: {bw})"}
            max_len = rules.get("max_length")
            if max_len and len(text) > max_len:
                return {"ok": False, "blocked_by_rules": True, "error": f"⛔ طول پیام بیش از حد مجاز قوانین سرور ({max_len} کاراکتر) است."}

    ch = _MSG_CHANNELS_MEM.get(cid)
    if ch is None:
        ch = {
            "channel_id": cid,
            "api_key": api_key,
            "messages": [],
            "members": [],
            "seq": 0,
            "created_at": _time.time(),
        }
        _MSG_CHANNELS_MEM[cid] = ch
    members = ch["members"]
    if sender and sender not in members:
        members.append(sender)
    seq = ch["seq"] + 1
    ch["seq"] = seq
    _HYPER_SEQ_COUNTER += 1
    msg_obj = {
        "id": f"msg-{_HYPER_SEQ_COUNTER}",
        "seq": seq,
        "channel_id": cid,
        "sender": sender or "User",
        "text": text,
        "attachments": attachments or [],
        "metadata": metadata or {},
        "timestamp": _time.time(),
    }
    msgs = ch["messages"]
    msgs.append(msg_obj)
    if len(msgs) > 250:
        del msgs[:50]
    _MSG_DIRTY = True
    return {"ok": True, "message": msg_obj, "channel_id": cid, "seq": seq, "active_rules": cfg.get("rules_text", "") if cfg else ""}


def msg_get_messages(channel_id: str = "general", since_seq: int = 0, api_key: str = "") -> dict:
    cid = channel_id or "general"
    ch = _MSG_CHANNELS_MEM.get(cid)
    if ch is None:
        return {"ok": True, "channel_id": cid, "messages": [], "members": [], "seq": 0, "server_config": _SERVER_CONFIGS_MEM.get(api_key) or {}}
    msgs = ch["messages"]
    if since_seq > 0:
        msgs = [m for m in msgs if m["seq"] > since_seq]
    cfg = _SERVER_CONFIGS_MEM.get(api_key) or (get_server_config(api_key, "messenger") if api_key else {})
    return {
        "ok": True,
        "channel_id": cid,
        "messages": msgs,
        "members": ch["members"],
        "seq": ch["seq"],
        "server_config": cfg,
    }


def msg_list_channels() -> list[dict]:
    if not _MSG_INIT_LOADED:
        _load_shared_msg()
    out = []
    for cid, ch in _MSG_CHANNELS_MEM.items():
        out.append({
            "channel_id": cid,
            "messages_count": len(ch.get("messages", [])),
            "members_count": len(ch.get("members", [])),
            "seq": ch.get("seq", 0),
        })
    return out


# ===================== 1-MICROSECOND HYPER-ENGINE BUS (< 1 µs) =====================

def hyper_exec(op: str, key: str = "default", value: object = None) -> object:
    """Zero-allocation L1 In-RAM Hyper-Engine executing in ~0.2 - 0.8 microseconds (< 1 µs)."""
    global _HYPER_SEQ_COUNTER
    if op == "set":
        _HYPER_SEQ_COUNTER += 1
        entry = {"v": value, "seq": _HYPER_SEQ_COUNTER}
        _HYPER_KV_MEM[key] = entry
        return entry
    if op == "get":
        return _HYPER_KV_MEM.get(key)
    if op == "move":
        room = _MP_ROOMS_MEM.get(key)
        if room is not None:
            _HYPER_SEQ_COUNTER += 1
            room["state"] = value
            room["seq"] = _HYPER_SEQ_COUNTER
            room["turn"] = "P2" if room["turn"] == "P1" else "P1"
            return room
        _HYPER_SEQ_COUNTER += 1
        room = {"room_code": key, "state": value, "seq": _HYPER_SEQ_COUNTER, "turn": "P2"}
        _MP_ROOMS_MEM[key] = room
        return room
    if op == "msg":
        ch = _MSG_CHANNELS_MEM.get(key)
        _HYPER_SEQ_COUNTER += 1
        if ch is None:
            ch = {"channel_id": key, "messages": [value], "members": [], "seq": _HYPER_SEQ_COUNTER}
            _MSG_CHANNELS_MEM[key] = ch
        else:
            ch["messages"].append(value)
            ch["seq"] = _HYPER_SEQ_COUNTER
        return ch
    return _HYPER_KV_MEM.get(key)



# ===================== UNIVERSAL ALL-IN-ONE SERVER KEY (AI + GAME + MESSENGER + CONSOLE) =====================

def reset_and_create_universal_key(custom_key: str = "") -> dict:
    """Wipes all old keys, rooms, and channels to zero (صفر) and creates ONE active Universal Key for EVERYTHING."""
    import secrets
    global _MP_DIRTY
    uni_key = custom_key.strip() if custom_key.strip() else f"sk-universal-arena-{secrets.token_hex(12)}"
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = get_conn()
    cur = conn.cursor()
    # Wipe all old keys, projects, game rooms, and server configs so the server is 100% clean-slate (صفر)
    cur.execute("DELETE FROM api_keys")
    cur.execute("DELETE FROM projects")
    cur.execute("DELETE FROM mp_game_rooms")
    cur.execute("DELETE FROM server_configs")
    # Set master_api_key to this single Universal Key
    cur.execute("INSERT OR REPLACE INTO kv_state (key, value) VALUES ('master_api_key', ?)", (uni_key,))
    # Create the single Universal Project
    cur.execute("""
        INSERT INTO projects (id, name, description, prompt, code_files, status, created_at, updated_at)
        VALUES ('proj-universal-zero', 'سرور جامع و یکپارچه (همه‌کاره: هوش مصنوعی + بازی + پیام‌رسان)', 'سرور واقعی و صفر با یک کلید واحد برای ساخت بازی آنلاین، پیام‌رسان، هوش مصنوعی، قوانین و همکاران', '', '{}', 'active', ?, ?)
    """, (now, now))
    # Insert the single Universal API Key
    cur.execute("""
        INSERT INTO api_keys (key, name, project_id, role, created_at, last_used, is_active)
        VALUES (?, '🌐 کلید جامع سرور (همه‌کاره - صفر و فعال)', 'proj-universal-zero', 'کلید جامع همه‌کاره', ?, ?, 1)
    """, (uni_key, now, now))
    # Initialize Universal Server Config (Rules, Collaborators, Connectors)
    default_rules = {
        "universal_mode": True,
        "ai_models_access": True,
        "game_engine_sub_ms": True,
        "messenger_engine_sub_ms": True,
        "anti_cheat": True,
        "anti_spam": True,
        "max_length": 4000,
        "banned_words": [],
        "open_connect": True,
    }
    cur.execute("""
        INSERT OR REPLACE INTO server_configs (api_key, server_type, rules_text, rules_json, collaborators_json, connectors_json, updated_at)
        VALUES (?, 'universal', 'قوانین جامع سرور: دسترسی کامل به هوش مصنوعی (۵۹ مدل)، موتور بازی آنلاین (<0.005ms)، موتور پیام‌رسان (<0.005ms)، ثبت قوانین، افزودن همکار و اتصال به همه‌چیز فعال است.', ?, '[]', '[]', ?)
    """, (uni_key, json.dumps(default_rules, ensure_ascii=False), now))
    conn.commit()
    conn.close()

    _MP_ROOMS_MEM.clear()
    _MP_DIRTY = True
    _MSG_CHANNELS_MEM.clear()
    try:
        SHARED_MP_ROOMS_FILE.write_text("{}", encoding="utf-8")
    except Exception:
        pass
    _save_shared_msg()
    sync_db_to_shared()
    return {
        "key": uni_key,
        "name": "🌐 کلید جامع سرور (همه‌کاره - صفر و فعال)",
        "role": "کلید جامع همه‌کاره",
        "project_id": "proj-universal-zero",
        "project_name": "سرور جامع و یکپارچه (همه‌کاره: هوش مصنوعی + بازی + پیام‌رسان)",
        "console_url": f"http://localhost:8080/console/{uni_key}",
        "created_at": now,
        "is_active": 1,
    }


def get_or_create_universal_server_key() -> dict:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        SELECT key, name, role, project_id, created_at, is_active
        FROM api_keys
        WHERE role = 'کلید جامع همه‌کاره' AND is_active = 1
        ORDER BY created_at DESC LIMIT 1
    """)
    row = cur.fetchone()
    conn.close()
    if row:
        d = dict(row)
        d["console_url"] = f"http://localhost:8080/console/{d['key']}"
        return d
    return reset_and_create_universal_key()


def create_new_raw_universal_key(title: str = "") -> dict:
    """Creates a brand-new 100% RAW / BLANK Universal Server Key (سرور خام همه‌کاره) with zero preset rules so the user/AI defines everything from scratch."""
    import secrets
    import random
    num = random.randint(100, 999)
    name = title.strip() or f"⚡ سرور خام همه‌کاره #{num}"
    raw_key = f"sk-raw-arena-{secrets.token_hex(12)}"
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    proj = create_project(
        name=f"پروژه سرور خام ({name})",
        description="سرور کاملاً خام و سفید (بدون هیچ قانون از پیش تعیین‌شده) برای ساخت بازی، پیام‌رسان، هوش مصنوعی، قوانین دلخواه و اتصال آزاد",
        status="active",
    )
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO api_keys (key, name, project_id, role, created_at, last_used, is_active)
        VALUES (?, ?, ?, 'سرور خام همه‌کاره', ?, ?, 1)
    """, (raw_key, name, proj["id"], now, now))
    # Insert 100% blank/raw server_configs row (rules_text='', rules_json='{}', collaborators='[]', connectors='[]')
    cur.execute("""
        INSERT OR REPLACE INTO server_configs (api_key, server_type, rules_text, rules_json, collaborators_json, connectors_json, updated_at)
        VALUES (?, 'raw_universal', '', '{}', '[]', '[]', ?)
    """, (raw_key, now))
    conn.commit()
    conn.close()
    sync_db_to_shared()
    return {
        "key": raw_key,
        "name": name,
        "role": "سرور خام همه‌کاره",
        "project_id": proj["id"],
        "project_name": proj["name"],
        "console_url": f"http://localhost:8080/console/{raw_key}",
        "created_at": now,
        "is_active": 1,
    }


